import logging
import random
import string
import asyncio
import time
import os
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import sys
from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, ForceReply
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError, ConnectionFailure

# Set up logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Configuration
API_ID = 23933044
API_HASH = "6df11147cbec7d62a323f0f498c8c03a"
BOT_TOKEN = "7737766541:AAGQb_SiIb8S6jBKd3xK1wuJjmbQ5Q4hChQ"
OWNER_ID = 7125341830
MONGO_URL = "mongodb+srv://animepahe:animepahe@animepahe.o8zgy.mongodb.net/?retryWrites=true&w=majority&appName=animepahe"
DB_NAME = "genzgiveawaybot"
FORCE_SUB_CHANNEL = -1003848388234  # Your force sub channel ID

# Create necessary directories
STOCK_DIR = "STOCK"
LOGS_DIR = "LOGS"
BACKUP_DIR = "BACKUPS"

for directory in [STOCK_DIR, LOGS_DIR, BACKUP_DIR]:
    if not os.path.exists(directory):
        os.makedirs(directory)

# Connect to MongoDB
try:
    mongo_client = MongoClient(MONGO_URL)
    db = mongo_client[DB_NAME]
    
    # Collections
    users_col = db["users"]
    admins_col = db["admins"]
    stocks_col = db["stocks"]
    redeem_keys_col = db["redeem_keys"]
    feedback_col = db["feedback"]
    user_redemptions_col = db["user_redemptions"]
    banned_users_col = db["banned_users"]
    giveaway_stats_col = db["giveaway_stats"]
    
    # Ensure indexes
    users_col.create_index("user_id", unique=True)
    admins_col.create_index("admin_id", unique=True)
    stocks_col.create_index("unique_key", unique=True)
    redeem_keys_col.create_index("key", unique=True)
    user_redemptions_col.create_index([("user_id", 1), ("stock_key", 1)], unique=True)
    banned_users_col.create_index("user_id", unique=True)
    logger.info("Connected to MongoDB successfully")
except ConnectionFailure as e:
    logger.error(f"Could not connect to MongoDB: {e}")
    exit(1)

# Helper functions
def is_owner(_, __, message: Message) -> bool:
    return message.from_user.id == OWNER_ID

def is_admin(_, __, message: Message) -> bool:
    if message.from_user.id == OWNER_ID:
        return True
    try:
        admin = admins_col.find_one({"admin_id": message.from_user.id})
        return admin is not None
    except Exception:
        return False

def is_user(_, __, message: Message) -> bool:
    try:
        user = users_col.find_one({"user_id": message.from_user.id})
        return user is not None
    except Exception:
        return False

def is_not_banned(_, __, message: Message) -> bool:
    try:
        banned = banned_users_col.find_one({"user_id": message.from_user.id})
        return banned is None
    except Exception:
        return True

# Custom filters
owner_filter = filters.create(is_owner)
admin_filter = filters.create(is_admin)
user_filter = filters.create(is_user)
not_banned_filter = filters.create(is_not_banned)

def generate_unique_key(length=8):
    """Generate a unique key for stocks"""
    chars = string.ascii_uppercase + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

def generate_redeem_key(length=12):
    """Generate a redeem key"""
    chars = string.ascii_uppercase + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

def get_stock_file_path(unique_key):
    """Get file path for a stock"""
    return os.path.join(STOCK_DIR, f"{unique_key}.txt")

def count_lines_in_file(file_path):
    """Count lines in a file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return sum(1 for _ in f)
    except FileNotFoundError:
        return 0
    except Exception as e:
        logger.error(f"Error counting lines in file: {e}")
        return 0

async def check_force_sub(user_id: int) -> Tuple[bool, Optional[str]]:
    """Check if user is subscribed to force sub channel"""
    try:
        member = await app.get_chat_member(FORCE_SUB_CHANNEL, user_id)
        if member.status in ["member", "administrator", "creator"]:
            return True, None
        return False, "not_member"
    except Exception as e:
        logger.error(f"Error checking force sub: {e}")
        return False, "error"

async def send_force_sub_message(client, message: Message):
    """Send force subscription message"""
    try:
        # Get channel invite link
        chat = await client.get_chat(FORCE_SUB_CHANNEL)
        invite_link = await chat.export_invite_link()
        
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("📢 Join Channel", url=invite_link)],
            [InlineKeyboardButton("🔄 Check Again", callback_data="check_subscription")]
        ])
        
        await message.reply_text(
            "🔒 **Access Restricted**\n\n"
            "You need to join our channel to use this bot!\n"
            "Please join and try again.",
            reply_markup=buttons,
            parse_mode=enums.ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error sending force sub message: {e}")

async def notify_admins_bot_started(bot):
    """Notify all admins and owner that the bot has started"""
    try:
        admins = list(admins_col.find())
        all_recipients = [{"admin_id": OWNER_ID}] + admins
        
        for admin in all_recipients:
            try:
                await bot.send_message(
                    admin["admin_id"],
                    f"🤖 **{bot.mention} Started Successfully!**\n\n"
                    f"⏰ Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                    "✅ All systems operational and ready to serve.\n"
                    f"📊 Force Sub Channel: {FORCE_SUB_CHANNEL}"
                )
                logger.info(f"Startup notification sent to admin: {admin['admin_id']}")
            except Exception as e:
                logger.error(f"Failed to send startup notification: {e}")
    except Exception as e:
        logger.error(f"Error in notify_admins_bot_started: {e}")

async def notify_admins_redeem(redeem_data, stock_data, user):
    """Notify all admins and owner about a key redemption"""
    try:
        admins = list(admins_col.find())
        all_recipients = [{"admin_id": OWNER_ID}] + admins
        
        user_info = f"👤 User: {user.first_name}"
        if user.username:
            user_info += f" (@{user.username})"
        user_info += f" (ID: {user.id})"
        
        # Update giveaway stats
        giveaway_stats_col.update_one(
            {"service": stock_data['service_name']},
            {"$inc": {"total_redeemed": 1}, "$set": {"last_redeem": datetime.now()}},
            upsert=True
        )
        
        for admin in all_recipients:
            try:
                await app.send_message(
                    admin["admin_id"],
                    f"🎉 **Key Redeemed!**\n\n"
                    f"🔧 **Service:** {stock_data['service_name']}\n"
                    f"🔑 **Redeem Key:** `{redeem_data['key']}`\n"
                    f"⏰ **Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                    f"{user_info}",
                    parse_mode=enums.ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Failed to send redeem notification: {e}")
    except Exception as e:
        logger.error(f"Error in notify_admins_redeem: {e}")

async def check_and_clean_empty_stocks():
    """Check for stocks with 0 lines and clean them up"""
    try:
        stocks = list(stocks_col.find())
        for stock in stocks:
            line_count = count_lines_in_file(stock["file_path"])
            if line_count == 0:
                try:
                    os.remove(stock["file_path"])
                except FileNotFoundError:
                    pass
                
                stocks_col.delete_one({"unique_key": stock["unique_key"]})
                redeem_keys_col.delete_many({"stock_key": stock["unique_key"]})
                logger.info(f"Cleaned up empty stock: {stock['service_name']}")
    except Exception as e:
        logger.error(f"Error cleaning empty stocks: {e}")

class Bot(Client):
    def __init__(self):
        super().__init__(
            name="giveaway_bot",
            api_id=API_ID,
            api_hash=API_HASH,
            bot_token=BOT_TOKEN,
            workers=200,
            max_concurrent_transmissions=1000,
            sleep_threshold=15,
        )
        self.start_time = time.time()

    async def start(self):
        await super().start()
        me = await self.get_me()
        self.mention = me.mention
        self.username = me.username  
        
        print(f"{me.first_name} Is Started.....✨️")
        await notify_admins_bot_started(self)

app = Bot()

# Force sub middleware
@app.on_message(filters.private & ~filters.command("start") & ~filters.command("verify"))
async def force_sub_middleware(client, message: Message):
    user_id = message.from_user.id
    
    # Skip force sub check for owner and admins
    if user_id == OWNER_ID or admins_col.find_one({"admin_id": user_id}):
        return
    
    is_subscribed, error = await check_force_sub(user_id)
    if not is_subscribed:
        await send_force_sub_message(client, message)
        return

# Start command
@app.on_message(filters.command("start") & filters.private)
async def start_command(client, message: Message):
    user_id = message.from_user.id
    
    # Check force sub for regular users
    if user_id != OWNER_ID and not admins_col.find_one({"admin_id": user_id}):
        is_subscribed, _ = await check_force_sub(user_id)
        if not is_subscribed:
            await send_force_sub_message(client, message)
            return
    
    # Add user to database
    try:
        users_col.update_one(
            {"user_id": user_id},
            {"$setOnInsert": {"user_id": user_id, "joined_at": datetime.now()}},
            upsert=True
        )
    except Exception as e:
        logger.error(f"Error adding user: {e}")
    
    # Check if user is banned
    banned = banned_users_col.find_one({"user_id": user_id})
    if banned:
        await message.reply_text(
            "🚫 **You are banned from using this bot!**\n\n"
            f"Reason: {banned.get('reason', 'No reason provided')}\n"
            f"Banned on: {banned.get('banned_at', 'Unknown')}"
        )
        return
    
    welcome_text = (
        "🎉 **Welcome to GenZ Giveaway Bot!** 🎉\n\n"
        "✨ **Features:**\n"
        "• 🔑 Redeem premium accounts with /redeem\n"
        "• 💬 Provide feedback with /feedback\n"
        "• 📊 Check bot stats with /stats\n\n"
        "👑 **Admin Commands:**\n"
        "• `/add` - Add premium accounts\n"
        "• `/see_stock` - View all stocks\n"
        "• `/gen_key` - Generate redeem keys\n"
        "• `/clr_stock` - Clear stocks\n"
        "• `/broadcast` - Broadcast message\n"
        "• `/logs` - Generate logs\n"
        "• `/stats` - View bot statistics\n"
        "• `/resetgiveaway` - Reset giveaway data\n"
        "• `/ban` - Ban a user\n"
        "• `/unban` - Unban a user\n\n"
        "🛠 **Owner Commands:**\n"
        "• `/add_admin` - Add admin\n"
        "• `/rmv_admin` - Remove admin\n"
        "• `/see_admins` - View all admins\n"
        "• `/clr_db` - Clear database\n"
        "• `/restart` - Restart bot\n\n"
        "💡 **Need help?** Contact @GenZSupport"
    )
    
    # Create inline buttons
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔑 Redeem Key", callback_data="help_redeem"),
         InlineKeyboardButton("📊 Bot Stats", callback_data="help_stats")],
        [InlineKeyboardButton("💬 Feedback", callback_data="help_feedback"),
         InlineKeyboardButton("👑 Admin Help", callback_data="help_admin")]
    ])
    
    await message.reply_text(welcome_text, reply_markup=buttons)

# Help callback handlers
@app.on_callback_query(filters.regex("^help_"))
async def help_callback(client, callback_query: CallbackQuery):
    help_type = callback_query.data.split("_")[1]
    
    if help_type == "redeem":
        text = (
            "🔑 **How to Redeem:**\n\n"
            "1️⃣ Get a redeem key from an admin\n"
            "2️⃣ Use the command: `/redeem YOUR_KEY`\n"
            "3️⃣ Receive your premium account instantly!\n\n"
            "⚠️ **Note:** Each key can only be used once."
        )
    elif help_type == "stats":
        total_users = users_col.count_documents({})
        total_redeems = user_redemptions_col.count_documents({})
        total_keys = redeem_keys_col.count_documents({})
        used_keys = redeem_keys_col.count_documents({"used": True})
        
        text = (
            f"📊 **Bot Statistics:**\n\n"
            f"👥 Total Users: {total_users}\n"
            f"🎁 Total Redeems: {total_redeems}\n"
            f"🔑 Total Keys Generated: {total_keys}\n"
            f"✅ Used Keys: {used_keys}\n"
            f"📈 Success Rate: {int(used_keys/total_keys*100) if total_keys > 0 else 0}%"
        )
    elif help_type == "feedback":
        text = (
            "💬 **How to Give Feedback:**\n\n"
            "• Use `/feedback` followed by your message\n"
            "• Or reply to any message with `/feedback`\n"
            "• You can also send media with feedback\n\n"
            "Your feedback helps us improve! 🌟"
        )
    elif help_type == "admin":
        text = (
            "👑 **Admin Commands Guide:**\n\n"
            "• `/add ServiceName` - Add stock (reply to file)\n"
            "• `/see_stock` - View all available stocks\n"
            "• `/gen_key KEY NUMBER` - Generate redeem keys\n"
            "• `/clr_stock` - Clear specific stock\n"
            "• `/broadcast` - Broadcast message to all users\n"
            "• `/logs` - Download bot logs\n"
            "• `/stats` - View detailed statistics\n"
            "• `/resetgiveaway` - Reset all giveaway data\n"
            "• `/ban USER_ID REASON` - Ban a user\n"
            "• `/unban USER_ID` - Unban a user"
        )
    else:
        text = "Help information not available."
    
    await callback_query.answer()
    await callback_query.message.edit_text(text, parse_mode=enums.ParseMode.MARKDOWN)
    
    # Add back button
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("◀️ Back", callback_data="back_to_start")]
    ])
    await callback_query.message.edit_reply_markup(buttons)

@app.on_callback_query(filters.regex("^back_to_start$"))
async def back_to_start(client, callback_query: CallbackQuery):
    await start_command(client, callback_query.message)

@app.on_callback_query(filters.regex("^check_subscription$"))
async def check_subscription_callback(client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    is_subscribed, _ = await check_force_sub(user_id)
    
    if is_subscribed:
        await callback_query.answer("✅ Subscription verified! You can now use the bot.", show_alert=True)
        await start_command(client, callback_query.message)
    else:
        await callback_query.answer("❌ You still haven't joined the channel. Please join first!", show_alert=True)

# Add stock command
@app.on_message(filters.command("add") & admin_filter & filters.private)
async def add_stock_command(client, message: Message):
    if not message.reply_to_message or not message.reply_to_message.document:
        await message.reply_text("❌ Please reply to a document with the command. Usage: /add ServiceName")
        return
    
    if len(message.command) < 2:
        await message.reply_text("❌ Please specify a service name. Usage: /add ServiceName")
        return
    
    service_name = message.command[1]
    unique_key = generate_unique_key()
    file_path = get_stock_file_path(unique_key)
    
    try:
        download_msg = await message.reply_text("📥 Downloading document...")
        file_path_download = await message.reply_to_message.download(file_name=file_path)
        
        line_count = count_lines_in_file(file_path_download)
        
        if line_count == 0:
            os.remove(file_path_download)
            await download_msg.edit_text("❌ The document is empty or could not be read.")
            return
        
        stocks_col.insert_one({
            "unique_key": unique_key,
            "service_name": service_name,
            "file_path": file_path_download,
            "line_count": line_count,
            "created_at": datetime.now(),
            "created_by": message.from_user.id,
            "created_by_username": message.from_user.username or "N/A"
        })
        
        await download_msg.edit_text(
            f"✅ **Stock Added Successfully!**\n\n"
            f"🔧 **Service:** {service_name}\n"
            f"🔑 **Stock ID:** `{unique_key}`\n"
            f"📊 **Accounts:** {line_count}\n"
            f"💾 **Saved to:** `{file_path_download}`"
        )
    except Exception as e:
        logger.error(f"Error adding stock: {e}")
        await message.reply_text("❌ An error occurred while adding the stock.")

# See stock command
@app.on_message(filters.command("see_stock") & admin_filter & filters.private)
async def see_stock_command(client, message: Message):
    try:
        stocks = list(stocks_col.find())
        
        if not stocks:
            await message.reply_text("📭 No stocks available.")
            return
        
        # Create paginated response
        response = "📦 **Available Stocks:**\n\n"
        for i, stock in enumerate(stocks, 1):
            response += (
                f"**{i}. {stock['service_name']}**\n"
                f"🔑 ID: `{stock['unique_key']}`\n"
                f"📊 Count: {stock['line_count']}\n"
                f"👤 By: {stock.get('created_by_username', 'N/A')}\n"
                f"📅 Added: {stock['created_at'].strftime('%Y-%m-%d')}\n\n"
            )
        
        # Split if too long
        if len(response) > 4000:
            parts = [response[i:i+4000] for i in range(0, len(response), 4000)]
            for part in parts:
                await message.reply_text(part)
        else:
            await message.reply_text(response)
    except Exception as e:
        logger.error(f"Error viewing stocks: {e}")
        await message.reply_text("❌ An error occurred while viewing stocks.")

# Generate key command
@app.on_message(filters.command("gen_key") & admin_filter & filters.private)
async def gen_key_command(client, message: Message):
    if len(message.command) < 3:
        await message.reply_text("❌ Usage: /gen_key {stock_id} {number_of_keys}")
        return
    
    unique_key = message.command[1]
    
    try:
        num_keys = int(message.command[2])
        if num_keys <= 0 or num_keys > 100:
            await message.reply_text("❌ Number of keys must be between 1 and 100.")
            return
    except ValueError:
        await message.reply_text("❌ Please enter a valid number.")
        return
    
    try:
        stock = stocks_col.find_one({"unique_key": unique_key})
        if not stock:
            await message.reply_text("❌ Stock not found with that ID.")
            return
        
        current_line_count = count_lines_in_file(stock["file_path"])
        if current_line_count < num_keys:
            await message.reply_text(
                f"❌ Not enough accounts. Only {current_line_count} available, requested {num_keys}."
            )
            return
        
        generated_keys = []
        for _ in range(num_keys):
            redeem_key = generate_redeem_key()
            redeem_keys_col.insert_one({
                "key": redeem_key,
                "stock_key": unique_key,
                "generated_at": datetime.now(),
                "used": False,
                "used_by": None,
                "used_at": None,
                "generated_by": message.from_user.id,
                "generated_by_username": message.from_user.username or "N/A"
            })
            generated_keys.append(redeem_key)
        
        stocks_col.update_one(
            {"unique_key": unique_key},
            {"$set": {"line_count": current_line_count - num_keys}}
        )
        
        # Format and send keys
        keys_text = "\n".join([f"• `{key}`" for key in generated_keys])
        bot_username = (await client.get_me()).username
        
        await message.reply_text(
            f"✅ **Successfully Generated {num_keys} Keys**\n\n"
            f"🔧 **Service:** {stock['service_name']}\n"
            f"🔑 **Stock ID:** `{unique_key}`\n"
            f"📊 **Remaining:** {current_line_count - num_keys}\n\n"
            f"**Generated Keys:**\n{keys_text}\n\n"
            f"**How to Redeem:**\n"
            f"Send `/redeem KEY` to @{bot_username}\n\n"
            f"⚠️ Each key can only be used once!",
            parse_mode=enums.ParseMode.MARKDOWN
        )
        
        # Also send as text file if many keys
        if num_keys > 10:
            keys_file = os.path.join(LOGS_DIR, f"keys_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
            with open(keys_file, 'w') as f:
                f.write("\n".join(generated_keys))
            await message.reply_document(keys_file, caption="📋 Keys in text format")
            os.remove(keys_file)
        
        if current_line_count - num_keys == 0:
            await check_and_clean_empty_stocks()
            
    except Exception as e:
        logger.error(f"Error generating keys: {e}")
        await message.reply_text("❌ An error occurred while generating keys.")

# Redeem command
@app.on_message(filters.command("redeem") & user_filter & not_banned_filter & filters.private)
async def redeem_command(client, message: Message):
    # Check force sub
    if message.from_user.id != OWNER_ID and not admins_col.find_one({"admin_id": message.from_user.id}):
        is_subscribed, _ = await check_force_sub(message.from_user.id)
        if not is_subscribed:
            await send_force_sub_message(client, message)
            return
    
    if len(message.command) < 2:
        await message.reply_text("❌ Usage: /redeem {key}")
        return
    
    redeem_key = message.command[1]
    user_id = message.from_user.id
    
    # Check if user is banned
    banned = banned_users_col.find_one({"user_id": user_id})
    if banned:
        await message.reply_text(
            f"🚫 **You are banned!**\n\n"
            f"Reason: {banned.get('reason', 'No reason')}\n"
            f"Contact: @GenZSupport"
        )
        return
    
    try:
        key_data = redeem_keys_col.find_one({"key": redeem_key})
        if not key_data:
            await message.reply_text("❌ Invalid redeem key.")
            return
        
        if key_data.get("used", False):
            await message.reply_text("❌ This key has already been used.")
            return
        
        # Check if user already redeemed from this stock
        user_redemption = user_redemptions_col.find_one({
            "user_id": user_id,
            "stock_key": key_data["stock_key"]
        })
        
        if user_redemption:
            stock = stocks_col.find_one({"unique_key": key_data["stock_key"]})
            service_name = stock["service_name"] if stock else "this service"
            await message.reply_text(f"❌ You have already redeemed a {service_name} key. One per service only!")
            return
        
        stock = stocks_col.find_one({"unique_key": key_data["stock_key"]})
        if not stock:
            await message.reply_text("❌ Stock is no longer available.")
            return
        
        # Get account from file
        file_path = stock["file_path"]
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                if not lines:
                    await message.reply_text("❌ No accounts available.")
                    return
                
                account_line = lines[0].strip()
                
                with open(file_path, 'w', encoding='utf-8') as f_write:
                    f_write.writelines(lines[1:])
                
                # Mark key as used
                redeem_keys_col.update_one(
                    {"key": redeem_key},
                    {
                        "$set": {
                            "used": True,
                            "used_by": user_id,
                            "used_by_username": message.from_user.username or "N/A",
                            "used_at": datetime.now()
                        }
                    }
                )
                
                # Record redemption
                user_redemptions_col.insert_one({
                    "user_id": user_id,
                    "username": message.from_user.username or "N/A",
                    "stock_key": key_data["stock_key"],
                    "service_name": stock["service_name"],
                    "redeemed_at": datetime.now(),
                    "redeem_key": redeem_key
                })
                
                # Send account
                try:
                    await client.send_message(
                        user_id,
                        f"🎉 **Account Redeemed Successfully!**\n\n"
                        f"🔧 **Service:** {stock['service_name']}\n"
                        f"📦 **Your Account:**\n`{account_line}`\n\n"
                        f"⚠️ Please change password immediately if applicable!"
                    )
                    
                    await message.reply_text(
                        "✅ **Account sent! Check your DM.**\n\n"
                        "💬 **Enjoying our service?** Send /feedback to share your experience!"
                    )
                    
                    # Notify admins
                    await notify_admins_redeem(key_data, stock, message.from_user)
                    
                except Exception as e:
                    logger.error(f"Error sending account: {e}")
                    await message.reply_text("❌ Failed to send account. Contact admin.")
                
                # Check if stock empty
                if count_lines_in_file(file_path) == 0:
                    await check_and_clean_empty_stocks()
                    
        except FileNotFoundError:
            await message.reply_text("❌ Stock file not found.")
    except Exception as e:
        logger.error(f"Error redeeming key: {e}")
        await message.reply_text("❌ An error occurred.")

# Clear stock command
@app.on_message(filters.command("clr_stock") & admin_filter & filters.private)
async def clr_stock_command(client, message: Message):
    try:
        stocks = list(stocks_col.find())
        
        if not stocks:
            await message.reply_text("📭 No stocks to clear.")
            return
        
        buttons = []
        for stock in stocks:
            buttons.append([
                InlineKeyboardButton(
                    f"🗑️ {stock['service_name']} ({stock['line_count']})",
                    callback_data=f"delete_stock_{stock['unique_key']}"
                )
            ])
        
        buttons.append([InlineKeyboardButton("🗑️ Delete All Stocks", callback_data="delete_all_stocks")])
        buttons.append([InlineKeyboardButton("❌ Cancel", callback_data="cancel_delete")])
        
        await message.reply_text(
            "📦 **Select stock to delete:**",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
    except Exception as e:
        logger.error(f"Error in clear stock: {e}")
        await message.reply_text("❌ An error occurred.")

# Delete stock callback
@app.on_callback_query(filters.regex(r"^(delete_stock_|delete_all_stocks|cancel_delete)$"))
async def handle_stock_deletion(client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    
    if user_id != OWNER_ID and not admins_col.find_one({"admin_id": user_id}):
        await callback_query.answer("Unauthorized!", show_alert=True)
        return
    
    if callback_query.data == "cancel_delete":
        await callback_query.message.delete()
        return
    
    try:
        if callback_query.data == "delete_all_stocks":
            stocks = list(stocks_col.find())
            for stock in stocks:
                try:
                    os.remove(stock["file_path"])
                except:
                    pass
            
            stocks_col.delete_many({})
            redeem_keys_col.delete_many({})
            user_redemptions_col.delete_many({})
            await callback_query.message.edit_text("✅ All stocks and data cleared!")
        else:
            unique_key = callback_query.data.split("_")[2]
            stock = stocks_col.find_one({"unique_key": unique_key})
            
            if stock:
                try:
                    os.remove(stock["file_path"])
                except:
                    pass
                
                stocks_col.delete_one({"unique_key": unique_key})
                redeem_keys_col.delete_many({"stock_key": unique_key})
                user_redemptions_col.delete_many({"stock_key": unique_key})
                await callback_query.message.edit_text(f"✅ {stock['service_name']} stock deleted!")
            else:
                await callback_query.answer("Stock not found!", show_alert=True)
    except Exception as e:
        logger.error(f"Error deleting stock: {e}")
        await callback_query.answer("Error occurred!", show_alert=True)

# Reset Giveaway command
@app.on_message(filters.command("resetgiveaway") & admin_filter & filters.private)
async def reset_giveaway_command(client, message: Message):
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Yes, Reset Everything", callback_data="confirm_reset")],
        [InlineKeyboardButton("❌ No, Cancel", callback_data="cancel_reset")]
    ])
    
    await message.reply_text(
        "⚠️ **DANGER ZONE** ⚠️\n\n"
        "This will reset ALL giveaway data:\n"
        "• Delete all stocks\n"
        "• Delete all redeem keys\n"
        "• Delete all user redemptions\n"
        "• Reset giveaway statistics\n\n"
        "**This action cannot be undone!**\n\n"
        "Are you sure?",
        reply_markup=buttons
    )

@app.on_callback_query(filters.regex("^(confirm_reset|cancel_reset)$"))
async def handle_reset_giveaway(client, callback_query: CallbackQuery):
    if callback_query.data == "cancel_reset":
        await callback_query.message.edit_text("❌ Reset cancelled.")
        return
    
    try:
        # Delete all stock files
        stocks = list(stocks_col.find())
        for stock in stocks:
            try:
                os.remove(stock["file_path"])
            except:
                pass
        
        # Clear collections
        stocks_col.delete_many({})
        redeem_keys_col.delete_many({})
        user_redemptions_col.delete_many({})
        giveaway_stats_col.delete_many({})
        
        await callback_query.message.edit_text(
            "✅ **Giveaway Data Reset Successfully!**\n\n"
            "All stocks, keys, and redemption records have been cleared.\n"
            "The bot is ready for a fresh start!"
        )
    except Exception as e:
        logger.error(f"Error resetting giveaway: {e}")
        await callback_query.message.edit_text("❌ Error occurred during reset.")

# Ban command
@app.on_message(filters.command("ban") & admin_filter & filters.private)
async def ban_user_command(client, message: Message):
    if len(message.command) < 2:
        await message.reply_text(
            "❌ **Usage:** `/ban USER_ID [REASON]`\n\n"
            "Example: `/ban 123456789 Spamming`"
        )
        return
    
    try:
        user_id = int(message.command[1])
        reason = " ".join(message.command[2:]) if len(message.command) > 2 else "No reason provided"
        
        # Check if user exists
        user = users_col.find_one({"user_id": user_id})
        if not user:
            await message.reply_text("❌ User not found in database.")
            return
        
        # Check if already banned
        existing_ban = banned_users_col.find_one({"user_id": user_id})
        if existing_ban:
            await message.reply_text(f"❌ User is already banned.\nReason: {existing_ban.get('reason', 'Unknown')}")
            return
        
        # Ban user
        banned_users_col.insert_one({
            "user_id": user_id,
            "reason": reason,
            "banned_by": message.from_user.id,
            "banned_by_username": message.from_user.username or "N/A",
            "banned_at": datetime.now()
        })
        
        # Try to notify user
        try:
            await client.send_message(
                user_id,
                f"🚫 **You have been banned from using this bot!**\n\n"
                f"Reason: {reason}\n"
                f"Banned by: {message.from_user.first_name}\n\n"
                f"Contact support for appeal."
            )
        except:
            pass
        
        await message.reply_text(
            f"✅ **User Banned Successfully!**\n\n"
            f"User ID: `{user_id}`\n"
            f"Reason: {reason}\n"
            f"Banned by: {message.from_user.first_name}"
        )
        
        # Log ban
        logger.info(f"User {user_id} banned by {message.from_user.id} for: {reason}")
        
    except ValueError:
        await message.reply_text("❌ Invalid user ID. Please provide a numeric ID.")
    except Exception as e:
        logger.error(f"Error banning user: {e}")
        await message.reply_text("❌ An error occurred while banning the user.")

# Unban command
@app.on_message(filters.command("unban") & admin_filter & filters.private)
async def unban_user_command(client, message: Message):
    if len(message.command) < 2:
        await message.reply_text("❌ Usage: `/unban USER_ID`")
        return
    
    try:
        user_id = int(message.command[1])
        
        # Check if user is banned
        banned = banned_users_col.find_one({"user_id": user_id})
        if not banned:
            await message.reply_text("❌ User is not banned.")
            return
        
        # Unban user
        banned_users_col.delete_one({"user_id": user_id})
        
        # Try to notify user
        try:
            await client.send_message(
                user_id,
                f"✅ **You have been unbanned!**\n\n"
                f"You can now use the bot again.\n"
                f"Use /start to begin."
            )
        except:
            pass
        
        await message.reply_text(
            f"✅ **User Unbanned Successfully!**\n\n"
            f"User ID: `{user_id}`\n"
            f"Previous reason: {banned.get('reason', 'Unknown')}"
        )
        
        # Log unban
        logger.info(f"User {user_id} unbanned by {message.from_user.id}")
        
    except ValueError:
        await message.reply_text("❌ Invalid user ID.")
    except Exception as e:
        logger.error(f"Error unbanning user: {e}")
        await message.reply_text("❌ An error occurred.")

# Stats command
@app.on_message(filters.command("stats") & filters.private)
async def stats_command(client, message: Message):
    user_id = message.from_user.id
    
    # Check force sub for regular users
    if user_id != OWNER_ID and not admins_col.find_one({"admin_id": user_id}):
        is_subscribed, _ = await check_force_sub(user_id)
        if not is_subscribed:
            await send_force_sub_message(client, message)
            return
    
    # Get statistics
    total_users = users_col.count_documents({})
    total_admins = admins_col.count_documents({}) + 1
    total_stocks = stocks_col.count_documents({})
    total_keys = redeem_keys_col.count_documents({})
    used_keys = redeem_keys_col.count_documents({"used": True})
    total_feedback = feedback_col.count_documents({})
    total_redemptions = user_redemptions_col.count_documents({})
    total_banned = banned_users_col.count_documents({})
    
    # Calculate bot uptime
    uptime = datetime.now() - app.start_time
    uptime_str = str(uptime).split('.')[0]
    
    # Get top services
    top_services = list(giveaway_stats_col.find().sort("total_redeemed", -1).limit(5))
    
    stats_text = (
        "📊 **Bot Statistics**\n\n"
        f"👥 **Users:** {total_users}\n"
        f"👑 **Admins:** {total_admins}\n"
        f"🚫 **Banned:** {total_banned}\n"
        f"📦 **Active Stocks:** {total_stocks}\n"
        f"🔑 **Keys Generated:** {total_keys}\n"
        f"✅ **Keys Used:** {used_keys}\n"
        f"🎁 **Total Redemptions:** {total_redemptions}\n"
        f"💬 **Feedback Received:** {total_feedback}\n"
        f"📈 **Success Rate:** {int(used_keys/total_keys*100) if total_keys > 0 else 0}%\n\n"
        f"⏱ **Uptime:** {uptime_str}\n\n"
    )
    
    if top_services:
        stats_text += "🏆 **Top Services:**\n"
        for i, service in enumerate(top_services, 1):
            stats_text += f"{i}. {service['service']}: {service['total_redeemed']} redeems\n"
    
    # Add admin-only stats
    if user_id == OWNER_ID or admins_col.find_one({"admin_id": user_id}):
        # Get recent activity
        last_hour = datetime.now() - timedelta(hours=1)
        recent_redeems = user_redemptions_col.count_documents({"redeemed_at": {"$gte": last_hour}})
        
        stats_text += f"\n📊 **Admin Stats:**\n"
        stats_text += f"🕐 Last hour redeems: {recent_redeems}\n"
        
        # Get stock details
        total_accounts = sum([stock['line_count'] for stock in stocks_col.find()])
        stats_text += f"📦 Total accounts in stock: {total_accounts}\n"
    
    # Create inline buttons
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 Refresh", callback_data="refresh_stats")],
        [InlineKeyboardButton("📊 Detailed Stats", callback_data="detailed_stats")]
    ])
    
    await message.reply_text(stats_text, reply_markup=buttons, parse_mode=enums.ParseMode.MARKDOWN)

@app.on_callback_query(filters.regex("^(refresh_stats|detailed_stats)$"))
async def stats_callbacks(client, callback_query: CallbackQuery):
    if callback_query.data == "refresh_stats":
        await stats_command(client, callback_query.message)
    else:
        # Detailed stats
        # Get top redeemers
        top_redeemers = list(user_redemptions_col.aggregate([
            {"$group": {"_id": "$user_id", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": 10}
        ]))
        
        text = "📊 **Detailed Statistics**\n\n"
        text += "🏆 **Top Redeemers:**\n"
        for i, redeemer in enumerate(top_redeemers, 1):
            user = users_col.find_one({"user_id": redeemer['_id']})
            username = user.get('username', 'Unknown') if user else 'Unknown'
            text += f"{i}. {username}: {redeemer['count']} redeems\n"
        
        await callback_query.answer()
        await callback_query.message.edit_text(text, parse_mode=enums.ParseMode.MARKDOWN)
        
        # Add back button
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("◀️ Back to Stats", callback_data="refresh_stats")]
        ])
        await callback_query.message.edit_reply_markup(buttons)

# Feedback command
@app.on_message(filters.command("feedback") & filters.private)
async def feedback_command(client, message: Message):
    user_id = message.from_user.id
    
    # Check force sub
    if user_id != OWNER_ID and not admins_col.find_one({"admin_id": user_id}):
        is_subscribed, _ = await check_force_sub(user_id)
        if not is_subscribed:
            await send_force_sub_message(client, message)
            return
    
    feedback_text = ""
    has_media = False
    
    if message.reply_to_message:
        if message.reply_to_message.text:
            feedback_text = message.reply_to_message.text
        elif message.reply_to_message.caption:
            feedback_text = message.reply_to_message.caption
            has_media = True
        else:
            feedback_text = "Media content"
            has_media = True
    else:
        if len(message.command) < 2:
            await message.reply_text(
                "💬 **How to give feedback:**\n\n"
                "• `/feedback Your message here`\n"
                "• Or reply to any message with `/feedback`\n\n"
                "Your feedback helps us improve! 🌟"
            )
            return
        feedback_text = " ".join(message.command[1:])
    
    try:
        feedback_col.insert_one({
            "user_id": user_id,
            "username": message.from_user.username or "N/A",
            "feedback": feedback_text,
            "has_media": has_media,
            "date": datetime.now()
        })
        
        # Notify admins
        admins = list(admins_col.find()) + [{"admin_id": OWNER_ID}]
        
        for admin in admins:
            try:
                await client.send_message(
                    admin["admin_id"],
                    f"📩 **New Feedback!**\n\n"
                    f"👤 From: {message.from_user.first_name}\n"
                    f"🆔 ID: `{user_id}`\n"
                    f"💬 Message: {feedback_text}\n"
                    f"📅 Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                )
                
                if has_media and message.reply_to_message:
                    await message.reply_to_message.forward(admin["admin_id"])
            except:
                pass
        
        await message.reply_text(
            "✅ **Thank you for your feedback!**\n\n"
            "We appreciate your input and will use it to improve our service. 🌟"
        )
    except Exception as e:
        logger.error(f"Error saving feedback: {e}")
        await message.reply_text("❌ An error occurred while saving your feedback.")

# Broadcast command
@app.on_message(filters.command("broadcast") & admin_filter & filters.private)
async def broadcast_command(client, message: Message):
    if not message.reply_to_message:
        await message.reply_text("❌ Please reply to a message to broadcast.")
        return
    
    broadcast_msg = message.reply_to_message
    users = users_col.find()
    success_count = 0
    fail_count = 0
    banned_count = 0
    
    total_users = users_col.count_documents({})
    
    if total_users == 0:
        await message.reply_text("❌ No users in database.")
        return
    
    # Confirm broadcast
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Yes, Broadcast", callback_data="confirm_broadcast"),
         InlineKeyboardButton("❌ No, Cancel", callback_data="cancel_broadcast")]
    ])
    
    await message.reply_text(
        f"📢 **Broadcast Confirmation**\n\n"
        f"Total users: {total_users}\n"
        f"Message preview: {broadcast_msg.text[:100] if broadcast_msg.text else 'Media message'}\n\n"
        f"Are you sure you want to broadcast?",
        reply_markup=buttons
    )
    
    # Store broadcast message in a variable accessible by callback
    app.broadcast_data = {"msg": broadcast_msg, "total": total_users}

@app.on_callback_query(filters.regex("^(confirm_broadcast|cancel_broadcast)$"))
async def handle_broadcast(client, callback_query: CallbackQuery):
    if callback_query.data == "cancel_broadcast":
        await callback_query.message.edit_text("❌ Broadcast cancelled.")
        return
    
    await callback_query.message.edit_text("📤 Broadcasting started...")
    
    broadcast_msg = app.broadcast_data["msg"]
    total_users = app.broadcast_data["total"]
    
    success_count = 0
    fail_count = 0
    banned_count = 0
    
    start_time = time.time()
    processed = 0
    
    for user in users_col.find():
        user_id = user["user_id"]
        
        # Skip banned users
        if banned_users_col.find_one({"user_id": user_id}):
            banned_count += 1
            processed += 1
            continue
        
        try:
            await broadcast_msg.copy(user_id)
            success_count += 1
        except Exception as e:
            fail_count += 1
            logger.error(f"Error broadcasting to {user_id}: {e}")
        
        processed += 1
        
        # Update progress every 50 users
        if processed % 50 == 0 or processed == total_users:
            percent = int(processed / total_users * 100)
            try:
                await callback_query.message.edit_text(
                    f"📤 **Broadcasting...**\n\n"
                    f"Progress: {percent}% ({processed}/{total_users})\n"
                    f"✅ Success: {success_count}\n"
                    f"❌ Failed: {fail_count}\n"
                    f"🚫 Skipped (Banned): {banned_count}"
                )
            except:
                pass
            
            await asyncio.sleep(0.5)
    
    total_time = time.time() - start_time
    
    await callback_query.message.edit_text(
        f"✅ **Broadcast Completed!**\n\n"
        f"⏱ Time: {int(total_time)} seconds\n"
        f"👥 Total: {total_users}\n"
        f"✅ Success: {success_count}\n"
        f"❌ Failed: {fail_count}\n"
        f"🚫 Banned: {banned_count}\n"
        f"📊 Rate: {int(success_count/total_users*100)}%"
    )

# Logs command
@app.on_message(filters.command("logs") & admin_filter & filters.private)
async def logs_command(client, message: Message):
    try:
        # Get statistics
        total_users = users_col.count_documents({})
        total_admins = admins_col.count_documents({}) + 1
        total_stocks = stocks_col.count_documents({})
        total_redeem_keys = redeem_keys_col.count_documents({})
        used_redeem_keys = redeem_keys_col.count_documents({"used": True})
        total_feedback = feedback_col.count_documents({})
        total_redemptions = user_redemptions_col.count_documents({})
        total_banned = banned_users_col.count_documents({})
        
        # Get recent activities
        recent_redeems = list(user_redemptions_col.find().sort("redeemed_at", -1).limit(20))
        recent_feedback = list(feedback_col.find().sort("date", -1).limit(10))
        
        # Create logs
        current_time = datetime.now()
        logs_text = f"🤖 Giveaway Bot Logs - {current_time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        logs_text += "="*50 + "\n"
        logs_text += "📊 BOT STATISTICS\n"
        logs_text += "="*50 + "\n"
        logs_text += f"👥 Total Users: {total_users}\n"
        logs_text += f"👑 Total Admins: {total_admins}\n"
        logs_text += f"🚫 Banned Users: {total_banned}\n"
        logs_text += f"📦 Total Stocks: {total_stocks}\n"
        logs_text += f"🔑 Total Keys: {total_redeem_keys}\n"
        logs_text += f"✅ Used Keys: {used_redeem_keys}\n"
        logs_text += f"🎁 Total Redemptions: {total_redemptions}\n"
        logs_text += f"💬 Total Feedback: {total_feedback}\n"
        logs_text += f"📈 Success Rate: {int(used_redeem_keys/total_redeem_keys*100) if total_redeem_keys > 0 else 0}%\n\n"
        
        logs_text += "="*50 + "\n"
        logs_text += "🎁 RECENT REDEEMS (Last 20)\n"
        logs_text += "="*50 + "\n"
        if recent_redeems:
            for redeem in recent_redeems:
                logs_text += f"• {redeem['service_name']} - {redeem.get('username', 'N/A')} ({redeem['user_id']}) - {redeem['redeemed_at'].strftime('%Y-%m-%d %H:%M')}\n"
        else:
            logs_text += "• No redeems yet\n"
        logs_text += "\n"
        
        logs_text += "="*50 + "\n"
        logs_text += "💬 RECENT FEEDBACK (Last 10)\n"
        logs_text += "="*50 + "\n"
        if recent_feedback:
            for feedback in recent_feedback:
                logs_text += f"• {feedback.get('username', 'N/A')} ({feedback['user_id']}) - {feedback['date'].strftime('%Y-%m-%d %H:%M')}\n"
                logs_text += f"  {feedback['feedback'][:150]}...\n\n"
        else:
            logs_text += "• No feedback yet\n"
        
        # Save to file
        filename = f"logs_{current_time.strftime('%Y%m%d_%H%M%S')}.txt"
        filepath = os.path.join(LOGS_DIR, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(logs_text)
        
        await message.reply_document(
            document=filepath,
            caption=f"📊 **Bot Logs**\n📅 {current_time.strftime('%Y-%m-%d %H:%M:%S')}"
        )
        
        os.remove(filepath)
        
    except Exception as e:
        logger.error(f"Error generating logs: {e}")
        await message.reply_text("❌ An error occurred while generating logs.")

# Clear database command (owner only)
@app.on_message(filters.command("clr_db") & owner_filter & filters.private)
async def clr_db_command(client, message: Message):
    buttons = [
        [InlineKeyboardButton("👥 Users", callback_data="clear_users")],
        [InlineKeyboardButton("👑 Admins", callback_data="clear_admins")],
        [InlineKeyboardButton("📦 Stocks", callback_data="clear_stocks")],
        [InlineKeyboardButton("🔑 Keys", callback_data="clear_redeem_keys")],
        [InlineKeyboardButton("📩 Feedback", callback_data="clear_feedback")],
        [InlineKeyboardButton("📋 Redemptions", callback_data="clear_user_redemptions")],
        [InlineKeyboardButton("🚫 Banned Users", callback_data="clear_banned")],
        [InlineKeyboardButton("🗑️ Clear All", callback_data="clear_all_data")]
    ]
    
    # Create rows of 2 buttons each
    button_rows = [buttons[i:i+2] for i in range(0, len(buttons), 2)]
    
    await message.reply_text(
        "🗄️ **Database Management**\n\nSelect which collection to clear:",
        reply_markup=InlineKeyboardMarkup(button_rows)
    )

@app.on_callback_query(filters.regex(r"^clear_"))
async def handle_db_clearing(client, callback_query: CallbackQuery):
    if callback_query.from_user.id != OWNER_ID:
        await callback_query.answer("Only owner can do this!", show_alert=True)
        return
    
    action = callback_query.data
    
    try:
        if action == "clear_users":
            users_col.delete_many({})
            await callback_query.message.edit_text("✅ Users collection cleared.")
        
        elif action == "clear_admins":
            admins_col.delete_many({})
            await callback_query.message.edit_text("✅ Admins collection cleared.")
        
        elif action == "clear_stocks":
            stocks = list(stocks_col.find())
            for stock in stocks:
                try:
                    os.remove(stock["file_path"])
                except:
                    pass
            stocks_col.delete_many({})
            await callback_query.message.edit_text("✅ Stocks collection cleared.")
        
        elif action == "clear_redeem_keys":
            redeem_keys_col.delete_many({})
            await callback_query.message.edit_text("✅ Redeem keys cleared.")
        
        elif action == "clear_feedback":
            feedback_col.delete_many({})
            await callback_query.message.edit_text("✅ Feedback cleared.")
        
        elif action == "clear_user_redemptions":
            user_redemptions_col.delete_many({})
            await callback_query.message.edit_text("✅ User redemptions cleared.")
        
        elif action == "clear_banned":
            banned_users_col.delete_many({})
            await callback_query.message.edit_text("✅ Banned users cleared.")
        
        elif action == "clear_all_data":
            # Delete stock files
            stocks = list(stocks_col.find())
            for stock in stocks:
                try:
                    os.remove(stock["file_path"])
                except:
                    pass
            
            # Clear all collections
            users_col.delete_many({})
            admins_col.delete_many({})
            stocks_col.delete_many({})
            redeem_keys_col.delete_many({})
            feedback_col.delete_many({})
            user_redemptions_col.delete_many({})
            banned_users_col.delete_many({})
            giveaway_stats_col.delete_many({})
            
            await callback_query.message.edit_text("✅ All database collections cleared!")
            
    except Exception as e:
        logger.error(f"Error clearing database: {e}")
        await callback_query.answer("Error occurred!", show_alert=True)

# Add admin command
@app.on_message(filters.command("add_admin") & owner_filter & filters.private)
async def add_admin_command(client, message: Message):
    if len(message.command) < 2:
        await message.reply_text("❌ Usage: /add_admin USER_ID")
        return
    
    try:
        admin_id = int(message.command[1])
        
        # Check if user exists
        user = users_col.find_one({"user_id": admin_id})
        if not user:
            await message.reply_text("❌ User not found in database. User needs to start the bot first.")
            return
        
        try:
            admins_col.insert_one({
                "admin_id": admin_id,
                "added_at": datetime.now(),
                "added_by": message.from_user.id,
                "added_by_username": message.from_user.username or "N/A"
            })
            
            # Notify new admin
            try:
                await client.send_message(
                    admin_id,
                    f"🎉 **You've been promoted to Admin!**\n\n"
                    f"You now have access to admin commands.\n"
                    f"Use /start to see available commands."
                )
            except:
                pass
            
            await message.reply_text(f"✅ User `{admin_id}` added as admin!")
            
        except DuplicateKeyError:
            await message.reply_text("❌ User is already an admin.")
            
    except ValueError:
        await message.reply_text("❌ Invalid user ID.")
    except Exception as e:
        logger.error(f"Error adding admin: {e}")
        await message.reply_text("❌ An error occurred.")

# Remove admin command
@app.on_message(filters.command("rmv_admin") & owner_filter & filters.private)
async def rmv_admin_command(client, message: Message):
    if len(message.command) < 2:
        await message.reply_text("❌ Usage: /rmv_admin USER_ID")
        return
    
    try:
        admin_id = int(message.command[1])
        
        if admin_id == OWNER_ID:
            await message.reply_text("❌ Cannot remove owner!")
            return
        
        result = admins_col.delete_one({"admin_id": admin_id})
        
        if result.deleted_count > 0:
            # Notify removed admin
            try:
                await client.send_message(
                    admin_id,
                    f"⚠️ **You have been removed as admin.**\n\n"
                    f"Your admin privileges have been revoked."
                )
            except:
                pass
            
            await message.reply_text(f"✅ User `{admin_id}` removed from admins.")
        else:
            await message.reply_text("❌ User is not an admin.")
            
    except ValueError:
        await message.reply_text("❌ Invalid user ID.")
    except Exception as e:
        logger.error(f"Error removing admin: {e}")
        await message.reply_text("❌ An error occurred.")

# See admins command
@app.on_message(filters.command("see_admins") & owner_filter & filters.private)
async def see_admins_command(client, message: Message):
    try:
        admins = list(admins_col.find())
        
        response = "👑 **Admin List**\n\n"
        response += f"**Owner:** `{OWNER_ID}`\n\n"
        
        if admins:
            response += "**Admins:**\n"
            for i, admin in enumerate(admins, 1):
                try:
                    user_info = await app.get_users(admin['admin_id'])
                    username = f"@{user_info.username}" if user_info.username else "No username"
                    response += f"{i}. `{admin['admin_id']}` - {username}\n"
                    response += f"   Added: {admin['added_at'].strftime('%Y-%m-%d %H:%M')}\n\n"
                except:
                    response += f"{i}. `{admin['admin_id']}` - Unknown user\n\n"
        else:
            response += "**No other admins.**"
        
        await message.reply_text(response)
        
    except Exception as e:
        logger.error(f"Error viewing admins: {e}")
        await message.reply_text("❌ An error occurred.")

# Restart command
@app.on_message(filters.command("restart") & owner_filter & filters.private)
async def restart_command(client, message: Message):
    try:
        await message.reply_text("🔄 **Restarting bot...**\n\nPlease wait a moment.")
        
        # Close connections
        mongo_client.close()
        
        # Restart
        os.execl(sys.executable, sys.executable, *sys.argv)
    except Exception as e:
        logger.error(f"Error restarting: {e}")
        await message.reply_text("❌ Restart failed!")



if __name__ == "__main__":
    logger.info("Starting GenZ Giveaway Bot...")
    app.run()
