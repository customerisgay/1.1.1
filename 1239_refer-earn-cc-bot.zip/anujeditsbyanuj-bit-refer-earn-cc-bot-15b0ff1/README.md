# 🎰 Telegram Refer & Earn Bot — CC Withdrawal System

A high-performance, feature-rich Telegram Refer & Earn bot built with Python, `python-telegram-bot`, and `MongoDB` (Async PyMongo). Users can refer friends to earn credits, and redeem those credits for Credit Cards (CC) stocked by admins in the pool.

## ✨ Features

- **👥 Referral System**: Generate unique referral links (`https://t.me/bot?start=USER_ID`). Automatically rewards referrers upon successful join with self-referral protection.
- **📢 Force Join Verification**: Enforces channel subscription for Public (`@channel`) and Private channels before allowing bot access. Also supports optional "Without-Force" channels.
- **💳 Credit Card (CC) Withdrawal**: Users redeem credits for CCs from the admin-stocked pool with automatic balance deduction.
- **🎨 Custom Emoji Rendering**: Native Telegram custom emoji rendering (`<tg-emoji emoji-id="...">`) across messages and inline buttons.
- **🛡️ Admin Panel (`/admin`)**:
  - ➕ Add CC stock (Single or Bulk)
  - 📢 Broadcast system (Text, Media, with anti-flood controls)
  - 💰 Set Refer Amount & Withdraw Limits
  - 📺 Channel Management (Public, Private, Without-Force)
  - 👤 User Balance Management
  - 🎨 Custom Emoji Configurator
  - 📊 Real-time Bot Statistics
- **⚡ In-Memory Caching**: Ultra-fast response times (<50ms) using in-memory settings & channel caching.
- **🚀 Auto Admin Restart Alerts**: Notifies admins via Telegram PM whenever the bot starts or restarts.

---

## 🛠️ Project Structure

```text
busy-lavoisier/
├── bot.py                # Main entry point & Application builder
├── config.py             # Bot token, MongoDB URI, Admin IDs
├── database.py           # PyMongo Async database operations & caching
├── handlers/
│   ├── start.py          # /start command, referrals, force join
│   ├── admin.py          # /admin control panel & input handlers
│   ├── withdraw.py       # CC withdrawal logic
│   └── broadcast.py      # Broadcast system
└── helpers/
    ├── emoji_utils.py    # Custom emoji formatter
    ├── force_join.py     # Channel membership checker
    └── keyboards.py      # Inline keyboard builders & styles
```

---

## 🚀 Installation & Local Setup

1. **Clone the repository**:
   ```bash
   git clone <YOUR_GITHUB_REPO_URL>
   cd busy-lavoisier
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure settings**:
   Edit `config.py` with your Bot Token, MongoDB URI, and Admin User IDs.

4. **Run the bot**:
   ```bash
   python bot.py
   ```

---

## 🌐 VPS Deployment (PM2 or Systemd)

```bash
# Clone on VPS
git clone <YOUR_GITHUB_REPO_URL>
cd busy-lavoisier

# Install Python & Dependencies
sudo apt update && sudo apt install python3 python3-pip -y
pip3 install -r requirements.txt

# Run with PM2
sudo apt install npm -y && sudo npm install -g pm2
pm2 start bot.py --name "refer-earn-bot" --interpreter python3
pm2 save
pm2 startup
```
