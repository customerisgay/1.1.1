import asyncio
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from telegram.error import TelegramError, Forbidden
import database
from helpers import keyboards, emoji_utils
import config

PENDING_BROADCAST = {}

def is_admin(user_id: int) -> bool:
    return user_id in config.ADMIN_IDS

async def admin_broadcast_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not is_admin(query.from_user.id):
        await query.answer("Unauthorized", show_alert=True)
        return
        
    PENDING_BROADCAST[query.from_user.id] = True
    
    text = (
        "📢 <b>Broadcast Message</b>\n\n"
        "Send the message (text, photo, video, etc.) you want to broadcast to all users now.\n\n"
        "Type /cancel to cancel."
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_admin_kb(), parse_mode=ParseMode.HTML)

async def process_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    if not message or not message.from_user:
        return
    user_id = message.from_user.id
    if not is_admin(user_id):
        return
        
    if not PENDING_BROADCAST.get(user_id):
        return
        
    PENDING_BROADCAST[user_id] = False
    
    all_users = await database.get_all_users()
    total = len(all_users)
    
    status_msg = await message.reply_text(f"⏳ Broadcasting to {total} users...")
    
    success = 0
    failed = 0
    
    for u in all_users:
        uid = u["user_id"]
        try:
            await context.bot.copy_message(chat_id=uid, from_chat_id=message.chat_id, message_id=message.message_id)
            success += 1
            await asyncio.sleep(0.05)
        except Forbidden:
            failed += 1
        except TelegramError:
            failed += 1
        except Exception:
            failed += 1
            
    check_e = await emoji_utils.get_emoji("check")
    await status_msg.edit_text(
        f"{check_e} <b>Broadcast Completed!</b>\n\n"
        f"✅ <b>Successfully sent:</b> {success}\n"
        f"❌ <b>Failed/Blocked:</b> {failed}\n"
        f"👥 <b>Total target:</b> {total}",
        reply_markup=keyboards.back_to_admin_kb(),
        parse_mode=ParseMode.HTML
    )

async def cancel_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if PENDING_BROADCAST.get(user_id):
        PENDING_BROADCAST[user_id] = False
        await update.message.reply_text("❌ Broadcast cancelled.", reply_markup=keyboards.back_to_admin_kb())
