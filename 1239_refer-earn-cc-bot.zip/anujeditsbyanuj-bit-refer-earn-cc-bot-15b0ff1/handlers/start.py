from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
import database
from helpers import force_join, keyboards, emoji_utils
import config

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id
    
    # Check referral argument /start 12345
    referrer_id = None
    if context.args and len(context.args) > 0 and context.args[0].isdigit():
        ref_candidate = int(context.args[0])
        if ref_candidate != user_id:
            referrer_id = ref_candidate

    existing_user = await database.get_user(user_id)
    if not existing_user:
        await database.add_user(
            user_id=user_id,
            username=user.username or "",
            first_name=user.first_name or "User",
            referred_by=referrer_id
        )
        if referrer_id:
            ref_user = await database.get_user(referrer_id)
            if ref_user:
                await database.increment_referral(referrer_id)
                try:
                    ref_amount = await database.get_setting("refer_amount", config.DEFAULT_REFER_AMOUNT)
                    coin_e = emoji_utils.get_emoji("coin")
                    party_e = emoji_utils.get_emoji("gift")
                    await context.bot.send_message(
                        chat_id=referrer_id,
                        text=(
                            f"{party_e} <b>New Referral Joined!</b>\n\n"
                            f"User <a href='tg://user?id={user_id}'>{user.first_name}</a> joined using your referral link!\n"
                            f"{coin_e} <b>+{ref_amount} Credits</b> added to your balance."
                        ),
                        parse_mode=ParseMode.HTML
                    )
                except Exception:
                    pass

    # Check force join
    unjoined = await force_join.get_unjoined_channels(context.bot, user_id)
    if unjoined:
        warn_e = emoji_utils.get_emoji("warn")
        link_e = emoji_utils.get_emoji("link")
        refresh_e = emoji_utils.get_emoji("refresh")
        
        all_channels = await database.get_channels()
        kb = keyboards.force_join_kb(all_channels, user_id)
        
        text = (
            f"{warn_e} <b>Must Join Our Channels First!</b>\n\n"
            f"Please join all the mandatory channels below to access the bot and start earning CCs!\n\n"
            f"{link_e} After joining, click the {refresh_e} <b>Check Joined</b> button below."
        )
        await update.message.reply_text(text, reply_markup=kb, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
        return

    await send_main_welcome(update, context, user)

async def send_main_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE, user):
    user_db = await database.get_user(user.id)
    balance = user_db.get("balance", 0.0) if user_db else 0.0
    referrals = user_db.get("total_referrals", 0) if user_db else 0
    
    bot_info = await context.bot.get_me()
    ref_link = f"https://t.me/{bot_info.username}?start={user.id}"
    
    refer_amt = await database.get_setting("refer_amount", config.DEFAULT_REFER_AMOUNT)
    withdraw_amt = await database.get_setting("withdraw_amount", config.DEFAULT_WITHDRAW_AMOUNT)
    
    welcome_e = emoji_utils.get_emoji("welcome")
    fire_e = emoji_utils.get_emoji("fire")
    coin_e = emoji_utils.get_emoji("coin")
    user_e = emoji_utils.get_emoji("user")
    gift_e = emoji_utils.get_emoji("gift")
    card_e = emoji_utils.get_emoji("card")
    link_e = emoji_utils.get_emoji("link")
    
    text = (
        f"{welcome_e} <b>Welcome, {user.first_name}!</b>\n\n"
        f"{fire_e} <b>Earn Free Credit Cards (CC) by Referring Friends!</b>\n\n"
        f"{coin_e} <b>Your Balance:</b> {balance} Credits\n"
        f"{user_e} <b>Total Referrals:</b> {referrals}\n"
        f"{gift_e} <b>Per Referral:</b> {refer_amt} Credits\n"
        f"{card_e} <b>Min Withdraw:</b> {withdraw_amt} Credits = 1 CC\n\n"
        f"{link_e} <b>Your Referral Link:</b>\n<code>{ref_link}</code>"
    )
    
    if update.callback_query:
        try:
            await update.callback_query.message.edit_text(text, reply_markup=keyboards.main_menu_kb(), parse_mode=ParseMode.HTML, disable_web_page_preview=True)
        except Exception:
            await context.bot.send_message(chat_id=user.id, text=text, reply_markup=keyboards.main_menu_kb(), parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    else:
        await update.message.reply_text(text, reply_markup=keyboards.main_menu_kb(), parse_mode=ParseMode.HTML, disable_web_page_preview=True)

async def check_joined_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    unjoined = await force_join.get_unjoined_channels(context.bot, user_id)
    if unjoined:
        await query.answer("❌ You haven't joined all required channels yet!", show_alert=True)
        return
        
    await send_main_welcome(update, context, query.from_user)

async def my_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user
    user_db = await database.get_user(user.id)
    balance = user_db.get("balance", 0.0) if user_db else 0.0
    referrals = user_db.get("total_referrals", 0) if user_db else 0
    
    stats_e = emoji_utils.get_emoji("stats")
    coin_e = emoji_utils.get_emoji("coin")
    user_e = emoji_utils.get_emoji("user")
    
    text = (
        f"{stats_e} <b>Your Account Statistics</b>\n\n"
        f"{user_e} <b>User ID:</b> <code>{user.id}</code>\n"
        f"{coin_e} <b>Balance:</b> {balance} Credits\n"
        f"{user_e} <b>Total Referrals:</b> {referrals}\n"
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_main_kb(), parse_mode=ParseMode.HTML)

async def ref_link_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    bot_info = await context.bot.get_me()
    ref_link = f"https://t.me/{bot_info.username}?start={query.from_user.id}"
    refer_amt = await database.get_setting("refer_amount", config.DEFAULT_REFER_AMOUNT)
    
    link_e = emoji_utils.get_emoji("link")
    
    text = (
        f"{link_e} <b>Your Exclusive Referral Link</b>\n\n"
        f"Share this link with your friends to earn {refer_amt} credits per join!\n\n"
        f"<code>{ref_link}</code>"
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_main_kb(), parse_mode=ParseMode.HTML, disable_web_page_preview=True)

async def how_it_works_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    refer_amt = await database.get_setting("refer_amount", config.DEFAULT_REFER_AMOUNT)
    withdraw_amt = await database.get_setting("withdraw_amount", config.DEFAULT_WITHDRAW_AMOUNT)
    
    sparkles_e = emoji_utils.get_emoji("sparkles")
    
    text = (
        f"{sparkles_e} <b>How Refer & Earn Works:</b>\n\n"
        f"1️⃣ Share your referral link with friends.\n"
        f"2️⃣ When your friend joins via your link, you get <b>+{refer_amt} Credits</b>.\n"
        f"3️⃣ When you reach <b>{withdraw_amt} Credits</b>, click <b>💳 Withdraw CC</b>.\n"
        f"4️⃣ You will instantly receive a Credit Card from our active stock!\n"
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_main_kb(), parse_mode=ParseMode.HTML)

async def main_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await send_main_welcome(update, context, query.from_user)
