from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
import database
from helpers import keyboards, emoji_utils
import config

ADMIN_STATE = {}

def is_admin(user_id: int) -> bool:
    return user_id in config.ADMIN_IDS

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await send_admin_panel(update, context)

async def send_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    shield_e = emoji_utils.get_emoji("shield")
    stats_e = emoji_utils.get_emoji("stats")
    
    total_users = await database.get_total_users_count()
    available_cc = await database.get_available_cc_count()
    total_cc = await database.get_total_cc_count()
    refer_amt = await database.get_setting("refer_amount", config.DEFAULT_REFER_AMOUNT)
    withdraw_amt = await database.get_setting("withdraw_amount", config.DEFAULT_WITHDRAW_AMOUNT)
    
    text = (
        f"{shield_e} <b>Admin Control Panel</b>\n\n"
        f"{stats_e} <b>Quick Overview:</b>\n"
        f"• Total Users: <code>{total_users}</code>\n"
        f"• CC Stock: <code>{available_cc} / {total_cc}</code>\n"
        f"• Referral Reward: <code>{refer_amt} Credits</code>\n"
        f"• Withdraw Limit: <code>{withdraw_amt} Credits</code>\n"
    )
    
    if update.callback_query:
        await update.callback_query.message.edit_text(text, reply_markup=keyboards.admin_panel_kb(), parse_mode=ParseMode.HTML)
    else:
        await update.message.reply_text(text, reply_markup=keyboards.admin_panel_kb(), parse_mode=ParseMode.HTML)

async def admin_home_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    ADMIN_STATE[query.from_user.id] = None
    await send_admin_panel(update, context)

async def close_admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    await query.message.delete()

# --- STATS ---
async def admin_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    total_users = await database.get_total_users_count()
    available_cc = await database.get_available_cc_count()
    total_cc = await database.get_total_cc_count()
    total_withdrawals = await database.get_total_withdrawals_count()
    
    text = (
        f"📊 <b>Detailed Bot Statistics</b>\n\n"
        f"👥 <b>Total Users:</b> {total_users}\n"
        f"💳 <b>Available CC Stock:</b> {available_cc}\n"
        f"📦 <b>Total CC Stock Added:</b> {total_cc}\n"
        f"✅ <b>Total CCs Claimed:</b> {total_withdrawals}\n"
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_admin_kb(), parse_mode=ParseMode.HTML)

# --- ADD CC ---
async def admin_add_cc_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    ADMIN_STATE[query.from_user.id] = "add_cc"
    text = (
        "💳 <b>Add Credit Cards (CC)</b>\n\n"
        "Send the CC details now.\n"
        "You can send single CC or multiple CCs (one per line):\n\n"
        "<code>4532XXXXXXXXXXXX|MM|YY|CVV</code>\n"
        "<code>4000XXXXXXXXXXXX|MM|YY|CVV</code>\n\n"
        "Type /cancel to abort."
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_admin_kb(), parse_mode=ParseMode.HTML)

# --- SET REFER AMOUNT ---
async def admin_set_refer_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    ADMIN_STATE[query.from_user.id] = "set_refer"
    curr = await database.get_setting("refer_amount", config.DEFAULT_REFER_AMOUNT)
    text = (
        f"💰 <b>Set Referral Credit Amount</b>\n\n"
        f"Current amount: <code>{curr} Credits</code> per referral.\n\n"
        f"Send the new amount as a number (e.g. 10)."
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_admin_kb(), parse_mode=ParseMode.HTML)

# --- SET WITHDRAW AMOUNT ---
async def admin_set_withdraw_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    ADMIN_STATE[query.from_user.id] = "set_withdraw"
    curr = await database.get_setting("withdraw_amount", config.DEFAULT_WITHDRAW_AMOUNT)
    text = (
        f"💳 <b>Set Minimum Withdraw Amount</b>\n\n"
        f"Current amount: <code>{curr} Credits</code> per CC.\n\n"
        f"Send the new amount as a number (e.g. 50)."
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_admin_kb(), parse_mode=ParseMode.HTML)

# --- ADD USER BALANCE ---
async def admin_add_balance_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    ADMIN_STATE[query.from_user.id] = "add_balance"
    text = (
        "👤 <b>Add User Balance</b>\n\n"
        "Send the User ID and Amount in this format:\n\n"
        "<code>USER_ID AMOUNT</code>\n"
        "Example: <code>1234567890 25</code>"
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_admin_kb(), parse_mode=ParseMode.HTML)

# --- CUSTOM EMOJIS ---
async def admin_emojis_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    ADMIN_STATE[query.from_user.id] = "set_emoji"
    text = (
        "🎨 <b>Set Custom Emoji IDs</b>\n\n"
        "Send the key and Custom Emoji ID in this format:\n\n"
        "<code>KEY EMOJI_ID</code>\n\n"
        "Available keys: <code>welcome</code>, <code>fire</code>, <code>card</code>, <code>coin</code>, <code>star</code>, <code>warn</code>, <code>check</code>, <code>link</code>, <code>gift</code>, <code>sparkles</code>, <code>shield</code>\n\n"
        "Example: <code>welcome 5316743524706698146</code>"
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_admin_kb(), parse_mode=ParseMode.HTML)

# --- CHANNEL MANAGEMENT ---
async def admin_channels_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    channels = await database.get_channels()
    text = (
        "📺 <b>Channel Management</b>\n\n"
        "Manage channels for force join check and promotional links."
    )
    await query.message.edit_text(text, reply_markup=keyboards.channel_manage_kb(channels), parse_mode=ParseMode.HTML)

async def add_ch_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return
    ch_type = query.data.replace("add_ch_", "")
    ADMIN_STATE[query.from_user.id] = f"add_ch_{ch_type}"
    text = (
        f"➕ <b>Add Channel ({ch_type})</b>\n\n"
        f"Send details in format:\n"
        f"<code>CHANNEL_ID|TITLE|INVITE_LINK</code>\n\n"
        f"Example Public Force: <code>@mychannel|My Public Channel|https://t.me/mychannel</code>\n"
        f"Example Private Force: <code>-1001234567890|My Private Channel|https://t.me/+AbCdEfGhIjK</code>"
    )
    await query.message.edit_text(text, reply_markup=keyboards.back_to_admin_kb(), parse_mode=ParseMode.HTML)

async def remove_ch_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not is_admin(query.from_user.id):
        return
    ch_id = query.data.replace("remove_ch_", "")
    await database.remove_channel(ch_id)
    await query.answer("✅ Channel removed!", show_alert=True)
    channels = await database.get_channels()
    await query.message.edit_text("📺 <b>Channel Management</b>", reply_markup=keyboards.channel_manage_kb(channels), parse_mode=ParseMode.HTML)

# --- PROCESS ADMIN TEXT INPUT ---
async def process_admin_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    if not message or not message.from_user:
        return
    user_id = message.from_user.id
    if not is_admin(user_id):
        return
        
    state = ADMIN_STATE.get(user_id)
    if not state:
        return
        
    text_input = message.text.strip() if message.text else ""
    
    if state == "add_cc":
        ccs = text_input.split("\n")
        added_count = await database.add_bulk_cc(ccs, user_id)
        ADMIN_STATE[user_id] = None
        await message.reply_text(
            f"✅ <b>Successfully added {added_count} CC(s) to pool!</b>",
            reply_markup=keyboards.back_to_admin_kb(),
            parse_mode=ParseMode.HTML
        )
        
    elif state == "set_refer":
        try:
            val = float(text_input)
            await database.set_setting("refer_amount", val)
            ADMIN_STATE[user_id] = None
            await message.reply_text(
                f"✅ Referral amount updated to <b>{val} Credits</b>!",
                reply_markup=keyboards.back_to_admin_kb(),
                parse_mode=ParseMode.HTML
            )
        except ValueError:
            await message.reply_text("❌ Please enter a valid number.")

    elif state == "set_withdraw":
        try:
            val = float(text_input)
            await database.set_setting("withdraw_amount", val)
            ADMIN_STATE[user_id] = None
            await message.reply_text(
                f"✅ Withdraw amount updated to <b>{val} Credits</b>!",
                reply_markup=keyboards.back_to_admin_kb(),
                parse_mode=ParseMode.HTML
            )
        except ValueError:
            await message.reply_text("❌ Please enter a valid number.")

    elif state == "add_balance":
        try:
            parts = text_input.split()
            target_id = int(parts[0])
            amt = float(parts[1])
            await database.update_balance(target_id, amt)
            ADMIN_STATE[user_id] = None
            await message.reply_text(
                f"✅ Added <b>{amt} Credits</b> to user <code>{target_id}</code>!",
                reply_markup=keyboards.back_to_admin_kb(),
                parse_mode=ParseMode.HTML
            )
        except Exception:
            await message.reply_text("❌ Format error! Use: <code>USER_ID AMOUNT</code>", parse_mode=ParseMode.HTML)

    elif state == "set_emoji":
        try:
            parts = text_input.split()
            key = parts[0].lower()
            emoji_id = parts[1]
            await database.set_setting(f"emoji_{key}", emoji_id)
            ADMIN_STATE[user_id] = None
            await message.reply_text(
                f"✅ Custom Emoji for <code>{key}</code> set to ID <code>{emoji_id}</code>!",
                reply_markup=keyboards.back_to_admin_kb(),
                parse_mode=ParseMode.HTML
            )
        except Exception:
            await message.reply_text("❌ Format error! Use: <code>KEY EMOJI_ID</code>", parse_mode=ParseMode.HTML)

    elif state.startswith("add_ch_"):
        ch_type = state.replace("add_ch_", "")
        try:
            parts = text_input.split("|")
            ch_id = parts[0].strip()
            title = parts[1].strip()
            invite_link = parts[2].strip()
            await database.add_channel(ch_id, title, invite_link, ch_type)
            ADMIN_STATE[user_id] = None
            await message.reply_text(
                f"✅ Channel <b>{title}</b> added as <code>{ch_type}</code>!",
                reply_markup=keyboards.back_to_admin_kb(),
                parse_mode=ParseMode.HTML
            )
        except Exception:
            await message.reply_text("❌ Format error! Use: <code>CHANNEL_ID|TITLE|INVITE_LINK</code>", parse_mode=ParseMode.HTML)
