from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
import database
from helpers import keyboards, emoji_utils
import config

async def withdraw_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    user_db = await database.get_user(user_id)
    
    if not user_db:
        await query.answer("❌ User data not found. Please /start the bot.", show_alert=True)
        return
        
    balance = float(user_db.get("balance", 0.0))
    min_withdraw = float(await database.get_setting("withdraw_amount", config.DEFAULT_WITHDRAW_AMOUNT))
    
    card_e = emoji_utils.get_emoji("card")
    check_e = emoji_utils.get_emoji("check")
    
    if balance < min_withdraw:
        await query.answer(
            f"❌ Insufficient Balance!\nYou need {min_withdraw} credits to withdraw 1 CC.\nYour Balance: {balance}",
            show_alert=True
        )
        return

    # Check CC availability
    available_cc = await database.get_available_cc_count()
    if available_cc <= 0:
        await query.answer("⚠️ CC Stock is currently empty! Admin will restock soon.", show_alert=True)
        return
        
    # Claim CC
    claimed_cc = await database.claim_cc(user_id)
    if not claimed_cc:
        await query.answer("⚠️ Unable to claim CC right now. Please try again.", show_alert=True)
        return
        
    # Deduct balance
    await database.update_balance(user_id, -min_withdraw)
    await database.add_withdrawal(user_id, claimed_cc, min_withdraw)
    
    new_user_db = await database.get_user(user_id)
    new_balance = new_user_db.get("balance", 0.0)
    
    text = (
        f"{check_e} <b>Withdrawal Successful!</b>\n\n"
        f"{card_e} <b>Your Credit Card Details:</b>\n"
        f"<code>{claimed_cc}</code>\n\n"
        f"💰 <b>Amount Deducted:</b> {min_withdraw} Credits\n"
        f"📉 <b>Remaining Balance:</b> {new_balance} Credits\n\n"
        f"<i>Thank you for using our bot! Refer more friends to get more CCs!</i>"
    )
    
    await query.message.edit_text(text, reply_markup=keyboards.back_to_main_kb(), parse_mode=ParseMode.HTML)
