import logging
import sys
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from telegram.constants import ParseMode
import config
import database
from handlers import start, withdraw, admin, broadcast
from helpers import emoji_utils

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

async def post_init(app):
    await database.init_cache()
    logger.info("Database cache initialized successfully!")
    
    rocket_e = emoji_utils.get_emoji("rocket")
    check_e = emoji_utils.get_emoji("check")
    text = (
        f"{rocket_e} <b>Bot Restarted & Online!</b>\n\n"
        f"{check_e} All services, custom emojis, and database cache initialized successfully."
    )
    
    for admin_id in config.ADMIN_IDS:
        try:
            await app.bot.send_message(chat_id=admin_id, text=text, parse_mode=ParseMode.HTML)
        except Exception as e:
            logger.warning(f"Could not notify admin {admin_id}: {e}")

def main():
    print("Starting Telegram Refer & Earn Bot (Optimized Engine)...")
    app = ApplicationBuilder().token(config.BOT_TOKEN).post_init(post_init).build()

    # Commands
    app.add_handler(CommandHandler("start", start.start_handler))
    app.add_handler(CommandHandler("admin", admin.admin_command))
    app.add_handler(CommandHandler("cancel", broadcast.cancel_action))

    # Callbacks
    app.add_handler(CallbackQueryHandler(start.check_joined_callback, pattern=r"^check_joined_"))
    app.add_handler(CallbackQueryHandler(start.my_stats_callback, pattern=r"^my_stats$"))
    app.add_handler(CallbackQueryHandler(start.ref_link_callback, pattern=r"^ref_link$"))
    app.add_handler(CallbackQueryHandler(start.how_it_works_callback, pattern=r"^how_it_works$"))
    app.add_handler(CallbackQueryHandler(start.main_menu_callback, pattern=r"^main_menu$"))
    app.add_handler(CallbackQueryHandler(withdraw.withdraw_callback, pattern=r"^withdraw$"))

    # Admin Callbacks
    app.add_handler(CallbackQueryHandler(admin.admin_home_callback, pattern=r"^admin_home$"))
    app.add_handler(CallbackQueryHandler(admin.close_admin_callback, pattern=r"^close_admin$"))
    app.add_handler(CallbackQueryHandler(admin.admin_stats_callback, pattern=r"^admin_stats$"))
    app.add_handler(CallbackQueryHandler(admin.admin_add_cc_prompt, pattern=r"^admin_add_cc$"))
    app.add_handler(CallbackQueryHandler(admin.admin_set_refer_prompt, pattern=r"^admin_set_refer$"))
    app.add_handler(CallbackQueryHandler(admin.admin_set_withdraw_prompt, pattern=r"^admin_set_withdraw$"))
    app.add_handler(CallbackQueryHandler(admin.admin_add_balance_prompt, pattern=r"^admin_add_balance$"))
    app.add_handler(CallbackQueryHandler(admin.admin_emojis_prompt, pattern=r"^admin_emojis$"))
    app.add_handler(CallbackQueryHandler(admin.admin_channels_menu, pattern=r"^admin_channels$"))
    app.add_handler(CallbackQueryHandler(admin.add_ch_prompt, pattern=r"^add_ch_"))
    app.add_handler(CallbackQueryHandler(admin.remove_ch_callback, pattern=r"^remove_ch_"))
    app.add_handler(CallbackQueryHandler(broadcast.admin_broadcast_prompt, pattern=r"^admin_broadcast$"))

    # Message handlers for admin inputs & broadcasts
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE, admin.process_admin_input), group=1)
    app.add_handler(MessageHandler(~filters.COMMAND & filters.ChatType.PRIVATE, broadcast.process_broadcast), group=2)

    logger.info("Bot started successfully in Polling mode!")
    app.run_polling()

if __name__ == "__main__":
    main()
