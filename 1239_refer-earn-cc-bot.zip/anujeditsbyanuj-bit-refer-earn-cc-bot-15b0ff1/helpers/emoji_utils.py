import database

DEFAULT_EMOJIS = {
    "welcome": "👋",
    "fire": "🔥",
    "card": "💳",
    "coin": "💰",
    "star": "⭐️",
    "warn": "⚠️",
    "check": "✅",
    "cross": "❌",
    "link": "🔗",
    "gift": "🎁",
    "sparkles": "✨",
    "rocket": "🚀",
    "shield": "🛡",
    "user": "👤",
    "stats": "📊",
    "refresh": "🔄"
}

CUSTOM_EMOJI_IDS = {
    "welcome": "5316743524706698146",
    "fire": "5992053533443100269",
    "card": "5417932593423211389",
    "coin": "6129580190147288563",
    "star": "5787147833526193811",
    "warn": "6010250047155868475",
    "check": "5436116879364075945",
    "cross": "6129837604717208147",
    "link": "6242199485393409396",
    "gift": "5422607012489889076",
    "sparkles": "6127314294250940395",
    "rocket": "6255967054600345865",
    "shield": "6010152641592563109",
    "user": "5891207662678317861",
    "stats": "6260406328502522638",
    "refresh": "5978846612087114958"
}

def get_emoji(name: str) -> str:
    fallback = DEFAULT_EMOJIS.get(name, "✨")
    emoji_id = database.SETTINGS_CACHE.get(f"emoji_{name}")
    if not emoji_id:
        emoji_id = CUSTOM_EMOJI_IDS.get(name)
        
    if emoji_id and str(emoji_id).isdigit():
        return f'<tg-emoji emoji-id="{emoji_id}">{fallback}</tg-emoji>'
    return fallback
