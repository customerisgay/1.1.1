from telegram import Bot
from telegram.error import TelegramError
import database

async def get_unjoined_channels(bot: Bot, user_id: int):
    channels = await database.get_channels()
    unjoined = []
    
    for ch in channels:
        ch_type = ch.get("type", "public_force")
        if ch_type == "without_force":
            continue # Don't enforce check for without_force
            
        ch_id = ch["channel_id"]
        try:
            member = await bot.get_chat_member(chat_id=ch_id, user_id=user_id)
            if member.status in ["left", "kicked", "banned"]:
                unjoined.append(ch)
        except TelegramError:
            # If bot can't check, mark as unjoined so user can join link
            unjoined.append(ch)
        except Exception:
            unjoined.append(ch)
            
    return unjoined
