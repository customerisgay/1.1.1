from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from helpers import emoji_utils

EMOJI_IDS = emoji_utils.CUSTOM_EMOJI_IDS

def create_button(text: str, callback_data: str = None, url: str = None, style: str = None, emoji_key: str = None):
    kwargs = {}
    if callback_data:
        kwargs["callback_data"] = callback_data
    if url:
        kwargs["url"] = url
        
    api_kwargs = {}
    if style:
        api_kwargs["style"] = style
        
    if emoji_key and emoji_key in EMOJI_IDS:
        api_kwargs["icon_custom_emoji_id"] = EMOJI_IDS[emoji_key]
        
    if api_kwargs:
        kwargs["api_kwargs"] = api_kwargs
        
    return InlineKeyboardButton(text=text, **kwargs)

def main_menu_kb():
    return InlineKeyboardMarkup([
        [
            create_button("Withdraw CC", callback_data="withdraw", style="success", emoji_key="card"),
            create_button("My Stats", callback_data="my_stats", style="primary", emoji_key="stats")
        ],
        [
            create_button("Referral Link", callback_data="ref_link", style="primary", emoji_key="link"),
            create_button("How It Works", callback_data="how_it_works", style="primary", emoji_key="sparkles")
        ]
    ])

def force_join_kb(channels: list, user_id: int):
    buttons = []
    for idx, ch in enumerate(channels, 1):
        buttons.append([create_button("Join Channel", url=ch.get("invite_link", "https://t.me/"), style="primary", emoji_key="fire")])
    
    buttons.append([create_button("Check Joined", callback_data=f"check_joined_{user_id}", style="success", emoji_key="refresh")])
    return InlineKeyboardMarkup(buttons)

def admin_panel_kb():
    return InlineKeyboardMarkup([
        [
            create_button("Add CC Stock", callback_data="admin_add_cc", style="success", emoji_key="card"),
            create_button("Broadcast", callback_data="admin_broadcast", style="primary", emoji_key="rocket")
        ],
        [
            create_button("Channels", callback_data="admin_channels", style="primary", emoji_key="link"),
            create_button("Bot Stats", callback_data="admin_stats", style="primary", emoji_key="stats")
        ],
        [
            create_button("Set Refer Amount", callback_data="admin_set_refer", style="primary", emoji_key="coin"),
            create_button("Set Withdraw Amount", callback_data="admin_set_withdraw", style="primary", emoji_key="card")
        ],
        [
            create_button("Add User Balance", callback_data="admin_add_balance", style="primary", emoji_key="user"),
            create_button("Custom Emojis", callback_data="admin_emojis", style="primary", emoji_key="sparkles")
        ],
        [
            create_button("Close Panel", callback_data="close_admin", style="danger", emoji_key="cross")
        ]
    ])

def channel_manage_kb(channels: list):
    buttons = [
        [
            create_button("Add Public Force", callback_data="add_ch_public_force", style="success"),
            create_button("Add Private Force", callback_data="add_ch_private_force", style="success")
        ],
        [
            create_button("Add Without Force", callback_data="add_ch_without_force", style="primary")
        ]
    ]
    for ch in channels:
        ch_type = ch.get("type", "force")
        label = f"Remove: {ch.get('channel_id')} ({ch_type})"
        buttons.append([create_button(label, callback_data=f"remove_ch_{ch['channel_id']}", style="danger", emoji_key="cross")])
    
    buttons.append([create_button("Back to Admin", callback_data="admin_home", style="primary")])
    return InlineKeyboardMarkup(buttons)

def back_to_admin_kb():
    return InlineKeyboardMarkup([
        [create_button("Back to Admin Panel", callback_data="admin_home", style="primary")]
    ])

def back_to_main_kb():
    return InlineKeyboardMarkup([
        [create_button("Back to Menu", callback_data="main_menu", style="primary")]
    ])
