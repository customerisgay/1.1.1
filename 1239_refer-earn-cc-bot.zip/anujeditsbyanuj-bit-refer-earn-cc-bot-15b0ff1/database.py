import datetime
from pymongo import AsyncMongoClient
import config

client = AsyncMongoClient(config.MONGO_URI)
db = client["refer_earn_bot"]

users_col = db["users"]
channels_col = db["channels"]
cc_pool_col = db["cc_pool"]
withdrawals_col = db["withdrawals"]
settings_col = db["settings"]

# --- IN-MEMORY CACHE FOR BLAZING FAST RESPONSE TIMES (<10ms) ---
SETTINGS_CACHE = {}
CHANNELS_CACHE = None

async def init_cache():
    global SETTINGS_CACHE, CHANNELS_CACHE
    try:
        settings = await settings_col.find({}).to_list(length=None)
        for s in settings:
            SETTINGS_CACHE[s["key"]] = s["value"]
            
        CHANNELS_CACHE = await channels_col.find({}).to_list(length=None)
    except Exception as e:
        print(f"Cache init warning: {e}")

# --- USER OPERATIONS ---
async def get_user(user_id: int):
    return await users_col.find_one({"user_id": user_id})

async def add_user(user_id: int, username: str, first_name: str, referred_by: int = None):
    doc = {
        "user_id": user_id,
        "username": username,
        "first_name": first_name,
        "balance": 0.0,
        "total_referrals": 0,
        "referred_by": referred_by,
        "joined_date": datetime.datetime.utcnow()
    }
    await users_col.update_one(
        {"user_id": user_id},
        {"$setOnInsert": doc},
        upsert=True
    )
    return doc

async def update_balance(user_id: int, amount: float):
    await users_col.update_one(
        {"user_id": user_id},
        {"$inc": {"balance": amount}}
    )

async def increment_referral(user_id: int):
    refer_amount = float(await get_setting("refer_amount", config.DEFAULT_REFER_AMOUNT))
    await users_col.update_one(
        {"user_id": user_id},
        {
            "$inc": {
                "total_referrals": 1,
                "balance": refer_amount
            }
        }
    )

async def get_all_users():
    cursor = users_col.find({})
    return await cursor.to_list(length=None)

async def get_total_users_count():
    return await users_col.count_documents({})

# --- CHANNEL OPERATIONS ---
async def add_channel(channel_id: str, title: str, invite_link: str, channel_type: str):
    global CHANNELS_CACHE
    await channels_col.update_one(
        {"channel_id": str(channel_id)},
        {"$set": {
            "channel_id": str(channel_id),
            "title": title,
            "invite_link": invite_link,
            "type": channel_type
        }},
        upsert=True
    )
    CHANNELS_CACHE = await channels_col.find({}).to_list(length=None)

async def remove_channel(channel_id: str):
    global CHANNELS_CACHE
    await channels_col.delete_one({"channel_id": str(channel_id)})
    CHANNELS_CACHE = await channels_col.find({}).to_list(length=None)

async def get_channels():
    global CHANNELS_CACHE
    if CHANNELS_CACHE is None:
        CHANNELS_CACHE = await channels_col.find({}).to_list(length=None)
    return CHANNELS_CACHE

# --- CC POOL OPERATIONS ---
async def add_bulk_cc(cc_list: list[str], added_by: int):
    docs = []
    for cc in cc_list:
        if cc.strip():
            docs.append({
                "cc_data": cc.strip(),
                "added_by": added_by,
                "added_date": datetime.datetime.utcnow(),
                "claimed_by": None,
                "claimed_date": None,
                "is_claimed": False
            })
    if docs:
        await cc_pool_col.insert_many(docs)
    return len(docs)

async def get_available_cc_count():
    return await cc_pool_col.count_documents({"is_claimed": False})

async def get_total_cc_count():
    return await cc_pool_col.count_documents({})

async def claim_cc(user_id: int):
    cc = await cc_pool_col.find_one_and_update(
        {"is_claimed": False},
        {"$set": {
            "is_claimed": True,
            "claimed_by": user_id,
            "claimed_date": datetime.datetime.utcnow()
        }}
    )
    if not cc:
        return None
    return cc["cc_data"]

# --- WITHDRAWAL OPERATIONS ---
async def add_withdrawal(user_id: int, cc_data: str, amount_spent: float):
    doc = {
        "user_id": user_id,
        "cc_data": cc_data,
        "amount_spent": amount_spent,
        "timestamp": datetime.datetime.utcnow()
    }
    await withdrawals_col.insert_one(doc)

async def get_total_withdrawals_count():
    return await withdrawals_col.count_documents({})

# --- FAST CACHED SETTINGS OPERATIONS ---
async def get_setting(key: str, default=None):
    if key in SETTINGS_CACHE:
        return SETTINGS_CACHE[key]
    res = await settings_col.find_one({"key": key})
    if res:
        SETTINGS_CACHE[key] = res["value"]
        return res["value"]
    return default

async def set_setting(key: str, value):
    SETTINGS_CACHE[key] = value
    await settings_col.update_one(
        {"key": key},
        {"$set": {"key": key, "value": value}},
        upsert=True
    )
