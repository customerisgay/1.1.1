BOT_TOKEN = "8946367857:AAGpDdtG2ZFMG2HeZh-Ve_Ey13pyW-_xVaU"
MONGO_URI = "mongodb+srv://narutouzumaki9tail786786_db_user:kaByy8uKMXMFjv2b@cluster0.7uy4mvt.mongodb.net/?appName=Cluster0"
ADMIN_IDS = [8730393744]

DEFAULT_REFER_AMOUNT = 5.0
DEFAULT_WITHDRAW_AMOUNT = 50.0
