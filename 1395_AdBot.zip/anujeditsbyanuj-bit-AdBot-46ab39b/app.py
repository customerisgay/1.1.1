# """
# AdBot Streamlit Frontend — Full Redesign v3
# Features:
#   - Animated particle background
#   - Platform-native post preview cards (Instagram, Facebook, Reddit, Telegram, Discord, LinkedIn)
#   - Auto-generate image for Instagram; optional for others
#   - Per-platform text & image regeneration with feedback
#   - Post to All / Post to This Platform only
#   - Posted Ads section with real engagement metrics
#   - Low-engagement suggestions
#   - Chat history sidebar

# Run backend first:  uvicorn main:app --reload --port 8000
# Run frontend:       streamlit run app.py
# """

# import os, requests, time
# import streamlit as st
# from datetime import datetime
# from dotenv import load_dotenv

# load_dotenv()
# BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")

# # ── Page config ───────────────────────────────────────────────────────────────
# st.set_page_config(
#     page_title="AdBot — AI Ad Platform",
#     page_icon="⚡",
#     layout="wide",
#     initial_sidebar_state="expanded"
# )

# # ── FULL CSS + Animated Background ───────────────────────────────────────────
# st.markdown("""
# <style>
# @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=Space+Mono:wght@400;700&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&display=swap');

# :root {
#   --bg:        #060810;
#   --surface:   #0c0f1a;
#   --card:      #111422;
#   --card2:     #161b2e;
#   --border:    #1c2238;
#   --border2:   #242d47;
#   --accent:    #4f6ef7;
#   --accent2:   #7b93ff;
#   --accentRGB: 79,110,247;
#   --glow:      rgba(79,110,247,0.18);
#   --green:     #1ee8a0;
#   --greenRGB:  30,232,160;
#   --amber:     #ffb547;
#   --rose:      #ff5f87;
#   --purple:    #a78bfa;
#   --cyan:      #22d3ee;
#   --muted:     #3d4866;
#   --soft:      #7a86a8;
#   --text:      #c4cde8;
#   --bright:    #eaefff;
#   --font-head: 'Syne', sans-serif;
#   --font-body: 'DM Sans', sans-serif;
#   --font-mono: 'Space Mono', monospace;
# }

# /* ── Reset & Base ── */
# html, body, [data-testid="stAppViewContainer"] {
#   background: var(--bg) !important;
#   color: var(--text) !important;
#   font-family: var(--font-body) !important;
# }
# [data-testid="stAppViewContainer"] > .main { background: transparent !important; }
# [data-testid="stHeader"] {
#   background: rgba(6,8,16,0.92) !important;
#   backdrop-filter: blur(24px);
#   border-bottom: 1px solid var(--border) !important;
# }
# .block-container { padding: 1.5rem 2rem 5rem !important; max-width: 100% !important; }
# #MainMenu, footer, [data-testid="stToolbar"] { display: none !important; }
# h1,h2,h3 { font-family: var(--font-head) !important; color: var(--bright) !important; }
# p, li, label { color: var(--text) !important; }
# hr { border-color: var(--border) !important; margin: 1.5rem 0 !important; }

# /* ── Particle Canvas ── */
# #particle-canvas {
#   position: fixed; top: 0; left: 0; width: 100%; height: 100%;
#   pointer-events: none; z-index: 0; opacity: 0.6;
# }

# /* ── Animated Grid Background ── */
# [data-testid="stAppViewContainer"]::before {
#   content: '';
#   position: fixed; inset: 0;
#   background-image:
#     linear-gradient(rgba(79,110,247,0.03) 1px, transparent 1px),
#     linear-gradient(90deg, rgba(79,110,247,0.03) 1px, transparent 1px);
#   background-size: 60px 60px;
#   pointer-events: none; z-index: 0;
#   animation: gridDrift 20s ease-in-out infinite alternate;
# }
# @keyframes gridDrift {
#   from { background-position: 0 0; }
#   to   { background-position: 30px 30px; }
# }

# /* ── Ambient Orbs ── */
# [data-testid="stAppViewContainer"]::after {
#   content: '';
#   position: fixed; inset: 0; pointer-events: none; z-index: 0;
#   background:
#     radial-gradient(ellipse 600px 400px at 10% 20%, rgba(79,110,247,0.06) 0%, transparent 70%),
#     radial-gradient(ellipse 500px 350px at 90% 80%, rgba(167,139,250,0.05) 0%, transparent 70%),
#     radial-gradient(ellipse 400px 300px at 50% 50%, rgba(30,232,160,0.03) 0%, transparent 70%);
#   animation: orbPulse 8s ease-in-out infinite alternate;
# }
# @keyframes orbPulse {
#   from { opacity: 0.7; } to { opacity: 1; }
# }

# /* ── Sidebar ── */
# [data-testid="stSidebar"] {
#   background: var(--surface) !important;
#   border-right: 1px solid var(--border) !important;
# }
# [data-testid="stSidebar"] .block-container { padding: 1rem !important; }

# /* ── Inputs ── */
# [data-testid="stTextInput"] input,
# [data-testid="stTextArea"] textarea,
# [data-baseweb="textarea"] textarea {
#   background: var(--surface) !important; border: 1px solid var(--border2) !important;
#   border-radius: 10px !important; color: var(--text) !important;
#   font-family: var(--font-body) !important; font-size: 14px !important;
#   caret-color: var(--accent) !important; transition: border-color .2s, box-shadow .2s !important;
# }
# [data-testid="stTextInput"] input:focus,
# [data-testid="stTextArea"] textarea:focus {
#   border-color: var(--accent) !important; box-shadow: 0 0 0 3px var(--glow) !important;
# }
# [data-testid="stTextInput"] label,
# [data-testid="stTextArea"] label { color: var(--soft) !important; font-size: 12px !important; }

# /* ── Selectbox ── */
# [data-testid="stSelectbox"] > div > div {
#   background: var(--surface) !important; border: 1px solid var(--border2) !important;
#   border-radius: 10px !important; color: var(--text) !important;
# }
# [data-baseweb="select"] ul { background: var(--card2) !important; border: 1px solid var(--border2) !important; }
# [data-baseweb="select"] li:hover { background: var(--border2) !important; }
# [data-baseweb="select"] li { color: var(--text) !important; }

# /* ── Checkboxes ── */
# [data-testid="stCheckbox"] label { color: var(--text) !important; font-size: 14px !important; }
# [data-testid="stCheckbox"] span[aria-checked="true"] { background: var(--accent) !important; border-color: var(--accent) !important; }

# /* ── Buttons ── */
# [data-testid="stButton"] > button {
#   background: var(--card) !important; color: var(--soft) !important;
#   border: 1px solid var(--border2) !important; border-radius: 10px !important;
#   font-family: var(--font-body) !important; font-weight: 600 !important;
#   font-size: 13px !important; transition: all .2s !important; padding: 0.45rem 1rem !important;
#   position: relative; z-index: 1;
# }
# [data-testid="stButton"] > button:hover {
#   border-color: var(--accent) !important; color: var(--accent2) !important;
#   box-shadow: 0 0 0 2px var(--glow) !important; transform: translateY(-1px) !important;
# }
# [data-testid="stButton"] > button[kind="primary"] {
#   background: linear-gradient(135deg, var(--accent), #6d5cf7) !important;
#   color: #fff !important; border-color: transparent !important;
#   box-shadow: 0 4px 24px rgba(var(--accentRGB),.4) !important;
# }
# [data-testid="stButton"] > button[kind="primary"]:hover {
#   background: linear-gradient(135deg, var(--accent2), #8b7cf8) !important;
#   transform: translateY(-2px) !important;
#   box-shadow: 0 8px 32px rgba(var(--accentRGB),.55) !important;
# }

# /* ── Tabs ── */
# [data-testid="stTabs"] [data-baseweb="tab-list"] {
#   background: var(--surface) !important; border-radius: 12px !important;
#   padding: 4px !important; border: 1px solid var(--border) !important; gap: 3px !important;
# }
# [data-testid="stTabs"] [data-baseweb="tab"] {
#   background: transparent !important; color: var(--muted) !important;
#   border-radius: 8px !important; font-family: var(--font-body) !important;
#   font-weight: 600 !important; border: none !important; font-size: 13px !important;
# }
# [data-testid="stTabs"] [aria-selected="true"] {
#   background: var(--card2) !important; color: var(--accent2) !important;
#   border: 1px solid var(--border2) !important;
# }
# [data-testid="stTabs"] [data-baseweb="tab-highlight"],
# [data-testid="stTabs"] [data-baseweb="tab-border"] { display: none !important; }

# /* ── Metrics ── */
# [data-testid="stMetric"] {
#   background: var(--card) !important; border: 1px solid var(--border) !important;
#   border-radius: 12px !important; padding: 14px 18px !important;
#   transition: border-color .2s !important;
# }
# [data-testid="stMetric"]:hover { border-color: var(--border2) !important; }
# [data-testid="stMetricLabel"] { color: var(--muted) !important; font-size: 11px !important; font-family: var(--font-mono) !important; }
# [data-testid="stMetricValue"] { color: var(--bright) !important; font-family: var(--font-head) !important; }

# /* ── Alerts ── */
# [data-testid="stSuccess"] { background: rgba(var(--greenRGB),.07) !important; border: 1px solid rgba(var(--greenRGB),.2) !important; border-radius: 10px !important; color: var(--green) !important; }
# [data-testid="stError"]   { background: rgba(255,95,135,.07) !important; border: 1px solid rgba(255,95,135,.2) !important; border-radius: 10px !important; }
# [data-testid="stWarning"] { background: rgba(255,181,71,.07) !important; border: 1px solid rgba(255,181,71,.2) !important; border-radius: 10px !important; color: var(--amber) !important; }
# [data-testid="stInfo"]    { background: rgba(var(--accentRGB),.07) !important; border: 1px solid rgba(var(--accentRGB),.2) !important; border-radius: 10px !important; color: var(--accent2) !important; }

# /* ── Expander ── */
# [data-testid="stExpander"] { background: var(--card) !important; border: 1px solid var(--border) !important; border-radius: 12px !important; }
# [data-testid="stExpander"] summary { color: var(--text) !important; }

# /* ── Scrollbar ── */
# ::-webkit-scrollbar { width: 4px; }
# ::-webkit-scrollbar-track { background: var(--bg); }
# ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 10px; }

# /* ────────────────────────────────────────────────────────
#    CUSTOM COMPONENTS
# ──────────────────────────────────────────────────────── */

# /* Hero */
# .ab-hero {
#   position: relative; overflow: hidden;
#   padding: 56px 0 44px; margin: -1.5rem -2rem 2.5rem;
#   background: linear-gradient(160deg, #060810 0%, #0a0f1e 60%, #0d0f1f 100%);
#   border-bottom: 1px solid var(--border);
# }
# .ab-hero-glow {
#   position: absolute; top: -60px; right: -40px;
#   width: 500px; height: 500px; border-radius: 50%;
#   background: radial-gradient(circle, rgba(79,110,247,.12) 0%, transparent 65%);
#   animation: heroGlow 6s ease-in-out infinite alternate;
# }
# .ab-hero-glow2 {
#   position: absolute; bottom: -80px; left: 5%;
#   width: 360px; height: 360px; border-radius: 50%;
#   background: radial-gradient(circle, rgba(30,232,160,.06) 0%, transparent 65%);
#   animation: heroGlow 8s ease-in-out infinite alternate-reverse;
# }
# @keyframes heroGlow { from { transform: scale(1); } to { transform: scale(1.2); } }
# .ab-hero-inner { padding: 0 2rem; position: relative; z-index: 1; }
# .ab-badge {
#   display: inline-flex; align-items: center; gap: 6px;
#   padding: 5px 14px; border-radius: 20px;
#   background: rgba(79,110,247,.1); border: 1px solid rgba(79,110,247,.25);
#   color: var(--accent2); font-size: 10px; font-weight: 700;
#   letter-spacing: 2px; text-transform: uppercase; margin-bottom: 18px;
#   font-family: var(--font-mono);
# }
# .ab-badge::before {
#   content: ''; width: 6px; height: 6px; border-radius: 50%;
#   background: var(--green); box-shadow: 0 0 8px var(--green);
#   animation: pulse 2s ease-in-out infinite;
# }
# @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.3; } }
# .ab-hero h1 {
#   font-size: 54px !important; font-weight: 800 !important;
#   color: var(--bright) !important; line-height: 1.08 !important;
#   letter-spacing: -1.5px !important; margin-bottom: 14px !important;
#   font-family: var(--font-head) !important;
# }
# .ab-hero h1 em { color: var(--accent2); font-style: normal; }
# .ab-hero p { color: var(--soft) !important; font-size: 15px; max-width: 520px; line-height: 1.7; }

# /* Step bar */
# .step-bar { display:flex; align-items:center; justify-content:center; gap:0; padding: 20px 0 28px; flex-wrap: wrap; }
# .step-node { display:flex; align-items:center; gap:8px; }
# .step-circle {
#   width: 34px; height: 34px; border-radius: 50%; display:flex; align-items:center; justify-content:center;
#   font-size:11px; font-weight:800; border:2px solid var(--border2); color:var(--muted);
#   background:var(--surface); transition:all .4s; font-family: var(--font-mono);
# }
# .step-circle.done  { background:rgba(var(--greenRGB),.1); color:var(--green); border-color:var(--green); }
# .step-circle.active{
#   background: linear-gradient(135deg, var(--accent), #6d5cf7);
#   color:#fff; border-color:transparent;
#   box-shadow: 0 0 20px rgba(var(--accentRGB),.5), 0 0 40px rgba(var(--accentRGB),.2);
#   animation: stepPulse 2s ease-in-out infinite;
# }
# @keyframes stepPulse { 0%,100% { box-shadow: 0 0 20px rgba(79,110,247,.5); } 50% { box-shadow: 0 0 30px rgba(79,110,247,.8); } }
# .step-text { font-size:12px; font-weight:600; color:var(--muted); font-family: var(--font-body); }
# .step-text.active  { color: var(--text); }
# .step-text.done    { color: var(--green); }
# .step-connector { width:36px; height:1px; margin:0 8px; transition: background .4s; }
# .step-connector.done-line { background: linear-gradient(90deg, var(--green), rgba(var(--greenRGB),.3)); }
# .step-connector.plain { background: var(--border); }

# /* Cards */
# .ab-card {
#   background: var(--card); border: 1px solid var(--border);
#   border-radius: 16px; padding: 26px 30px; margin-bottom: 16px;
#   position: relative; z-index: 1;
#   transition: border-color .2s;
# }
# .ab-card:hover { border-color: var(--border2); }
# .ab-label {
#   font-size: 10px; font-weight: 700; letter-spacing: 2px;
#   text-transform: uppercase; color: var(--muted); margin-bottom: 10px;
#   font-family: var(--font-mono);
# }
# .ab-ptag {
#   display: inline-flex; align-items: center; gap: 5px;
#   padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600;
#   margin: 3px; background: rgba(var(--accentRGB),.1);
#   border: 1px solid rgba(var(--accentRGB),.2); color: var(--accent2);
#   font-family: var(--font-body);
# }
# .ab-ptag.green { background: rgba(var(--greenRGB),.1); border-color: rgba(var(--greenRGB),.2); color: var(--green); }
# .ab-ptag.amber { background: rgba(255,181,71,.1); border-color: rgba(255,181,71,.2); color: var(--amber); }
# .ab-ptag.rose  { background: rgba(255,95,135,.1); border-color: rgba(255,95,135,.2); color: var(--rose); }

# /* ── PLATFORM PREVIEW CARDS ── */
# /* Instagram */
# .preview-instagram {
#   background: #fff; border-radius: 12px; overflow: hidden;
#   font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
#   max-width: 420px; box-shadow: 0 20px 60px rgba(0,0,0,.5);
#   border: 1px solid #dbdbdb;
# }
# .ig-header {
#   display: flex; align-items: center; gap: 10px;
#   padding: 12px 14px; border-bottom: 1px solid #efefef;
# }
# .ig-avatar {
#   width: 34px; height: 34px; border-radius: 50%;
#   background: linear-gradient(45deg, #f09433,#e6683c,#dc2743,#cc2366,#bc1888);
#   display: flex; align-items:center; justify-content:center; color:#fff; font-size:13px; font-weight:700;
# }
# .ig-username { font-size: 13px; font-weight: 600; color: #262626; }
# .ig-location { font-size: 11px; color: #737373; }
# .ig-image { width: 100%; aspect-ratio: 1/1; background: #f0f0f0; object-fit: cover; display:block; }
# .ig-image-placeholder { width:100%; aspect-ratio:1/1; background: linear-gradient(135deg,#f5f5f5,#e8e8e8); display:flex; align-items:center; justify-content:center; color:#aaa; font-size:40px; }
# .ig-actions { padding: 10px 14px 6px; display:flex; gap:14px; }
# .ig-action { font-size: 22px; cursor: pointer; }
# .ig-likes { padding: 0 14px 6px; font-size:13px; font-weight:600; color:#262626; }
# .ig-caption { padding: 2px 14px 10px; font-size:13px; color:#262626; line-height:1.5; }
# .ig-caption .ig-name { font-weight:700; margin-right:5px; }
# .ig-hashtags { color: #003569; }
# .ig-time { padding: 0 14px 12px; font-size:11px; color:#8e8e8e; text-transform:uppercase; }

# /* Facebook */
# .preview-facebook {
#   background: #fff; border-radius: 10px; overflow: hidden;
#   font-family: Helvetica, Arial, sans-serif; max-width: 500px;
#   box-shadow: 0 20px 60px rgba(0,0,0,.5); border: 1px solid #ddd;
# }
# .fb-header { display:flex; align-items:center; gap:10px; padding:12px 14px; }
# .fb-avatar { width:42px; height:42px; border-radius:50%; background: linear-gradient(135deg,#1877f2,#42a5f5); display:flex; align-items:center; justify-content:center; color:#fff; font-size:16px; font-weight:700; }
# .fb-name { font-size:14px; font-weight:700; color:#050505; }
# .fb-meta { font-size:12px; color:#65676b; display:flex; align-items:center; gap:4px; }
# .fb-content { padding: 0 14px 12px; font-size:14px; color:#050505; line-height:1.55; }
# .fb-image { width:100%; background:#f0f0f0; }
# .fb-reactions { padding: 8px 14px; border-top:1px solid #e4e6eb; border-bottom:1px solid #e4e6eb; display:flex; justify-content:space-between; font-size:13px; color:#65676b; }
# .fb-actions { display:flex; gap:0; }
# .fb-action-btn { flex:1; text-align:center; padding:8px; font-size:13px; color:#65676b; font-weight:600; border-top:none; cursor:pointer; }

# /* Telegram */
# .preview-telegram {
#   background: #1c2733; border-radius: 14px; overflow: hidden;
#   font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 440px;
#   box-shadow: 0 20px 60px rgba(0,0,0,.6);
# }
# .tg-header { background: #2b5278; padding: 12px 16px; display:flex; align-items:center; gap:10px; }
# .tg-icon { width:38px; height:38px; border-radius:50%; background: linear-gradient(135deg,#2b9fda,#1da1f2); display:flex; align-items:center; justify-content:center; color:#fff; font-size:16px; }
# .tg-channel-name { font-size:14px; font-weight:700; color:#fff; }
# .tg-subscribers { font-size:11px; color:rgba(255,255,255,.6); }
# .tg-msg { margin:10px 12px; background: #2b3d4f; border-radius:10px; padding:12px 14px; }
# .tg-msg-text { font-size:14px; color:#e1e8f0; line-height:1.55; }
# .tg-msg-text b { color:#fff; font-weight:700; }
# .tg-msg-image { width:100%; border-radius:8px; margin-bottom:10px; }
# .tg-msg-meta { font-size:11px; color:rgba(225,232,240,.45); text-align:right; margin-top:8px; }
# .tg-views { display:flex; align-items:center; gap:4px; font-size:12px; color:rgba(225,232,240,.5); padding: 6px 14px 10px; }

# /* Discord */
# .preview-discord {
#   background: #313338; border-radius: 10px; overflow: hidden;
#   font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 460px;
#   box-shadow: 0 20px 60px rgba(0,0,0,.6);
# }
# .dc-header { background: #2b2d31; padding: 10px 14px; display:flex; align-items:center; gap:8px; border-bottom:1px solid #1e1f22; }
# .dc-hash { color:#80848e; font-size:20px; font-weight:700; }
# .dc-channel-name { font-size:14px; font-weight:700; color:#f2f3f5; }
# .dc-msg { padding: 14px 14px 10px; display:flex; gap:12px; }
# .dc-avatar { width:40px; height:40px; border-radius:50%; background: linear-gradient(135deg,#5865f2,#7289da); flex-shrink:0; display:flex; align-items:center; justify-content:center; color:#fff; font-size:16px; font-weight:700; }
# .dc-msg-right { flex:1; }
# .dc-username { font-size:14px; font-weight:700; color:#f2f3f5; }
# .dc-bot-badge { background:#5865f2; color:#fff; font-size:9px; font-weight:700; padding:2px 5px; border-radius:3px; margin-left:4px; letter-spacing:.5px; }
# .dc-timestamp { font-size:11px; color:#80848e; margin-left:6px; }
# .dc-text { font-size:14px; color:#dcddde; line-height:1.55; margin-top:4px; }
# .dc-embed { margin-top:10px; border-left:4px solid #5865f2; background:#2b2d31; border-radius:0 4px 4px 0; padding:10px 14px; }
# .dc-embed-img { width:100%; border-radius:6px; margin-top:8px; }

# /* LinkedIn */
# .preview-linkedin {
#   background: #fff; border-radius: 10px; overflow: hidden;
#   font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 500px;
#   box-shadow: 0 20px 60px rgba(0,0,0,.5); border: 1px solid #e0e0e0;
# }
# .li-header { display:flex; align-items:center; gap:10px; padding:14px 14px 10px; }
# .li-avatar { width:48px; height:48px; border-radius:50%; background: linear-gradient(135deg,#0a66c2,#0d8fdb); display:flex; align-items:center; justify-content:center; color:#fff; font-size:18px; font-weight:700; }
# .li-name { font-size:14px; font-weight:700; color:#000000e6; }
# .li-headline { font-size:12px; color:#00000099; line-height:1.4; }
# .li-degree { font-size:11px; color:#0a66c2; }
# .li-content { padding: 4px 14px 14px; font-size:14px; color:#000000e6; line-height:1.6; white-space: pre-wrap; word-break: break-word; }
# .li-image { width:100%; }
# .li-reactions { padding:8px 14px; border-top:1px solid rgba(0,0,0,.1); font-size:13px; color:#00000099; display:flex; justify-content:space-between; }
# .li-actions { display:flex; border-top:1px solid rgba(0,0,0,.1); }
# .li-action-btn { flex:1; text-align:center; padding:10px; font-size:13px; color:#00000099; font-weight:600; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:5px; }

# /* Reddit */
# .preview-reddit {
#   background: #1a1a1b; border-radius: 10px; overflow: hidden;
#   font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 500px;
#   box-shadow: 0 20px 60px rgba(0,0,0,.6); border: 1px solid #343536;
# }
# .rd-header { display:flex; align-items:center; gap:8px; padding:10px 12px; border-bottom:1px solid #343536; }
# .rd-sub-icon { width:28px; height:28px; border-radius:50%; background: linear-gradient(135deg,#ff4500,#ff6534); display:flex; align-items:center; justify-content:center; color:#fff; font-size:13px; font-weight:800; }
# .rd-sub-name { font-size:13px; font-weight:700; color:#d7dadc; }
# .rd-posted-by { font-size:11px; color:#818384; }
# .rd-body { padding: 10px 12px; }
# .rd-title { font-size:16px; font-weight:700; color:#d7dadc; margin-bottom:8px; line-height:1.35; }
# .rd-text { font-size:13px; color:#d7dadc; line-height:1.55; }
# .rd-image { width:100%; border-radius:4px; margin-top:8px; }
# .rd-actions { padding:8px 12px; display:flex; align-items:center; gap:14px; }
# .rd-vote { display:flex; align-items:center; gap:6px; background:#272729; border-radius:20px; padding:5px 10px; }
# .rd-vote-arrow { color:#818384; font-size:14px; cursor:pointer; }
# .rd-vote-count { font-size:13px; font-weight:700; color:#d7dadc; }
# .rd-action-btn { display:flex; align-items:center; gap:5px; color:#818384; font-size:13px; font-weight:700; cursor:pointer; }

# /* Metric badges */
# .eng-badge { display:inline-block; padding:3px 12px; border-radius:20px; font-size:12px; font-weight:700; font-family: var(--font-mono); }
# .eng-good  { background:rgba(var(--greenRGB),.1); border:1px solid rgba(var(--greenRGB),.25); color:var(--green); }
# .eng-mid   { background:rgba(255,181,71,.1); border:1px solid rgba(255,181,71,.25);  color:var(--amber); }
# .eng-bad   { background:rgba(255,95,135,.1); border:1px solid rgba(255,95,135,.25);color:var(--rose); }

# /* Chat messages */
# .chat-msg  { border-radius:12px; padding:12px 16px; margin-bottom:8px; font-size:13px; line-height:1.6; position:relative; z-index:1; }
# .chat-bot  { background:var(--card); border:1px solid var(--border); border-left:3px solid var(--accent); }
# .chat-user { background:rgba(var(--accentRGB),.06); border:1px solid rgba(var(--accentRGB),.12); text-align:right; }
# .chat-label{ font-size:10px; color:var(--muted); margin-bottom:4px; font-weight:700; letter-spacing:1px; text-transform:uppercase; font-family: var(--font-mono); }

# /* Platform cards (selection) */
# .plat-card {
#   background: var(--card); border: 1px solid var(--border);
#   border-radius: 14px; padding: 18px; transition: all .2s;
#   position: relative; z-index: 1;
# }
# .plat-card.selected { border-color: var(--accent); box-shadow: 0 0 0 2px var(--glow); }

# /* Posted ad card */
# .posted-card {
#   background: var(--card); border: 1px solid var(--border);
#   border-radius: 16px; padding: 24px 28px; margin-bottom: 20px;
#   position: relative; z-index: 1; transition: border-color .2s;
# }
# .posted-card:hover { border-color: var(--border2); }
# .posted-card.low-eng { border-color: rgba(255,95,135,.3); }
# .low-eng-banner {
#   background: rgba(255,95,135,.08); border: 1px solid rgba(255,95,135,.2);
#   border-radius: 10px; padding: 12px 16px; margin-bottom: 16px;
#   display:flex; align-items:center; gap:10px; font-size:13px; color: var(--rose);
# }

# /* Image regen feedback */
# .img-regen-box {
#   background: var(--surface); border: 1px solid var(--border2);
#   border-radius: 10px; padding: 14px 16px; margin-top: 10px;
# }

# /* Divider label */
# .section-divider {
#   display:flex; align-items:center; gap:12px; margin: 28px 0 20px;
#   position: relative; z-index: 1;
# }
# .section-divider::before, .section-divider::after {
#   content:''; flex:1; height:1px; background: var(--border);
# }
# .section-divider span {
#   font-size:11px; font-weight:700; letter-spacing:2px; text-transform:uppercase;
#   color: var(--muted); font-family: var(--font-mono); white-space: nowrap;
# }

# /* Skeleton loader */
# .skeleton {
#   background: linear-gradient(90deg, var(--card) 25%, var(--card2) 50%, var(--card) 75%);
#   background-size: 200% 100%; animation: shimmer 1.5s infinite;
#   border-radius: 8px; height: 16px;
# }
# @keyframes shimmer { from { background-position: 200% 0; } to { background-position: -200% 0; } }
# </style>

# <!-- Animated particle canvas -->
# <canvas id="particle-canvas"></canvas>
# <script>
# (function() {
#   const canvas = document.getElementById('particle-canvas');
#   if (!canvas) return;
#   const ctx = canvas.getContext('2d');
#   let W, H, particles = [];

#   function resize() {
#     W = canvas.width  = window.innerWidth;
#     H = canvas.height = window.innerHeight;
#   }
#   resize();
#   window.addEventListener('resize', resize);

#   const COLORS = ['rgba(79,110,247,', 'rgba(167,139,250,', 'rgba(30,232,160,', 'rgba(34,211,238,'];

#   for (let i = 0; i < 80; i++) {
#     particles.push({
#       x: Math.random() * 1000,
#       y: Math.random() * 1000,
#       vx: (Math.random() - 0.5) * 0.3,
#       vy: (Math.random() - 0.5) * 0.3,
#       r: Math.random() * 1.5 + 0.3,
#       color: COLORS[Math.floor(Math.random() * COLORS.length)],
#       alpha: Math.random() * 0.5 + 0.1,
#     });
#   }

#   function draw() {
#     ctx.clearRect(0, 0, W, H);
#     particles.forEach(p => {
#       p.x += p.vx; p.y += p.vy;
#       if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
#       if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
#       ctx.beginPath();
#       ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
#       ctx.fillStyle = p.color + p.alpha + ')';
#       ctx.fill();
#     });

#     // Draw connections
#     for (let i = 0; i < particles.length; i++) {
#       for (let j = i + 1; j < particles.length; j++) {
#         const dx = particles[i].x - particles[j].x;
#         const dy = particles[i].y - particles[j].y;
#         const dist = Math.sqrt(dx*dx + dy*dy);
#         if (dist < 100) {
#           ctx.beginPath();
#           ctx.moveTo(particles[i].x, particles[i].y);
#           ctx.lineTo(particles[j].x, particles[j].y);
#           ctx.strokeStyle = `rgba(79,110,247,${0.06 * (1 - dist/100)})`;
#           ctx.lineWidth = 0.5;
#           ctx.stroke();
#         }
#       }
#     }
#     requestAnimationFrame(draw);
#   }
#   draw();
# })();
# </script>
# """, unsafe_allow_html=True)

# # ── Session State ─────────────────────────────────────────────────────────────
# DEFAULTS = {
#     "step": "describe",
#     "campaign_id": None,
#     "campaign_data": None,
#     "ads": [],
#     "posts": [],
#     "chat": [],
#     "selected_platforms": [],
#     "ad_version_num": 1,
#     "low_eng_shown": False,
#     "img_sources": {},
#     "img_enabled": {},
#     "img_feedback": {},   # {platform: str} — image regen feedback
# }
# for k, v in DEFAULTS.items():
#     if k not in st.session_state:
#         st.session_state[k] = v

# # ── Constants ─────────────────────────────────────────────────────────────────
# PLATFORMS = {
#     "Instagram": {"icon": "📸", "max_chars": 2200,  "color": "#e1306c", "style": "Visual · emojis · hashtags", "needs_image": True},
#     "Facebook":  {"icon": "👥", "max_chars": 63206, "color": "#1877f2", "style": "Conversational · detailed",  "needs_image": False},
#     "Telegram":  {"icon": "✈️", "max_chars": 4096,  "color": "#5b6ef5", "style": "Informative · *bold* key points", "needs_image": False},
#     "Discord":   {"icon": "🎮", "max_chars": 2000,  "color": "#7289da", "style": "Casual · community-focused", "needs_image": False},
#     "LinkedIn":  {"icon": "💼", "max_chars": 3000,  "color": "#0a66c2", "style": "Professional · value-driven", "needs_image": False},
#     "Reddit":    {"icon": "🤖", "max_chars": 40000, "color": "#ff4500", "style": "Authentic · community value", "needs_image": False},
# }

# PLATFORM_SMART = {
#     "Job / Hiring":   ["LinkedIn", "Discord", "Reddit"],
#     "Grocery / Food": ["Instagram", "Facebook", "Telegram"],
#     "Product Sale":   ["Instagram", "Facebook", "Reddit"],
#     "Event":          ["Instagram", "Facebook", "Discord"],
#     "Service":        ["Facebook", "Telegram", "Reddit"],
#     "Real Estate":    ["Facebook", "Instagram", "Telegram"],
#     "Announcement":   ["Telegram", "Discord", "Reddit"],
#     "General":        ["Instagram", "Facebook"],
# }

# IMAGE_SOURCES = {
#     "flux":          "⚡ FLUX.1 (HF Space)",
#     "pollinations":  "🎨 Pollinations AI",
#     "unsplash":      "📷 Picsum Stock",
#     "replicate":     "🚀 Replicate FLUX",
# }

# STEPS   = ["describe", "platform_select", "generating", "review", "monitor"]
# SLABELS = ["Describe", "Platforms", "Generate", "Review", "Monitor"]

# # ── Helpers ───────────────────────────────────────────────────────────────────
# def api(method, path, **kwargs):
#     try:
#         resp = getattr(requests, method)(f"{BACKEND_URL}{path}", timeout=90, **kwargs)
#         resp.raise_for_status()
#         return resp.json()
#     except requests.exceptions.ConnectionError:
#         st.error("❌ Backend not running. Start it: `uvicorn main:app --reload`")
#         st.stop()
#     except requests.exceptions.HTTPError as e:
#         detail = e.response.json().get("detail", str(e)) if e.response else str(e)
#         raise ValueError(detail)

# def add_chat(role, msg):
#     st.session_state.chat.append({"role": role, "msg": msg, "ts": datetime.now().strftime("%H:%M")})

# def eng_badge(rate):
#     if rate >= 5:   return "🟢 Great",  "eng-good"
#     if rate >= 2.5: return "🟡 Okay",   "eng-mid"
#     return "🔴 Low", "eng-bad"

# def render_stepbar():
#     idx   = STEPS.index(st.session_state.step) if st.session_state.step in STEPS else 0
#     nodes = ""
#     for i, lbl in enumerate(SLABELS):
#         cls  = "active" if i == idx else ("done" if i < idx else "")
#         txt  = "active" if i == idx else ("done" if i < idx else "")
#         sym  = "✓" if i < idx else str(i + 1)
#         nodes += f'<div class="step-node"><div class="step-circle {cls}">{sym}</div><span class="step-text {txt}">{lbl}</span></div>'
#         if i < len(SLABELS) - 1:
#             line_cls = "done-line" if i < idx else "plain"
#             nodes += f'<div class="step-connector {line_cls}"></div>'
#     st.markdown(f'<div class="step-bar">{nodes}</div>', unsafe_allow_html=True)

# def render_platform_preview(platform: str, ad: dict):
#     """Render a native-looking platform post preview."""
#     content   = ad.get("content", "")
#     image_url = ad.get("image_url", "")
#     now_str   = "Just now"

#     # Truncate long text for preview
#     preview_text = content if len(content) < 500 else content[:497] + "…"
#     # Split hashtags
#     lines   = preview_text.split('\n')
#     hashtags = " ".join([w for w in content.split() if w.startswith('#')])
#     no_hash  = " ".join([w for w in preview_text.split() if not w.startswith('#') and not w.startswith('@')])[:350]

#     img_html = ""
#     if image_url:
#         img_html = f'<img src="{image_url}" style="width:100%;display:block;" />'

#     if platform == "Instagram":
#         img_block = img_html if img_html else '<div class="ig-image-placeholder">📷</div>'
#         st.markdown(f"""
#         <div class="preview-instagram">
#           <div class="ig-header">
#             <div class="ig-avatar">A</div>
#             <div><div class="ig-username">adbot_official</div><div class="ig-location">Sponsored</div></div>
#             <span style="margin-left:auto;font-size:20px;color:#262626">···</span>
#           </div>
#           {img_block}
#           <div class="ig-actions">
#             <span class="ig-action">🤍</span>
#             <span class="ig-action">💬</span>
#             <span class="ig-action">📤</span>
#             <span style="margin-left:auto" class="ig-action">🔖</span>
#           </div>
#           <div class="ig-likes">142 likes</div>
#           <div class="ig-caption"><span class="ig-name">adbot_official</span>{no_hash[:200]}
#             <span class="ig-hashtags"> {hashtags[:120]}</span></div>
#           <div class="ig-time">2 minutes ago</div>
#         </div>""", unsafe_allow_html=True)

#     elif platform == "Facebook":
#         img_block = f'<img class="fb-image" src="{image_url}" />' if image_url else ""
#         st.markdown(f"""
#         <div class="preview-facebook">
#           <div class="fb-header">
#             <div class="fb-avatar">A</div>
#             <div><div class="fb-name">AdBot Page</div>
#               <div class="fb-meta">2 min · 🌍</div></div>
#             <span style="margin-left:auto;font-size:18px;color:#65676b">···</span>
#           </div>
#           <div class="fb-content">{preview_text[:400]}</div>
#           {img_block}
#           <div class="fb-reactions">
#             <span>👍 ❤️ 😮 &nbsp; 47</span>
#             <span>12 comments · 5 shares</span>
#           </div>
#           <div class="fb-actions">
#             <div class="fb-action-btn">👍 Like</div>
#             <div class="fb-action-btn">💬 Comment</div>
#             <div class="fb-action-btn">↗️ Share</div>
#           </div>
#         </div>""", unsafe_allow_html=True)

#     elif platform == "Telegram":
#         img_block = f'<img class="tg-msg-image" src="{image_url}" />' if image_url else ""
#         bold_text = preview_text.replace("*", "").replace("**", "")[:300]
#         st.markdown(f"""
#         <div class="preview-telegram">
#           <div class="tg-header">
#             <div class="tg-icon">✈</div>
#             <div><div class="tg-channel-name">AdBot Channel</div>
#               <div class="tg-subscribers">1,247 subscribers</div></div>
#           </div>
#           <div style="padding:6px 12px 4px;">
#             <div class="tg-msg">
#               {img_block}
#               <div class="tg-msg-text">{bold_text}</div>
#               <div class="tg-msg-meta">12:34 ✓✓</div>
#             </div>
#           </div>
#           <div class="tg-views">👁 342 views</div>
#         </div>""", unsafe_allow_html=True)

#     elif platform == "Discord":
#         img_block = f'<img class="dc-embed-img" src="{image_url}" />' if image_url else ""
#         st.markdown(f"""
#         <div class="preview-discord">
#           <div class="dc-header">
#             <span class="dc-hash">#</span>
#             <span class="dc-channel-name">announcements</span>
#           </div>
#           <div class="dc-msg">
#             <div class="dc-avatar">A</div>
#             <div class="dc-msg-right">
#               <div><span class="dc-username">AdBot</span>
#                 <span class="dc-bot-badge">APP</span>
#                 <span class="dc-timestamp">Today at 12:34</span></div>
#               <div class="dc-text">{preview_text[:300]}</div>
#               {f'<div class="dc-embed">{img_block}</div>' if image_url else ""}
#             </div>
#           </div>
#         </div>""", unsafe_allow_html=True)

#     elif platform == "LinkedIn":
#         img_block = f'<img class="li-image" src="{image_url}" />' if image_url else ""
#         st.markdown(f"""
#         <div class="preview-linkedin">
#           <div class="li-header">
#             <div class="li-avatar">A</div>
#             <div><div class="li-name">AdBot Official</div>
#               <div class="li-headline">AI-Powered Advertising Platform</div>
#               <div class="li-degree">2nd · 2h · 🌍</div></div>
#             <span style="margin-left:auto;font-size:22px;color:#00000066">···</span>
#           </div>
#           <div class="li-content">{preview_text[:400]}</div>
#           {img_block}
#           <div class="li-reactions">
#             <span>👍 ❤️ 💡 &nbsp; 87 reactions</span>
#             <span>24 comments · 11 reposts</span>
#           </div>
#           <div class="li-actions">
#             <div class="li-action-btn">👍 Like</div>
#             <div class="li-action-btn">💬 Comment</div>
#             <div class="li-action-btn">🔄 Repost</div>
#             <div class="li-action-btn">📤 Send</div>
#           </div>
#         </div>""", unsafe_allow_html=True)

#     elif platform == "Reddit":
#         lines2   = preview_text.strip().split('\n')
#         rd_title = lines2[0][:100] if lines2 else "Ad Post"
#         rd_body  = '\n'.join(lines2[1:])[:300] if len(lines2) > 1 else ""
#         img_block = f'<img class="rd-image" src="{image_url}" />' if image_url else ""
#         st.markdown(f"""
#         <div class="preview-reddit">
#           <div class="rd-header">
#             <div class="rd-sub-icon">r/</div>
#             <div><div class="rd-sub-name">r/announcements</div>
#               <div class="rd-posted-by">Posted by u/adbot_official · Just now</div></div>
#           </div>
#           <div class="rd-body">
#             <div class="rd-title">{rd_title}</div>
#             <div class="rd-text">{rd_body}</div>
#             {img_block}
#           </div>
#           <div class="rd-actions">
#             <div class="rd-vote">
#               <span class="rd-vote-arrow">▲</span>
#               <span class="rd-vote-count">1</span>
#               <span class="rd-vote-arrow">▼</span>
#             </div>
#             <div class="rd-action-btn">💬 Comment</div>
#             <div class="rd-action-btn">↗️ Share</div>
#             <div class="rd-action-btn">••• More</div>
#           </div>
#         </div>""", unsafe_allow_html=True)

# # ── SIDEBAR ───────────────────────────────────────────────────────────────────
# with st.sidebar:
#     st.markdown("""
#     <div style="padding:8px 0 16px">
#       <div style="font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:#eaefff;letter-spacing:-0.5px">
#         ⚡ AdBot
#       </div>
#       <div style="font-size:11px;color:#3d4866;font-family:'Space Mono',monospace;letter-spacing:1px;text-transform:uppercase">
#         AI Ad Platform
#       </div>
#     </div>
#     """, unsafe_allow_html=True)
#     st.divider()

#     # Chat history
#     st.markdown('<div style="font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#3d4866;font-family:\'Space Mono\',monospace;margin-bottom:10px">Chat History</div>', unsafe_allow_html=True)

#     chat_container = st.container()
#     with chat_container:
#         if not st.session_state.chat:
#             st.markdown('<div style="font-size:12px;color:#3d4866;text-align:center;padding:20px 0">No messages yet</div>', unsafe_allow_html=True)
#         else:
#             for entry in st.session_state.chat[-20:]:
#                 cls   = "chat-bot"  if entry["role"] == "agent" else "chat-user"
#                 label = "⚡ AdBot"  if entry["role"] == "agent" else "👤 You"
#                 st.markdown(f'<div class="chat-msg {cls}"><div class="chat-label">{label} · {entry["ts"]}</div>{entry["msg"]}</div>', unsafe_allow_html=True)

#     st.divider()

#     # Past campaigns
#     st.markdown('<div style="font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#3d4866;font-family:\'Space Mono\',monospace;margin-bottom:10px">Past Campaigns</div>', unsafe_allow_html=True)
#     try:
#         history = api("get", "/campaigns")
#         if history:
#             for c in history[:8]:
#                 created = datetime.fromisoformat(c["created_at"]).strftime("%b %d")
#                 if st.button(
#                     f"**{c['ad_type']}**\n{c['description'][:32]}… · _{created}_",
#                     key=f"hist_{c['id']}", use_container_width=True
#                 ):
#                     st.session_state.campaign_id   = c["id"]
#                     st.session_state.campaign_data = c
#                     st.session_state.selected_platforms = PLATFORM_SMART.get(c["ad_type"], ["Instagram", "Facebook"])
#                     st.session_state.step = "platform_select"
#                     add_chat("agent", f"Loaded campaign: <b>{c['description'][:60]}</b>")
#                     st.rerun()
#         else:
#             st.caption("No past campaigns yet.")
#     except Exception:
#         st.caption("Start your first campaign!")

#     st.divider()
#     if st.button("＋ New Campaign", use_container_width=True, type="primary"):
#         for k in list(st.session_state.keys()):
#             del st.session_state[k]
#         st.rerun()

# # ── HERO ──────────────────────────────────────────────────────────────────────
# st.markdown("""
# <div class="ab-hero">
#   <div class="ab-hero-glow"></div>
#   <div class="ab-hero-glow2"></div>
#   <div class="ab-hero-inner">
#     <div class="ab-badge">AI-Powered · Multi-Platform · Real APIs</div>
#     <h1>AdBot —<br/><em>ads that convert.</em></h1>
#     <p>Describe your product once. Get platform-native copy, AI images, real-time previews, and live API posting — all in one flow.</p>
#   </div>
# </div>
# """, unsafe_allow_html=True)

# render_stepbar()

# # ═════════════════════════════════════════════════════════════════════════════
# # STEP 1 — DESCRIBE
# # ═════════════════════════════════════════════════════════════════════════════
# if st.session_state.step == "describe":

#     st.markdown('<div class="ab-card">', unsafe_allow_html=True)
#     st.markdown('<div class="ab-label">What are you advertising?</div>', unsafe_allow_html=True)
#     desc = st.text_area(
#         "desc", label_visibility="collapsed",
#         placeholder=(
#             "Examples:\n"
#             "• Fresh organic vegetables, 20% off this weekend, home delivery in Mumbai\n"
#             "• Hiring senior React developer, 3+ yrs exp, fintech startup, remote OK\n"
#             "• Grand opening of new bakery — artisan breads, coffee. Saturday 10 AM\n"
#             "• 2BHK apartment for rent, fully furnished, ₹25,000/mo"
#         ),
#         height=160
#     )

#     col1, col2 = st.columns(2)
#     with col1:
#         st.markdown('<div class="ab-label">Tone</div>', unsafe_allow_html=True)
#         tone = st.selectbox(
#             "tone", ["Auto-detect","Energetic","Professional","Friendly","Urgent","Luxurious","Minimalist"],
#             label_visibility="collapsed"
#         )
#     with col2:
#         st.markdown('<div class="ab-label">Language</div>', unsafe_allow_html=True)
#         lang = st.selectbox(
#             "lang", ["English","Hinglish","Hindi","Tamil","Telugu","Kannada"],
#             label_visibility="collapsed"
#         )
#     st.markdown("</div>", unsafe_allow_html=True)
#     st.markdown("")

#     if st.button("Continue → Choose Platforms", type="primary", use_container_width=True):
#         if not desc.strip():
#             st.error("Please describe your product or service.")
#         else:
#             with st.spinner("Analyzing your campaign…"):
#                 try:
#                     campaign = api("post", "/campaigns", json={"description": desc, "tone": tone, "language": lang})
#                     st.session_state.campaign_id   = campaign["id"]
#                     st.session_state.campaign_data = campaign
#                     st.session_state.selected_platforms = PLATFORM_SMART.get(campaign["ad_type"], ["Instagram","Facebook"])
#                     add_chat("agent", f"Detected as <b>{campaign['ad_type']}</b>. Pre-selected best platforms.")
#                     st.session_state.step = "platform_select"
#                     st.rerun()
#                 except ValueError as e:
#                     st.error(str(e))

# # ═════════════════════════════════════════════════════════════════════════════
# # STEP 2 — PLATFORM SELECT
# # ═════════════════════════════════════════════════════════════════════════════
# elif st.session_state.step == "platform_select":
#     campaign  = st.session_state.campaign_data
#     ad_type   = campaign["ad_type"] if campaign else "General"
#     suggested = PLATFORM_SMART.get(ad_type, ["Instagram","Facebook"])

#     st.markdown('<div class="ab-card">', unsafe_allow_html=True)
#     st.markdown('<div class="ab-label">Select Platforms</div>', unsafe_allow_html=True)
#     st.markdown(
#         f'<div style="margin-bottom:16px;font-size:13px;color:var(--soft)">💡 Recommended for '
#         f'<b style="color:var(--green)">{ad_type}</b>: '
#         + "".join([f'<span class="ab-ptag green">{PLATFORMS[p]["icon"]} {p}</span>' for p in suggested if p in PLATFORMS])
#         + "</div>", unsafe_allow_html=True
#     )

#     cols   = st.columns(3)
#     chosen = []
#     for i, (name, info) in enumerate(PLATFORMS.items()):
#         with cols[i % 3]:
#             checked = st.checkbox(
#                 f"{info['icon']} **{name}**\n_{info['style']}_",
#                 value=(name in suggested),
#                 key=f"plat_{name}"
#             )
#             if name == "Instagram" and checked:
#                 st.markdown('<div style="font-size:11px;color:var(--green);margin-top:-8px;margin-bottom:4px">✦ Auto-generates image</div>', unsafe_allow_html=True)
#             if checked:
#                 chosen.append(name)

#     st.markdown("</div>", unsafe_allow_html=True)

#     if chosen:
#         st.markdown(
#             '<div style="margin:10px 0 6px;font-size:13px;color:var(--soft)">Generating for: '
#             + "".join([f'<span class="ab-ptag">{PLATFORMS[p]["icon"]} {p}</span>' for p in chosen])
#             + "</div>", unsafe_allow_html=True
#         )

#     c1, c2 = st.columns([1, 3])
#     with c1:
#         if st.button("← Back"):
#             st.session_state.step = "describe"; st.rerun()
#     with c2:
#         lbl = (f"✦ Generate for {len(chosen)} Platform{'s' if len(chosen) != 1 else ''}"
#                if chosen else "Select at least one platform")
#         if st.button(lbl, type="primary", use_container_width=True, disabled=len(chosen) == 0):
#             add_chat("human", f"Generate for: {', '.join(chosen)}")
#             st.session_state.selected_platforms = chosen
#             st.session_state.img_enabled = {p: (True if PLATFORMS[p]["needs_image"] else False) for p in chosen}
#             st.session_state.img_sources = {p: "flux" for p in chosen}
#             st.session_state.img_feedback = {p: "" for p in chosen}
#             st.session_state.step = "generating"
#             st.rerun()

# # ═════════════════════════════════════════════════════════════════════════════
# # STEP 3 — GENERATING
# # ═════════════════════════════════════════════════════════════════════════════
# elif st.session_state.step == "generating":
#     platforms_to_generate = st.session_state.selected_platforms

#     if not platforms_to_generate:
#         st.error("No platforms selected.")
#         if st.button("← Go Back"):
#             st.session_state.step = "platform_select"; st.rerun()
#     else:
#         with st.spinner(f"🤖 Crafting ads for {', '.join(platforms_to_generate)}…"):
#             try:
#                 result = api(
#                     "post",
#                     f"/campaigns/{st.session_state.campaign_id}/generate",
#                     json={"platforms": platforms_to_generate, "feedback": ""}
#                 )
#                 all_ads      = result["ads"]
#                 filtered_ads = [ad for ad in all_ads if ad["platform"] in platforms_to_generate]
#                 st.session_state.ads            = filtered_ads
#                 st.session_state.ad_version_num = result["version"]

#                 # Auto-generate image for Instagram
#                 for ad in st.session_state.ads:
#                     if ad["platform"] == "Instagram" and not ad.get("image_url"):
#                         try:
#                             src = st.session_state.img_sources.get("Instagram", "flux")
#                             updated_ad = api("post", f"/ads/{ad['id']}/generate-image?source={src}")
#                             st.session_state.ads = [
#                                 updated_ad if a["id"] == ad["id"] else a
#                                 for a in st.session_state.ads
#                             ]
#                             add_chat("agent", f"✅ Instagram image auto-generated.")
#                         except Exception as e:
#                             add_chat("agent", f"⚠️ Instagram image failed: {e}")

#                 st.session_state.step = "review"
#                 add_chat("agent", f"✅ <b>{len(filtered_ads)} ads</b> ready for {', '.join(platforms_to_generate)}.")
#                 st.rerun()
#             except Exception as e:
#                 st.error(f"Generation failed: {e}")
#                 if st.button("← Go Back"):
#                     st.session_state.step = "platform_select"; st.rerun()

# # ═════════════════════════════════════════════════════════════════════════════
# # STEP 4 — REVIEW (Preview + Edit + Post)
# # ═════════════════════════════════════════════════════════════════════════════
# elif st.session_state.step == "review":
#     campaign = st.session_state.campaign_data
#     ads_list = st.session_state.ads
#     selected = st.session_state.selected_platforms
#     ads_map  = {ad["platform"]: ad for ad in ads_list if ad["platform"] in selected}

#     if not ads_map:
#         st.warning("No ads found. Please regenerate.")
#         if st.button("← Go Back"):
#             st.session_state.step = "platform_select"; st.rerun()
#         st.stop()

#     first = ads_list[0]

#     # Campaign header
#     st.markdown(f"""
#     <div class="ab-card" style="margin-bottom:24px;background:linear-gradient(135deg,var(--card),var(--card2));border-color:var(--border2)">
#       <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px">
#         <div>
#           <div class="ab-label">Campaign · v{st.session_state.ad_version_num} · #{campaign['id']}</div>
#           <div style="font-family:'Syne',sans-serif;font-size:24px;font-weight:800;color:var(--bright);margin-bottom:6px">
#             {first.get('title','Your Campaign')}
#           </div>
#           <div style="font-size:13px;color:var(--muted)">
#             {campaign['ad_type']} &nbsp;·&nbsp; CTA: {first.get('cta','—')}
#             &nbsp;·&nbsp; Platforms: {', '.join(ads_map.keys())}
#           </div>
#         </div>
#         <div>{''.join([f'<span class="ab-ptag">{PLATFORMS[p]["icon"]} {p}</span>' for p in ads_map.keys()])}</div>
#       </div>
#     </div>""", unsafe_allow_html=True)

#     # Global feedback
#     st.markdown('<div class="ab-card" style="padding:18px 24px;margin-bottom:20px">', unsafe_allow_html=True)
#     st.markdown('<div class="ab-label">Global Feedback — Regenerate All Texts</div>', unsafe_allow_html=True)
#     gf_col, gb_col = st.columns([5, 1])
#     with gf_col:
#         global_fb = st.text_input(
#             "global_feedback", label_visibility="collapsed",
#             placeholder="Apply feedback to all platforms at once…",
#             key=f"global_fb_{st.session_state.ad_version_num}"
#         )
#     with gb_col:
#         if st.button("Apply →", use_container_width=True):
#             if global_fb.strip():
#                 add_chat("human", f"Global: {global_fb}")
#                 with st.spinner("Regenerating all…"):
#                     try:
#                         result = api("post",
#                             f"/campaigns/{st.session_state.campaign_id}/generate",
#                             json={"platforms": selected, "feedback": global_fb}
#                         )
#                         st.session_state.ads = [ad for ad in result["ads"] if ad["platform"] in selected]
#                         st.session_state.ad_version_num = result["version"]
#                         add_chat("agent", f"✅ v{result['version']} ready!")
#                         st.rerun()
#                     except Exception as e:
#                         st.error(str(e))
#             else:
#                 st.warning("Type some feedback first.")
#     st.markdown("</div>", unsafe_allow_html=True)

#     # Per-platform tabs
#     valid_platforms = [p for p in selected if p in ads_map]
#     tabs = st.tabs([f"{PLATFORMS[p]['icon']} {p}" for p in valid_platforms])
#     edited_ads = {}

#     for tab, platform in zip(tabs, valid_platforms):
#         ad    = ads_map[platform]
#         limit = PLATFORMS[platform]["max_chars"]
#         info  = PLATFORMS[platform]

#         with tab:
#             # ── Preview + Edit side by side ──────────────────────────────
#             prev_col, edit_col = st.columns([1, 1], gap="large")

#             # LEFT: Platform preview
#             with prev_col:
#                 st.markdown('<div class="ab-label">Live Preview</div>', unsafe_allow_html=True)
#                 render_platform_preview(platform, ad)

#             # RIGHT: Editor
#             with edit_col:
#                 st.markdown('<div class="ab-label">Ad Copy Editor</div>', unsafe_allow_html=True)
#                 edited = st.text_area(
#                     f"edit_{platform}",
#                     value=ad["content"], height=220,
#                     label_visibility="collapsed",
#                     key=f"edit_{platform}_{st.session_state.ad_version_num}"
#                 )
#                 edited_ads[platform] = {"ad_id": ad["id"], "content": edited}
#                 chars = len(edited)
#                 color = "var(--green)" if chars <= limit else "var(--rose)"
#                 st.markdown(f'<div style="text-align:right;font-size:11px;color:{color};margin-top:3px;font-family:\'Space Mono\',monospace">{chars:,} / {limit:,}</div>', unsafe_allow_html=True)

#                 # Text regen
#                 st.markdown("")
#                 st.markdown('<div class="ab-label">Text Feedback</div>', unsafe_allow_html=True)
#                 fb_c, btn_c = st.columns([4, 1])
#                 with fb_c:
#                     feedback = st.text_input(
#                         f"fb_{platform}", label_visibility="collapsed",
#                         placeholder="'more urgent' · 'add price' · 'funnier'…",
#                         key=f"fb_{platform}_{st.session_state.ad_version_num}"
#                     )
#                 with btn_c:
#                     if st.button("↺", key=f"regen_text_{platform}", help="Regenerate text"):
#                         fb_text = feedback.strip() or "Improve this ad copy"
#                         add_chat("human", f"[{platform}] Regen: {fb_text}")
#                         with st.spinner(f"Rewriting…"):
#                             try:
#                                 result = api("post",
#                                     f"/campaigns/{st.session_state.campaign_id}/generate",
#                                     json={"platforms": [platform], "feedback": fb_text}
#                                 )
#                                 new_ads = [a for a in result["ads"] if a["platform"] == platform]
#                                 if new_ads:
#                                     st.session_state.ads = [
#                                         new_ads[0] if a["platform"] == platform else a
#                                         for a in st.session_state.ads
#                                     ]
#                                     st.session_state.ad_version_num = result["version"]
#                                     add_chat("agent", f"✅ [{platform}] text rewritten (v{result['version']})")
#                                     st.rerun()
#                             except Exception as e:
#                                 st.error(str(e))

#                 # Image section
#                 st.markdown("")
#                 st.markdown('<div class="ab-label">Image</div>', unsafe_allow_html=True)

#                 if platform == "Instagram":
#                     st.markdown('<div style="font-size:11px;color:var(--green);margin-bottom:8px">✦ Image required &amp; auto-generated</div>', unsafe_allow_html=True)
#                     img_on = True
#                 else:
#                     img_on = st.checkbox(
#                         "Generate image for this platform",
#                         value=st.session_state.img_enabled.get(platform, False),
#                         key=f"img_on_{platform}"
#                     )
#                     st.session_state.img_enabled[platform] = img_on

#                 if img_on:
#                     src_keys   = list(IMAGE_SOURCES.keys())
#                     src_labels = list(IMAGE_SOURCES.values())
#                     current_src = st.session_state.img_sources.get(platform, "flux")
#                     src_idx    = src_keys.index(current_src) if current_src in src_keys else 0

#                     chosen_src_label = st.selectbox(
#                         f"src_{platform}", src_labels, index=src_idx,
#                         label_visibility="collapsed",
#                         key=f"src_{platform}_{st.session_state.ad_version_num}"
#                     )
#                     chosen_src = src_keys[src_labels.index(chosen_src_label)]
#                     st.session_state.img_sources[platform] = chosen_src

#                     current_img = ad.get("image_url", "")
#                     if current_img:
#                         st.image(current_img, use_container_width=True)

#                     # Image feedback input
#                     img_fb = st.text_input(
#                         f"img_fb_{platform}", label_visibility="collapsed",
#                         placeholder="Image feedback: 'warmer colors', 'outdoor setting', 'add product'…",
#                         key=f"img_fb_{platform}_{st.session_state.ad_version_num}",
#                         value=st.session_state.img_feedback.get(platform, "")
#                     )
#                     st.session_state.img_feedback[platform] = img_fb

#                     g1, g2 = st.columns(2)
#                     with g1:
#                         gen_label = "✦ Generate Image" if not current_img else "↺ New Image"
#                         if st.button(gen_label, key=f"gen_img_{platform}", use_container_width=True):
#                             with st.spinner(f"Generating…"):
#                                 try:
#                                     api("put", f"/ads/{ad['id']}", json={"content": edited_ads[platform]['content']})
#                                     endpoint = "regenerate-image" if current_img else "generate-image"
#                                     # Include feedback in prompt if present
#                                     query = f"?source={chosen_src}"
#                                     if img_fb.strip():
#                                         import urllib.parse
#                                         query += f"&feedback={urllib.parse.quote(img_fb.strip())}"
#                                     updated_ad = api("post", f"/ads/{ad['id']}/{endpoint}{query}")
#                                     st.session_state.ads = [
#                                         updated_ad if a["platform"] == platform else a
#                                         for a in st.session_state.ads
#                                     ]
#                                     add_chat("agent", f"✅ [{platform}] image generated via {chosen_src}")
#                                     st.rerun()
#                                 except Exception as e:
#                                     st.error(f"Image generation failed: {e}")
#                     with g2:
#                         if current_img and st.button("🔀 Shuffle", key=f"shuf_img_{platform}", use_container_width=True):
#                             with st.spinner("Shuffling…"):
#                                 try:
#                                     updated_ad = api("post", f"/ads/{ad['id']}/regenerate-image?source={chosen_src}")
#                                     st.session_state.ads = [
#                                         updated_ad if a["platform"] == platform else a
#                                         for a in st.session_state.ads
#                                     ]
#                                     add_chat("agent", f"✅ [{platform}] image shuffled")
#                                     st.rerun()
#                                 except Exception as e:
#                                     st.error(f"Shuffle failed: {e}")

#             st.markdown('<div style="height:16px"></div>', unsafe_allow_html=True)
#             st.markdown('<hr style="margin:4px 0 16px"/>', unsafe_allow_html=True)

#             # Per-platform post button
#             pc1, pc2 = st.columns([2, 1])
#             with pc2:
#                 if st.button(
#                     f"🚀 Post to {platform} Only",
#                     key=f"post_only_{platform}",
#                     use_container_width=True,
#                     type="primary"
#                 ):
#                     add_chat("human", f"Post to {platform} only.")
#                     with st.spinner(f"Posting to {platform}…"):
#                         try:
#                             api("put", f"/ads/{ad['id']}", json={"content": edited_ads[platform]['content']})
#                             post = api("post", f"/ads/{ad['id']}/post")
#                             # Merge into existing posts
#                             existing = [p for p in st.session_state.posts if p.get("platform") != platform]
#                             st.session_state.posts = existing + [post]
#                             add_chat("agent", f"🚀 <b>{platform}</b> ad is live!")
#                             st.success(f"✅ Posted to {platform}!")
#                         except ValueError as e:
#                             st.error(str(e))

#     # ── Bottom action bar ─────────────────────────────────────────────────────
#     st.markdown('<div class="section-divider"><span>Post Actions</span></div>', unsafe_allow_html=True)
#     st.markdown('<div class="ab-card" style="padding:20px 24px">', unsafe_allow_html=True)

#     ac1, ac2, ac3 = st.columns(3)
#     with ac1:
#         if st.button("✅ Post to All Platforms", type="primary", use_container_width=True):
#             add_chat("human", "Post to all platforms.")
#             errors, posted = [], []
#             with st.spinner("Posting to all platforms…"):
#                 for platform, info in edited_ads.items():
#                     try:
#                         api("put", f"/ads/{info['ad_id']}", json={"content": info["content"]})
#                         fresh_ads = api("get", f"/campaigns/{st.session_state.campaign_id}/ads")
#                         fresh_ad  = next((a for a in fresh_ads if a["id"] == info["ad_id"]), None)
#                         if fresh_ad:
#                             st.session_state.ads = [
#                                 fresh_ad if a["id"] == info["ad_id"] else a
#                                 for a in st.session_state.ads
#                             ]
#                         post = api("post", f"/ads/{info['ad_id']}/post")
#                         posted.append(post)
#                     except ValueError as e:
#                         errors.append(f"{platform}: {e}")
#             if posted:
#                 st.session_state.posts = posted
#                 add_chat("agent", f"🚀 <b>{len(posted)} ads live!</b> Metrics auto-refresh every 30 min.")
#                 st.session_state.step = "monitor"
#                 st.rerun()
#             for err in errors:
#                 st.error(err)

#     with ac2:
#         if st.button("🔄 Regenerate All", use_container_width=True):
#             add_chat("human", "Regenerate all ads.")
#             st.session_state.step = "generating"; st.rerun()

#     with ac3:
#         if st.button("← Change Platforms", use_container_width=True):
#             st.session_state.step = "platform_select"; st.rerun()

#     st.markdown("</div>", unsafe_allow_html=True)

#     # View posted if any
#     if st.session_state.posts:
#         if st.button("📊 View Posted Ads →", use_container_width=True):
#             st.session_state.step = "monitor"; st.rerun()

# # ═════════════════════════════════════════════════════════════════════════════
# # STEP 5 — MONITOR
# # ═════════════════════════════════════════════════════════════════════════════
# elif st.session_state.step == "monitor":

#     hdr1, hdr2, hdr3 = st.columns([4, 1, 1])
#     with hdr1:
#         st.markdown('<div style="font-family:\'Syne\',sans-serif;font-size:22px;font-weight:800;color:var(--bright);margin-bottom:4px">📊 Posted Ads & Metrics</div>', unsafe_allow_html=True)
#     with hdr2:
#         if st.button("🔄 Refresh", use_container_width=True):
#             for post in st.session_state.posts:
#                 if post.get("status") == "live":
#                     try: api("post", f"/posts/{post['id']}/metrics/refresh")
#                     except: pass
#             st.rerun()
#     with hdr3:
#         if st.button("← Review Ads", use_container_width=True):
#             st.session_state.step = "review"; st.rerun()

#     if st.button("＋ New Campaign", type="primary"):
#         for k in list(st.session_state.keys()): del st.session_state[k]
#         st.rerun()

#     try:
#         all_posts = api("get", f"/campaigns/{st.session_state.campaign_id}/posts")
#     except Exception:
#         all_posts = st.session_state.posts

#     active   = [p for p in all_posts if p.get("status") == "live"]
#     inactive = [p for p in all_posts if p.get("status") == "archived"]

#     if not active:
#         st.info("No active posts yet. Go back to review and post your ads.")

#     for post in active:
#         m    = post.get("latest_metrics") or {}
#         eng  = m.get("eng_rate", 0)
#         label, css = eng_badge(eng)
#         is_low = eng < 2.5
#         icon = PLATFORMS.get(post["platform"], {}).get("icon", "📱")
#         posted_dt = datetime.fromisoformat(post["posted_at"]).strftime("%b %d %H:%M")
#         plat_color = PLATFORMS.get(post["platform"], {}).get("color", "#5b6ef5")

#         card_cls = "posted-card low-eng" if is_low else "posted-card"
#         st.markdown(f'<div class="{card_cls}">', unsafe_allow_html=True)

#         # Low engagement banner
#         if is_low:
#             st.markdown(f"""
#             <div class="low-eng-banner">
#               📉 <b>Low engagement detected on {post['platform']}.</b>
#               Consider regenerating this ad with a stronger hook.
#             </div>""", unsafe_allow_html=True)

#         # Header row
#         row1, row2 = st.columns([3, 1])
#         with row1:
#             st.markdown(f"""
#             <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
#               <div style="font-size:28px">{icon}</div>
#               <div>
#                 <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:var(--bright)">{post['platform']}</div>
#                 <div style="font-size:12px;color:var(--muted);font-family:'Space Mono',monospace">
#                   {post.get('hours_live',0)}h live · {posted_dt} · ID: {post.get('platform_post_id','—')[:18]}
#                 </div>
#               </div>
#               <span class="eng-badge {css}" style="margin-left:12px">{label} — {eng}%</span>
#             </div>""", unsafe_allow_html=True)

#         # Metrics
#         mc1, mc2, mc3, mc4, mc5 = st.columns(5)
#         mc1.metric("👁️ Views",    f"{m.get('views', 0):,}")
#         mc2.metric("❤️ Likes",    m.get("likes", 0))
#         mc3.metric("🔁 Shares",   m.get("shares", 0))
#         mc4.metric("💬 Comments", m.get("comments", 0))
#         mc5.metric("🖱️ Clicks",   m.get("clicks", 0))

#         # Ad content preview
#         ad_content = next((a["content"] for a in st.session_state.ads if a.get("id") == post.get("ad_id")), "—")
#         ad_img     = next((a.get("image_url","") for a in st.session_state.ads if a.get("id") == post.get("ad_id")), "")
#         ad_obj     = next((a for a in st.session_state.ads if a.get("id") == post.get("ad_id")), {})

#         with st.expander(f"📄 View Ad Content — {post['platform']}"):
#             if ad_img:
#                 ic1, ic2 = st.columns([1, 2])
#                 with ic1: st.image(ad_img, use_container_width=True)
#                 with ic2:
#                     st.markdown(f"""
#                     <div style="background:var(--surface);border:1px solid var(--border2);
#                       border-radius:12px;padding:16px 18px;font-size:14px;
#                       line-height:1.75;color:var(--text);white-space:pre-wrap;word-break:break-word">
#                       {ad_content}
#                     </div>""", unsafe_allow_html=True)
#             else:
#                 st.markdown(f"""
#                 <div style="background:var(--surface);border:1px solid var(--border2);
#                   border-radius:12px;padding:16px 18px;font-size:14px;
#                   line-height:1.75;color:var(--text);white-space:pre-wrap;word-break:break-word">
#                   {ad_content}
#                 </div>""", unsafe_allow_html=True)

#         # Action row
#         act1, act2, act3, act4 = st.columns(4)
#         with act1:
#             if st.button("🗑️ Delete Post", key=f"del_{post['id']}", use_container_width=True):
#                 try: api("delete", f"/posts/{post['id']}"); st.rerun()
#                 except Exception as e: st.error(str(e))

#         with act2:
#             if st.button("✏️ Regenerate Ad", key=f"regen_{post['id']}", use_container_width=True,
#                          type="primary" if is_low else "secondary"):
#                 add_chat("human", f"Regenerate {post['platform']} ad.")
#                 with st.spinner(f"Rewriting {post['platform']} ad…"):
#                     try:
#                         feedback_msg = (
#                             "Previous had poor engagement. Add a stronger hook, more urgency."
#                             if is_low else "Improve this ad copy."
#                         )
#                         result = api("post",
#                             f"/campaigns/{st.session_state.campaign_id}/generate",
#                             json={"platforms": [post["platform"]], "feedback": feedback_msg}
#                         )
#                         new_ads = [a for a in result["ads"] if a["platform"] == post["platform"]]
#                         if new_ads:
#                             st.session_state.ads = [
#                                 new_ads[0] if a["platform"] == post["platform"] else a
#                                 for a in st.session_state.ads
#                             ]
#                             st.session_state.selected_platforms = [post["platform"]]
#                             st.session_state.ad_version_num = result["version"]
#                             add_chat("agent", f"✅ [{post['platform']}] improved v{result['version']} ready.")
#                             # Archive old post
#                             try: api("delete", f"/posts/{post['id']}")
#                             except: pass
#                             st.session_state.step = "review"
#                             st.rerun()
#                     except Exception as e:
#                         st.error(str(e))

#         with act3:
#             if st.button("🖼️ Regen Image", key=f"regen_img_{post['id']}", use_container_width=True):
#                 if ad_obj:
#                     with st.spinner("Regenerating image…"):
#                         try:
#                             src = st.session_state.img_sources.get(post["platform"], "flux")
#                             updated_ad = api("post", f"/ads/{ad_obj['id']}/regenerate-image?source={src}")
#                             st.session_state.ads = [
#                                 updated_ad if a["id"] == ad_obj["id"] else a
#                                 for a in st.session_state.ads
#                             ]
#                             add_chat("agent", f"✅ [{post['platform']}] image refreshed")
#                             st.rerun()
#                         except Exception as e:
#                             st.error(str(e))

#         with act4:
#             if st.button("📈 Refresh Metrics", key=f"refm_{post['id']}", use_container_width=True):
#                 try:
#                     api("post", f"/posts/{post['id']}/metrics/refresh")
#                     st.rerun()
#                 except Exception as e:
#                     st.error(str(e))

#         st.markdown('</div>', unsafe_allow_html=True)

#     # Archived
#     if inactive:
#         with st.expander(f"🗃️ Archived Posts ({len(inactive)})"):
#             for p in inactive:
#                 m = p.get("latest_metrics") or {}
#                 eng_val = m.get("eng_rate", 0)
#                 lbl, css = eng_badge(eng_val)
#                 st.markdown(
#                     f'`{PLATFORMS.get(p["platform"],{}).get("icon","📱")} {p["platform"]}` — '
#                     f'Final: **{eng_val}%** · {m.get("views",0):,} views '
#                     f'<span class="eng-badge {css}" style="font-size:11px">{lbl}</span>',
#                     unsafe_allow_html=True
#                 )

#     # Low engagement handler
#     low_posts = [p for p in active
#                  if (p.get("latest_metrics") or {}).get("eng_rate", 99) < 2.5
#                  and not st.session_state.low_eng_shown]
#     if low_posts:
#         names = ", ".join([f"<b>{p['platform']}</b>" for p in low_posts])
#         add_chat("agent", f"📉 Low engagement on {names}. Click 'Regenerate Ad' on that platform.")
#         st.session_state.low_eng_shown = True
#         st.rerun()

# # ── Footer ────────────────────────────────────────────────────────────────────
# st.markdown('<p style="text-align:center;color:#1c2238;font-size:11px;margin-top:60px;padding-bottom:24px;font-family:\'Space Mono\',monospace">AdBot v3 · Gemini AI · FastAPI · SQLite · Real Platform APIs</p>', unsafe_allow_html=True)

"""
AdBot Streamlit Frontend — Full Redesign v3
Features:
  - Animated particle background
  - Platform-native post preview cards (Instagram, Facebook, Reddit, Telegram, Discord, LinkedIn)
  - Auto-generate image for Instagram; optional for others
  - Per-platform text & image regeneration with feedback
  - Post to All / Post to This Platform only
  - Posted Ads section with real engagement metrics
  - Low-engagement suggestions
  - Chat history sidebar

Run backend first:  uvicorn main:app --reload --port 8000
Run frontend:       streamlit run app.py
"""

import os, re, copy, requests, time
import streamlit as st
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")

#  Page config 
st.set_page_config(
    page_title="AdBot — AI Ad Platform",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── FULL CSS + Animated Background ───────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=Space+Mono:wght@400;700&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&display=swap');

:root {
  --bg:        #060810;
  --surface:   #0c0f1a;
  --card:      #111422;
  --card2:     #161b2e;
  --border:    #1c2238;
  --border2:   #242d47;
  --accent:    #4f6ef7;
  --accent2:   #7b93ff;
  --accentRGB: 79,110,247;
  --glow:      rgba(79,110,247,0.18);
  --green:     #1ee8a0;
  --greenRGB:  30,232,160;
  --amber:     #ffb547;
  --rose:      #ff5f87;
  --purple:    #a78bfa;
  --cyan:      #22d3ee;
  --muted:     #3d4866;
  --soft:      #7a86a8;
  --text:      #c4cde8;
  --bright:    #eaefff;
  --font-head: 'Syne', sans-serif;
  --font-body: 'DM Sans', sans-serif;
  --font-mono: 'Space Mono', monospace;
}

/* ── Reset & Base ── */
html, body, [data-testid="stAppViewContainer"] {
  background: var(--bg) !important;
  color: var(--text) !important;
  font-family: var(--font-body) !important;
}
[data-testid="stAppViewContainer"] > .main { background: transparent !important; }
[data-testid="stHeader"] {
  background: rgba(6,8,16,0.92) !important;
  backdrop-filter: blur(24px);
  border-bottom: 1px solid var(--border) !important;
}
.block-container { padding: 1.5rem 2rem 5rem !important; max-width: 100% !important; }
#MainMenu, footer, [data-testid="stToolbar"] { display: none !important; }
h1,h2,h3 { font-family: var(--font-head) !important; color: var(--bright) !important; }
p, li, label { color: var(--text) !important; }
hr { border-color: var(--border) !important; margin: 1.5rem 0 !important; }

/* ── Particle Canvas ── */
#particle-canvas {
  position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  pointer-events: none; z-index: 0; opacity: 0.6;
}

/* ── Animated Grid Background ── */
[data-testid="stAppViewContainer"]::before {
  content: '';
  position: fixed; inset: 0;
  background-image:
    linear-gradient(rgba(79,110,247,0.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(79,110,247,0.03) 1px, transparent 1px);
  background-size: 60px 60px;
  pointer-events: none; z-index: 0;
  animation: gridDrift 20s ease-in-out infinite alternate;
}
@keyframes gridDrift {
  from { background-position: 0 0; }
  to   { background-position: 30px 30px; }
}

/* ── Ambient Orbs ── */
[data-testid="stAppViewContainer"]::after {
  content: '';
  position: fixed; inset: 0; pointer-events: none; z-index: 0;
  background:
    radial-gradient(ellipse 600px 400px at 10% 20%, rgba(79,110,247,0.06) 0%, transparent 70%),
    radial-gradient(ellipse 500px 350px at 90% 80%, rgba(167,139,250,0.05) 0%, transparent 70%),
    radial-gradient(ellipse 400px 300px at 50% 50%, rgba(30,232,160,0.03) 0%, transparent 70%);
  animation: orbPulse 8s ease-in-out infinite alternate;
}
@keyframes orbPulse {
  from { opacity: 0.7; } to { opacity: 1; }
}

/* ── Sidebar ── */
[data-testid="stSidebar"] {
  background: var(--surface) !important;
  border-right: 1px solid var(--border) !important;
}
[data-testid="stSidebar"] .block-container { padding: 1rem !important; }

/* ── Inputs ── */
[data-testid="stTextInput"] input,
[data-testid="stTextArea"] textarea,
[data-baseweb="textarea"] textarea {
  background: var(--surface) !important; border: 1px solid var(--border2) !important;
  border-radius: 10px !important; color: var(--text) !important;
  font-family: var(--font-body) !important; font-size: 14px !important;
  caret-color: var(--accent) !important; transition: border-color .2s, box-shadow .2s !important;
}
[data-testid="stTextInput"] input:focus,
[data-testid="stTextArea"] textarea:focus {
  border-color: var(--accent) !important; box-shadow: 0 0 0 3px var(--glow) !important;
}
[data-testid="stTextInput"] label,
[data-testid="stTextArea"] label { color: var(--soft) !important; font-size: 12px !important; }

/* ── Selectbox ── */
[data-testid="stSelectbox"] > div > div {
  background: var(--surface) !important; border: 1px solid var(--border2) !important;
  border-radius: 10px !important; color: var(--text) !important;
}
[data-baseweb="select"] ul { background: var(--card2) !important; border: 1px solid var(--border2) !important; }
[data-baseweb="select"] li:hover { background: var(--border2) !important; }
[data-baseweb="select"] li { color: var(--text) !important; }

/* ── Checkboxes ── */
[data-testid="stCheckbox"] label { color: var(--text) !important; font-size: 14px !important; }
[data-testid="stCheckbox"] span[aria-checked="true"] { background: var(--accent) !important; border-color: var(--accent) !important; }

/* ── Buttons ── */
[data-testid="stButton"] > button {
  background: var(--card) !important; color: var(--soft) !important;
  border: 1px solid var(--border2) !important; border-radius: 10px !important;
  font-family: var(--font-body) !important; font-weight: 600 !important;
  font-size: 13px !important; transition: all .2s !important; padding: 0.45rem 1rem !important;
  position: relative; z-index: 1;
}
[data-testid="stButton"] > button:hover {
  border-color: var(--accent) !important; color: var(--accent2) !important;
  box-shadow: 0 0 0 2px var(--glow) !important; transform: translateY(-1px) !important;
}
[data-testid="stButton"] > button[kind="primary"] {
  background: linear-gradient(135deg, var(--accent), #6d5cf7) !important;
  color: #fff !important; border-color: transparent !important;
  box-shadow: 0 4px 24px rgba(var(--accentRGB),.4) !important;
}
[data-testid="stButton"] > button[kind="primary"]:hover {
  background: linear-gradient(135deg, var(--accent2), #8b7cf8) !important;
  transform: translateY(-2px) !important;
  box-shadow: 0 8px 32px rgba(var(--accentRGB),.55) !important;
}

/* ── Tabs ── */
[data-testid="stTabs"] [data-baseweb="tab-list"] {
  background: var(--surface) !important; border-radius: 12px !important;
  padding: 4px !important; border: 1px solid var(--border) !important; gap: 3px !important;
}
[data-testid="stTabs"] [data-baseweb="tab"] {
  background: transparent !important; color: var(--muted) !important;
  border-radius: 8px !important; font-family: var(--font-body) !important;
  font-weight: 600 !important; border: none !important; font-size: 13px !important;
}
[data-testid="stTabs"] [aria-selected="true"] {
  background: var(--card2) !important; color: var(--accent2) !important;
  border: 1px solid var(--border2) !important;
}
[data-testid="stTabs"] [data-baseweb="tab-highlight"],
[data-testid="stTabs"] [data-baseweb="tab-border"] { display: none !important; }

/* ── Metrics ── */
[data-testid="stMetric"] {
  background: var(--card) !important; border: 1px solid var(--border) !important;
  border-radius: 12px !important; padding: 14px 18px !important;
  transition: border-color .2s !important;
}
[data-testid="stMetric"]:hover { border-color: var(--border2) !important; }
[data-testid="stMetricLabel"] { color: var(--muted) !important; font-size: 11px !important; font-family: var(--font-mono) !important; }
[data-testid="stMetricValue"] { color: var(--bright) !important; font-family: var(--font-head) !important; }

/* ── Alerts ── */
[data-testid="stSuccess"] { background: rgba(var(--greenRGB),.07) !important; border: 1px solid rgba(var(--greenRGB),.2) !important; border-radius: 10px !important; color: var(--green) !important; }
[data-testid="stError"]   { background: rgba(255,95,135,.07) !important; border: 1px solid rgba(255,95,135,.2) !important; border-radius: 10px !important; }
[data-testid="stWarning"] { background: rgba(255,181,71,.07) !important; border: 1px solid rgba(255,181,71,.2) !important; border-radius: 10px !important; color: var(--amber) !important; }
[data-testid="stInfo"]    { background: rgba(var(--accentRGB),.07) !important; border: 1px solid rgba(var(--accentRGB),.2) !important; border-radius: 10px !important; color: var(--accent2) !important; }

/* ── Expander ── */
[data-testid="stExpander"] { background: var(--card) !important; border: 1px solid var(--border) !important; border-radius: 12px !important; }
[data-testid="stExpander"] summary { color: var(--text) !important; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: var(--bg); }
::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 10px; }

/* ── Sidebar — full chat-app styling ── */
[data-testid="stSidebar"] {
  background: #07090f !important;
  border-right: 1px solid #141824 !important;
  position: relative !important;
  z-index: 100 !important;
}
[data-testid="stSidebar"] > div:first-child {
  height: 100vh !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  display: flex !important;
  flex-direction: column !important;
}
[data-testid="stSidebar"] .block-container {
  padding: 0 12px 80px 12px !important;
  flex: 1 !important;
}
[data-testid="stSidebar"] > div { padding: 0 !important; }

/* Hide default Streamlit sidebar padding */
[data-testid="stSidebarContent"] {
  padding: 0 !important;
  overflow-x: hidden !important;
  height: 100% !important;
}

/* Sidebar search input */
[data-testid="stSidebar"] [data-testid="stTextInput"] {
  margin: 0 !important;
}
[data-testid="stSidebar"] [data-testid="stTextInput"] input {
  background: rgba(255,255,255,0.04) !important;
  border: 1px solid #1c2238 !important;
  border-radius: 8px !important;
  font-size: 12px !important;
  padding: 8px 12px 8px 32px !important;
  color: #c4cde8 !important;
  width: 100% !important;
}
[data-testid="stSidebar"] [data-testid="stTextInput"] input:focus {
  border-color: #4f6ef7 !important;
  background: rgba(79,110,247,0.05) !important;
  box-shadow: 0 0 0 2px rgba(79,110,247,0.12) !important;
}
[data-testid="stSidebar"] [data-testid="stTextInput"] input::placeholder {
  color: #3d4866 !important;
}

/* Sidebar all buttons reset */
[data-testid="stSidebar"] [data-testid="stButton"] > button {
  font-size: 12px !important;
  padding: 6px 10px !important;
  border-radius: 8px !important;
  margin: 0 !important;
  opacity: 1 !important;
  height: auto !important;
  background: transparent !important;
  border: 1px solid #1c2238 !important;
  color: #7a86a8 !important;
  transition: all .15s !important;
  transform: none !important;
}
[data-testid="stSidebar"] [data-testid="stButton"] > button:hover {
  background: rgba(79,110,247,0.1) !important;
  border-color: rgba(79,110,247,0.3) !important;
  color: #7b93ff !important;
  transform: none !important;
  box-shadow: none !important;
}
/* Primary new-chat button */
[data-testid="stSidebar"] [data-testid="stButton"] > button[kind="primary"] {
  background: linear-gradient(135deg, #4f6ef7, #6d5cf7) !important;
  color: #fff !important;
  border-color: transparent !important;
  box-shadow: 0 2px 12px rgba(79,110,247,0.3) !important;
  font-weight: 700 !important;
}
[data-testid="stSidebar"] [data-testid="stButton"] > button[kind="primary"]:hover {
  box-shadow: 0 4px 18px rgba(79,110,247,0.45) !important;
  background: linear-gradient(135deg, #6272f8, #7b6df8) !important;
}
/* Disabled (Active) session button */
[data-testid="stSidebar"] [data-testid="stButton"] > button:disabled {
  opacity: 1 !important;
  background: rgba(79,110,247,0.12) !important;
  border-color: rgba(79,110,247,0.25) !important;
  color: #7b93ff !important;
  cursor: default !important;
}

/* Expanders inside sidebar */
[data-testid="stSidebar"] [data-testid="stExpander"] {
  background: transparent !important;
  border: none !important;
  border-radius: 0 !important;
}
[data-testid="stSidebar"] [data-testid="stExpander"] summary {
  font-size: 11px !important;
  color: #3d4866 !important;
  font-family: 'Space Mono', monospace !important;
  font-weight: 700 !important;
  letter-spacing: 1px !important;
  text-transform: uppercase !important;
  padding: 6px 0 !important;
}
[data-testid="stSidebar"] [data-testid="stExpander"] summary:hover {
  color: #7a86a8 !important;
}

/* Sidebar divider */
[data-testid="stSidebar"] hr {
  border-color: #141824 !important;
  margin: 8px 0 !important;
}

/* Sidebar chat messages */
.sb-chat-bot {
  background: rgba(255,255,255,0.03);
  border-left: 2px solid #4f6ef7;
  border-radius: 0 8px 8px 0;
  padding: 8px 10px;
  margin-bottom: 6px;
  font-size: 12px;
  line-height: 1.5;
  color: #c4cde8;
}
.sb-chat-user {
  background: rgba(79,110,247,0.06);
  border-right: 2px solid rgba(79,110,247,0.3);
  border-radius: 8px 0 0 8px;
  padding: 8px 10px;
  margin-bottom: 6px;
  font-size: 12px;
  line-height: 1.5;
  color: #c4cde8;
  text-align: right;
}
.sb-chat-label {
  font-size: 9px;
  color: #3d4866;
  font-weight: 700;
  letter-spacing: 1px;
  text-transform: uppercase;
  font-family: 'Space Mono', monospace;
  margin-bottom: 3px;
}

/* Session group date label */
.sess-group-label {
  font-size: 9px;
  font-weight: 700;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: #3d4866;
  font-family: 'Space Mono', monospace;
  padding: 10px 16px 4px;
}

/* Session item card */
.sess-item {
  padding: 10px 16px;
  cursor: pointer;
  transition: background .15s;
  border-left: 2px solid transparent;
  margin: 1px 0;
}
.sess-item:hover {
  background: rgba(255,255,255,0.03);
  border-left-color: #242d47;
}
.sess-item.active {
  background: rgba(79,110,247,0.08);
  border-left-color: #4f6ef7;
}
.sess-item-title {
  font-size: 13px;
  font-weight: 600;
  color: #eaefff;
  font-family: 'Syne', sans-serif;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 180px;
  margin-bottom: 3px;
}
.sess-item.active .sess-item-title { color: #7b93ff; }
.sess-item-meta {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 11px;
  color: #3d4866;
  flex-wrap: wrap;
}
.sess-type-pill {
  font-size: 9px;
  font-weight: 700;
  font-family: 'Space Mono', monospace;
  background: rgba(79,110,247,0.1);
  color: #7b93ff;
  padding: 1px 6px;
  border-radius: 4px;
  letter-spacing: 0.3px;
}
.sess-step-dot {
  width: 5px; height: 5px; border-radius: 50%;
  display: inline-block; flex-shrink: 0;
}
/* ────────────────────────────────────────────────────────
   CUSTOM COMPONENTS
──────────────────────────────────────────────────────── */

/* Hero */
.ab-hero {
  position: relative; overflow: hidden;
  padding: 56px 0 44px; margin: -1.5rem -2rem 2.5rem;
  background: linear-gradient(160deg, #060810 0%, #0a0f1e 60%, #0d0f1f 100%);
  border-bottom: 1px solid var(--border);
}
.ab-hero-glow {
  position: absolute; top: -60px; right: -40px;
  width: 500px; height: 500px; border-radius: 50%;
  background: radial-gradient(circle, rgba(79,110,247,.12) 0%, transparent 65%);
  animation: heroGlow 6s ease-in-out infinite alternate;
}
.ab-hero-glow2 {
  position: absolute; bottom: -80px; left: 5%;
  width: 360px; height: 360px; border-radius: 50%;
  background: radial-gradient(circle, rgba(30,232,160,.06) 0%, transparent 65%);
  animation: heroGlow 8s ease-in-out infinite alternate-reverse;
}
@keyframes heroGlow { from { transform: scale(1); } to { transform: scale(1.2); } }
.ab-hero-inner { padding: 0 2rem; position: relative; z-index: 1; }
.ab-badge {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 5px 14px; border-radius: 20px;
  background: rgba(79,110,247,.1); border: 1px solid rgba(79,110,247,.25);
  color: var(--accent2); font-size: 10px; font-weight: 700;
  letter-spacing: 2px; text-transform: uppercase; margin-bottom: 18px;
  font-family: var(--font-mono);
}
.ab-badge::before {
  content: ''; width: 6px; height: 6px; border-radius: 50%;
  background: var(--green); box-shadow: 0 0 8px var(--green);
  animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.3; } }
.ab-hero h1 {
  font-size: 54px !important; font-weight: 800 !important;
  color: var(--bright) !important; line-height: 1.08 !important;
  letter-spacing: -1.5px !important; margin-bottom: 14px !important;
  font-family: var(--font-head) !important;
}
.ab-hero h1 em { color: var(--accent2); font-style: normal; }
.ab-hero p { color: var(--soft) !important; font-size: 15px; max-width: 520px; line-height: 1.7; }

/* Step bar */
.step-bar { display:flex; align-items:center; justify-content:center; gap:0; padding: 20px 0 28px; flex-wrap: wrap; }
.step-node { display:flex; align-items:center; gap:8px; }
.step-circle {
  width: 34px; height: 34px; border-radius: 50%; display:flex; align-items:center; justify-content:center;
  font-size:11px; font-weight:800; border:2px solid var(--border2); color:var(--muted);
  background:var(--surface); transition:all .4s; font-family: var(--font-mono);
}
.step-circle.done  { background:rgba(var(--greenRGB),.1); color:var(--green); border-color:var(--green); }
.step-circle.active{
  background: linear-gradient(135deg, var(--accent), #6d5cf7);
  color:#fff; border-color:transparent;
  box-shadow: 0 0 20px rgba(var(--accentRGB),.5), 0 0 40px rgba(var(--accentRGB),.2);
  animation: stepPulse 2s ease-in-out infinite;
}
@keyframes stepPulse { 0%,100% { box-shadow: 0 0 20px rgba(79,110,247,.5); } 50% { box-shadow: 0 0 30px rgba(79,110,247,.8); } }
.step-text { font-size:12px; font-weight:600; color:var(--muted); font-family: var(--font-body); }
.step-text.active  { color: var(--text); }
.step-text.done    { color: var(--green); }
.step-connector { width:36px; height:1px; margin:0 8px; transition: background .4s; }
.step-connector.done-line { background: linear-gradient(90deg, var(--green), rgba(var(--greenRGB),.3)); }
.step-connector.plain { background: var(--border); }

/* Cards */
.ab-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 16px; padding: 26px 30px; margin-bottom: 16px;
  position: relative; z-index: 1;
  transition: border-color .2s;
}
.ab-card:hover { border-color: var(--border2); }
.ab-label {
  font-size: 10px; font-weight: 700; letter-spacing: 2px;
  text-transform: uppercase; color: var(--muted); margin-bottom: 10px;
  font-family: var(--font-mono);
}
.ab-ptag {
  display: inline-flex; align-items: center; gap: 5px;
  padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600;
  margin: 3px; background: rgba(var(--accentRGB),.1);
  border: 1px solid rgba(var(--accentRGB),.2); color: var(--accent2);
  font-family: var(--font-body);
}
.ab-ptag.green { background: rgba(var(--greenRGB),.1); border-color: rgba(var(--greenRGB),.2); color: var(--green); }
.ab-ptag.amber { background: rgba(255,181,71,.1); border-color: rgba(255,181,71,.2); color: var(--amber); }
.ab-ptag.rose  { background: rgba(255,95,135,.1); border-color: rgba(255,95,135,.2); color: var(--rose); }

/* ── PLATFORM PREVIEW CARDS ── */
/* Instagram */
.preview-instagram {
  background: #fff; border-radius: 12px; overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  max-width: 420px; box-shadow: 0 20px 60px rgba(0,0,0,.5);
  border: 1px solid #dbdbdb;
}
.ig-header {
  display: flex; align-items: center; gap: 10px;
  padding: 12px 14px; border-bottom: 1px solid #efefef;
}
.ig-avatar {
  width: 34px; height: 34px; border-radius: 50%;
  background: linear-gradient(45deg, #f09433,#e6683c,#dc2743,#cc2366,#bc1888);
  display: flex; align-items:center; justify-content:center; color:#fff; font-size:13px; font-weight:700;
}
.ig-username { font-size: 13px; font-weight: 600; color: #262626; }
.ig-location { font-size: 11px; color: #737373; }
.ig-image { width: 100%; aspect-ratio: 1/1; background: #f0f0f0; object-fit: cover; display:block; }
.ig-image-placeholder { width:100%; aspect-ratio:1/1; background: linear-gradient(135deg,#f5f5f5,#e8e8e8); display:flex; align-items:center; justify-content:center; color:#aaa; font-size:40px; }
.ig-actions { padding: 10px 14px 6px; display:flex; gap:14px; }
.ig-action { font-size: 22px; cursor: pointer; }
.ig-likes { padding: 0 14px 6px; font-size:13px; font-weight:600; color:#262626; }
.ig-caption { padding: 2px 14px 10px; font-size:13px; color:#262626; line-height:1.5; }
.ig-caption .ig-name { font-weight:700; margin-right:5px; }
.ig-hashtags { color: #003569; }
.ig-time { padding: 0 14px 12px; font-size:11px; color:#8e8e8e; text-transform:uppercase; }

/* Facebook */
.preview-facebook {
  background: #fff; border-radius: 10px; overflow: hidden;
  font-family: Helvetica, Arial, sans-serif; max-width: 500px;
  box-shadow: 0 20px 60px rgba(0,0,0,.5); border: 1px solid #ddd;
}
.fb-header { display:flex; align-items:center; gap:10px; padding:12px 14px; }
.fb-avatar { width:42px; height:42px; border-radius:50%; background: linear-gradient(135deg,#1877f2,#42a5f5); display:flex; align-items:center; justify-content:center; color:#fff; font-size:16px; font-weight:700; }
.fb-name { font-size:14px; font-weight:700; color:#050505; }
.fb-meta { font-size:12px; color:#65676b; display:flex; align-items:center; gap:4px; }
.fb-content { padding: 0 14px 12px; font-size:14px; color:#050505; line-height:1.55; }
.fb-image { width:100%; background:#f0f0f0; }
.fb-reactions { padding: 8px 14px; border-top:1px solid #e4e6eb; border-bottom:1px solid #e4e6eb; display:flex; justify-content:space-between; font-size:13px; color:#65676b; }
.fb-actions { display:flex; gap:0; }
.fb-action-btn { flex:1; text-align:center; padding:8px; font-size:13px; color:#65676b; font-weight:600; border-top:none; cursor:pointer; }

/* Telegram */
.preview-telegram {
  background: #1c2733; border-radius: 14px; overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 440px;
  box-shadow: 0 20px 60px rgba(0,0,0,.6);
}
.tg-header { background: #2b5278; padding: 12px 16px; display:flex; align-items:center; gap:10px; }
.tg-icon { width:38px; height:38px; border-radius:50%; background: linear-gradient(135deg,#2b9fda,#1da1f2); display:flex; align-items:center; justify-content:center; color:#fff; font-size:16px; }
.tg-channel-name { font-size:14px; font-weight:700; color:#fff; }
.tg-subscribers { font-size:11px; color:rgba(255,255,255,.6); }
.tg-msg { margin:10px 12px; background: #2b3d4f; border-radius:10px; padding:12px 14px; }
.tg-msg-text { font-size:14px; color:#e1e8f0; line-height:1.55; }
.tg-msg-text b { color:#fff; font-weight:700; }
.tg-msg-image { width:100%; border-radius:8px; margin-bottom:10px; }
.tg-msg-meta { font-size:11px; color:rgba(225,232,240,.45); text-align:right; margin-top:8px; }
.tg-views { display:flex; align-items:center; gap:4px; font-size:12px; color:rgba(225,232,240,.5); padding: 6px 14px 10px; }

/* Discord */
.preview-discord {
  background: #313338; border-radius: 10px; overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 460px;
  box-shadow: 0 20px 60px rgba(0,0,0,.6);
}
.dc-header { background: #2b2d31; padding: 10px 14px; display:flex; align-items:center; gap:8px; border-bottom:1px solid #1e1f22; }
.dc-hash { color:#80848e; font-size:20px; font-weight:700; }
.dc-channel-name { font-size:14px; font-weight:700; color:#f2f3f5; }
.dc-msg { padding: 14px 14px 10px; display:flex; gap:12px; }
.dc-avatar { width:40px; height:40px; border-radius:50%; background: linear-gradient(135deg,#5865f2,#7289da); flex-shrink:0; display:flex; align-items:center; justify-content:center; color:#fff; font-size:16px; font-weight:700; }
.dc-msg-right { flex:1; }
.dc-username { font-size:14px; font-weight:700; color:#f2f3f5; }
.dc-bot-badge { background:#5865f2; color:#fff; font-size:9px; font-weight:700; padding:2px 5px; border-radius:3px; margin-left:4px; letter-spacing:.5px; }
.dc-timestamp { font-size:11px; color:#80848e; margin-left:6px; }
.dc-text { font-size:14px; color:#dcddde; line-height:1.55; margin-top:4px; }
.dc-embed { margin-top:10px; border-left:4px solid #5865f2; background:#2b2d31; border-radius:0 4px 4px 0; padding:10px 14px; }
.dc-embed-img { width:100%; border-radius:6px; margin-top:8px; }

/* LinkedIn */
.preview-linkedin {
  background: #fff; border-radius: 10px; overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 500px;
  box-shadow: 0 20px 60px rgba(0,0,0,.5); border: 1px solid #e0e0e0;
}
.li-header { display:flex; align-items:center; gap:10px; padding:14px 14px 10px; }
.li-avatar { width:48px; height:48px; border-radius:50%; background: linear-gradient(135deg,#0a66c2,#0d8fdb); display:flex; align-items:center; justify-content:center; color:#fff; font-size:18px; font-weight:700; }
.li-name { font-size:14px; font-weight:700; color:#000000e6; }
.li-headline { font-size:12px; color:#00000099; line-height:1.4; }
.li-degree { font-size:11px; color:#0a66c2; }
.li-content { padding: 4px 14px 14px; font-size:14px; color:#000000e6; line-height:1.6; white-space: pre-wrap; word-break: break-word; }
.li-image { width:100%; }
.li-reactions { padding:8px 14px; border-top:1px solid rgba(0,0,0,.1); font-size:13px; color:#00000099; display:flex; justify-content:space-between; }
.li-actions { display:flex; border-top:1px solid rgba(0,0,0,.1); }
.li-action-btn { flex:1; text-align:center; padding:10px; font-size:13px; color:#00000099; font-weight:600; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:5px; }

/* Reddit */
.preview-reddit {
  background: #1a1a1b; border-radius: 10px; overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 500px;
  box-shadow: 0 20px 60px rgba(0,0,0,.6); border: 1px solid #343536;
}
.rd-header { display:flex; align-items:center; gap:8px; padding:10px 12px; border-bottom:1px solid #343536; }
.rd-sub-icon { width:28px; height:28px; border-radius:50%; background: linear-gradient(135deg,#ff4500,#ff6534); display:flex; align-items:center; justify-content:center; color:#fff; font-size:13px; font-weight:800; }
.rd-sub-name { font-size:13px; font-weight:700; color:#d7dadc; }
.rd-posted-by { font-size:11px; color:#818384; }
.rd-body { padding: 10px 12px; }
.rd-title { font-size:16px; font-weight:700; color:#d7dadc; margin-bottom:8px; line-height:1.35; }
.rd-text { font-size:13px; color:#d7dadc; line-height:1.55; }
.rd-image { width:100%; border-radius:4px; margin-top:8px; }
.rd-actions { padding:8px 12px; display:flex; align-items:center; gap:14px; }
.rd-vote { display:flex; align-items:center; gap:6px; background:#272729; border-radius:20px; padding:5px 10px; }
.rd-vote-arrow { color:#818384; font-size:14px; cursor:pointer; }
.rd-vote-count { font-size:13px; font-weight:700; color:#d7dadc; }
.rd-action-btn { display:flex; align-items:center; gap:5px; color:#818384; font-size:13px; font-weight:700; cursor:pointer; }

/* Metric badges */
.eng-badge { display:inline-block; padding:3px 12px; border-radius:20px; font-size:12px; font-weight:700; font-family: var(--font-mono); }
.eng-good  { background:rgba(var(--greenRGB),.1); border:1px solid rgba(var(--greenRGB),.25); color:var(--green); }
.eng-mid   { background:rgba(255,181,71,.1); border:1px solid rgba(255,181,71,.25);  color:var(--amber); }
.eng-bad   { background:rgba(255,95,135,.1); border:1px solid rgba(255,95,135,.25);color:var(--rose); }

/* Chat messages */
.chat-msg  { border-radius:12px; padding:12px 16px; margin-bottom:8px; font-size:13px; line-height:1.6; position:relative; z-index:1; }
.chat-bot  { background:var(--card); border:1px solid var(--border); border-left:3px solid var(--accent); }
.chat-user { background:rgba(var(--accentRGB),.06); border:1px solid rgba(var(--accentRGB),.12); text-align:right; }
.chat-label{ font-size:10px; color:var(--muted); margin-bottom:4px; font-weight:700; letter-spacing:1px; text-transform:uppercase; font-family: var(--font-mono); }

/* Platform cards (selection) */
.plat-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 14px; padding: 18px; transition: all .2s;
  position: relative; z-index: 1;
}
.plat-card.selected { border-color: var(--accent); box-shadow: 0 0 0 2px var(--glow); }

/* Posted ad card */
.posted-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 16px; padding: 24px 28px; margin-bottom: 20px;
  position: relative; z-index: 1; transition: border-color .2s;
}
.posted-card:hover { border-color: var(--border2); }
.posted-card.low-eng { border-color: rgba(255,95,135,.3); }
.low-eng-banner {
  background: rgba(255,95,135,.08); border: 1px solid rgba(255,95,135,.2);
  border-radius: 10px; padding: 12px 16px; margin-bottom: 16px;
  display:flex; align-items:center; gap:10px; font-size:13px; color: var(--rose);
}

/* Image regen feedback */
.img-regen-box {
  background: var(--surface); border: 1px solid var(--border2);
  border-radius: 10px; padding: 14px 16px; margin-top: 10px;
}

/* Divider label */
.section-divider {
  display:flex; align-items:center; gap:12px; margin: 28px 0 20px;
  position: relative; z-index: 1;
}
.section-divider::before, .section-divider::after {
  content:''; flex:1; height:1px; background: var(--border);
}
.section-divider span {
  font-size:11px; font-weight:700; letter-spacing:2px; text-transform:uppercase;
  color: var(--muted); font-family: var(--font-mono); white-space: nowrap;
}

/* Skeleton loader */
.skeleton {
  background: linear-gradient(90deg, var(--card) 25%, var(--card2) 50%, var(--card) 75%);
  background-size: 200% 100%; animation: shimmer 1.5s infinite;
  border-radius: 8px; height: 16px;
}
@keyframes shimmer { from { background-position: 200% 0; } to { background-position: -200% 0; } }

/* ── Sidebar Chat History ── */
.sb-logo-wrap {
  display: flex; align-items: center; gap: 11px;
  padding: 18px 4px 14px;
}
.sb-logo-icon {
  width: 38px; height: 38px; border-radius: 11px; flex-shrink: 0;
  background: linear-gradient(135deg,#4f6ef7,#6d5cf7);
  display: flex; align-items: center; justify-content: center;
  font-size: 18px; box-shadow: 0 4px 18px rgba(79,110,247,.45);
}
.sb-logo-text { font-family:'Syne',sans-serif; font-size:20px; font-weight:800; color:#eaefff; letter-spacing:-0.5px; line-height:1.1; }
.sb-logo-sub  { font-size:9px; color:#3d4866; font-family:'Space Mono',monospace; letter-spacing:2px; text-transform:uppercase; margin-top:1px; }

/* Sidebar section divider */
.sb-divider {
  display: flex; align-items: center; gap: 8px; margin: 14px 0 10px;
}
.sb-divider-line { flex: 1; height: 1px; background: var(--border); }
.sb-divider-label {
  font-size: 9px; color: var(--muted); font-family: 'Space Mono', monospace;
  letter-spacing: 2px; text-transform: uppercase; white-space: nowrap;
}

/* Chat bubble in sidebar */
.sb-bubble-wrap { margin-bottom: 7px; }
.sb-bubble {
  display: inline-block; max-width: 92%; text-align: left;
  border-radius: 8px; padding: 8px 11px;
  font-size: 11px; color: #c4cde8; line-height: 1.5;
}
.sb-bubble.bot  { background: #111422; border-left: 2px solid #4f6ef7; border-radius: 8px 8px 8px 2px; }
.sb-bubble.user { background: rgba(79,110,247,.1); border-left: 2px solid rgba(79,110,247,.3); border-radius: 8px 8px 2px 8px; }
.sb-bubble-meta { font-size: 9px; font-weight: 700; font-family: 'Space Mono', monospace; letter-spacing: .8px; text-transform: uppercase; margin-bottom: 3px; }

/* Session history card */
.sb-sess-card {
  border-radius: 11px; padding: 11px 13px; margin-bottom: 3px;
  border: 1px solid var(--border); background: var(--surface);
  transition: border-color .15s, background .15s;
  cursor: pointer;
}
.sb-sess-card.active {
  background: rgba(79,110,247,.07);
  border-color: #4f6ef7;
}
.sb-sess-card:hover:not(.active) {
  background: var(--card); border-color: var(--border2);
}
.sb-sess-icon  { font-size: 19px; flex-shrink: 0; line-height: 1; margin-top: 2px; }
.sb-sess-title {
  font-size: 12px; font-weight: 700; color: #eaefff;
  font-family: 'Syne', sans-serif; line-height: 1.3; margin-bottom: 4px;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.sb-sess-meta  { display: flex; flex-wrap: wrap; align-items: center; gap: 4px; margin-bottom: 5px; }
.sb-chip {
  background: rgba(79,110,247,.15); color: #7b93ff;
  padding: 1px 7px; border-radius: 8px; font-size: 9px;
  font-weight: 700; font-family: 'Space Mono', monospace;
}
.sb-chip.live { background: rgba(30,232,160,.12); color: #1ee8a0; }
.sb-meta-dot  { width: 5px; height: 5px; border-radius: 50%; flex-shrink: 0; display: inline-block; }
.sb-step-text {
  font-size: 9px; font-family: 'Space Mono', monospace;
  letter-spacing: .5px; text-transform: uppercase;
}
.sb-active-badge {
  text-align: center; font-size: 9px; color: #4f6ef7;
  font-family: 'Space Mono', monospace; padding: 3px 0 5px;
  letter-spacing: 1px; text-transform: uppercase;
}
.sb-empty {
  text-align: center; padding: 28px 8px;
  background: var(--surface); border: 1px dashed var(--border);
  border-radius: 10px; margin-top: 6px;
}
.sb-empty-icon { font-size: 24px; margin-bottom: 8px; }
.sb-empty-text { font-size: 11px; color: var(--muted); line-height: 1.7; }
</style>

<!-- Animated particle canvas -->
<canvas id="particle-canvas"></canvas>
<script>
(function() {
  const canvas = document.getElementById('particle-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, particles = [];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const COLORS = ['rgba(79,110,247,', 'rgba(167,139,250,', 'rgba(30,232,160,', 'rgba(34,211,238,'];

  for (let i = 0; i < 80; i++) {
    particles.push({
      x: Math.random() * 1000,
      y: Math.random() * 1000,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      r: Math.random() * 1.5 + 0.3,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      alpha: Math.random() * 0.5 + 0.1,
    });
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
      if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.color + p.alpha + ')';
      ctx.fill();
    });

    // Draw connections
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 100) {
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(79,110,247,${0.06 * (1 - dist/100)})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }
    requestAnimationFrame(draw);
  }
  draw();
})();
</script>
""", unsafe_allow_html=True)

# ── Session State ─────────────────────────────────────────────────────────────
DEFAULTS = {
    "step": "describe",
    "campaign_id": None,
    "campaign_data": None,
    "ads": [],
    "posts": [],
    "chat": [],
    "selected_platforms": [],
    "ad_version_num": 1,
    "low_eng_shown": False,
    "img_sources": {},
    "img_enabled": {},
    "img_feedback": {},
    # ── Session history store ──────────────────────────────────────────────────
    # List of saved session snapshots, newest first.
    # Each entry: { id, title, ad_type, description, created_at, campaign_id,
    #               campaign_data, ads, posts, chat, selected_platforms,
    #               ad_version_num, step }
    "sessions": [],
    "active_session_id": None,
    "sidebar_search": "",
}
for k, v in DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ── Constants ─────────────────────────────────────────────────────────────────
PLATFORMS = {
    "Instagram": {"icon": "📸", "max_chars": 2200,  "color": "#e1306c", "style": "Visual · emojis · hashtags", "needs_image": True},
    "Facebook":  {"icon": "👥", "max_chars": 63206, "color": "#1877f2", "style": "Conversational · detailed",  "needs_image": False},
    "Telegram":  {"icon": "✈️", "max_chars": 4096,  "color": "#5b6ef5", "style": "Informative · *bold* key points", "needs_image": False},
    "Discord":   {"icon": "🎮", "max_chars": 2000,  "color": "#7289da", "style": "Casual · community-focused", "needs_image": False},
    "LinkedIn":  {"icon": "💼", "max_chars": 3000,  "color": "#0a66c2", "style": "Professional · value-driven", "needs_image": False},
    "Reddit":    {"icon": "🤖", "max_chars": 40000, "color": "#ff4500", "style": "Authentic · community value", "needs_image": False},
}

PLATFORM_SMART = {
    "Job / Hiring":   ["LinkedIn", "Discord", "Reddit"],
    "Grocery / Food": ["Instagram", "Facebook", "Telegram"],
    "Product Sale":   ["Instagram", "Facebook", "Reddit"],
    "Event":          ["Instagram", "Facebook", "Discord"],
    "Service":        ["Facebook", "Telegram", "Reddit"],
    "Real Estate":    ["Facebook", "Instagram", "Telegram"],
    "Announcement":   ["Telegram", "Discord", "Reddit"],
    "General":        ["Instagram", "Facebook"],
}

IMAGE_SOURCES = {
    "flux":          "⚡ FLUX.1 (HF Space)",
    "pollinations":  "🎨 Pollinations AI",
    "unsplash":      "📷 Picsum Stock",
    "replicate":     "🚀 Replicate FLUX",
}

STEPS   = ["describe", "platform_select", "generating", "review", "monitor"]
SLABELS = ["Describe", "Platforms", "Generate", "Review", "Monitor"]

# ── Helpers ───────────────────────────────────────────────────────────────────
def api(method, path, **kwargs):
    try:
        resp = getattr(requests, method)(f"{BACKEND_URL}{path}", timeout=90, **kwargs)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.ConnectionError:
        st.error("❌ Backend not running. Start it: `uvicorn main:app --reload`")
        st.stop()
    except requests.exceptions.HTTPError as e:
        detail = e.response.json().get("detail", str(e)) if e.response else str(e)
        raise ValueError(detail)

def add_chat(role, msg):
    st.session_state.chat.append({"role": role, "msg": msg, "ts": datetime.now().strftime("%H:%M")})
    # Keep session snapshot in sync whenever conversation advances
    _snapshot_current_session()

def eng_badge(rate):
    if rate >= 5:   return "🟢 Great",  "eng-good"
    if rate >= 2.5: return "🟡 Okay",   "eng-mid"
    return "🔴 Low", "eng-bad"

# ── Session management helpers ────────────────────────────────────────────────
SESSION_FIELDS = [
    "step", "campaign_id", "campaign_data", "ads", "posts", "chat",
    "selected_platforms", "ad_version_num", "low_eng_shown",
    "img_sources", "img_enabled", "img_feedback",
]

def _snapshot_current_session():
    """Save the current working state into the sessions list (upsert by campaign_id)."""
    cid = st.session_state.get("campaign_id")
    if not cid:
        return
    campaign = st.session_state.get("campaign_data") or {}
    snap = {
        "id":                cid,
        "title":             campaign.get("description", "Untitled")[:60],
        "ad_type":           campaign.get("ad_type", "General"),
        "description":       campaign.get("description", ""),
        "created_at":        campaign.get("created_at", datetime.now().isoformat()),
        "campaign_id":       cid,
    }
    for f in SESSION_FIELDS:
        snap[f] = st.session_state.get(f)

    sessions = st.session_state.setdefault("sessions", [])
    # Upsert: replace existing snapshot for this campaign_id
    existing_ids = [s["id"] for s in sessions]
    if cid in existing_ids:
        idx = existing_ids.index(cid)
        sessions[idx] = snap
    else:
        sessions.insert(0, snap)   # newest first
    st.session_state.sessions = sessions
    st.session_state.active_session_id = cid

def _load_session(snap: dict):
    """Restore a saved snapshot into active session state."""
    for f in SESSION_FIELDS:
        if f in snap:
            st.session_state[f] = snap[f]
    st.session_state.campaign_id   = snap["campaign_id"]
    st.session_state.campaign_data = snap["campaign_data"]
    st.session_state.active_session_id = snap["id"]

def _delete_session(session_id):
    """Remove a session snapshot by id."""
    st.session_state.sessions = [
        s for s in st.session_state.get("sessions", [])
        if s["id"] != session_id
    ]
    if st.session_state.get("active_session_id") == session_id:
        st.session_state.active_session_id = None

def _new_session():
    """Snapshot current session then reset to blank."""
    _snapshot_current_session()
    for f in SESSION_FIELDS:
        default_val = DEFAULTS.get(f)
        st.session_state[f] = copy.deepcopy(default_val)
    st.session_state.campaign_id   = None
    st.session_state.campaign_data = None
    st.session_state.active_session_id = None

def render_stepbar():
    idx   = STEPS.index(st.session_state.step) if st.session_state.step in STEPS else 0
    nodes = ""
    for i, lbl in enumerate(SLABELS):
        cls  = "active" if i == idx else ("done" if i < idx else "")
        txt  = "active" if i == idx else ("done" if i < idx else "")
        sym  = "✓" if i < idx else str(i + 1)
        nodes += f'<div class="step-node"><div class="step-circle {cls}">{sym}</div><span class="step-text {txt}">{lbl}</span></div>'
        if i < len(SLABELS) - 1:
            line_cls = "done-line" if i < idx else "plain"
            nodes += f'<div class="step-connector {line_cls}"></div>'
    st.markdown(f'<div class="step-bar">{nodes}</div>', unsafe_allow_html=True)

def _esc(text: str) -> str:
    """HTML-escape text so ad content never breaks the preview HTML structure."""
    return (text
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;"))

def _nl2br(text: str) -> str:
    """Convert newlines to <br> for HTML display."""
    return _esc(text).replace("\n", "<br>")

def _tg_format(text: str) -> str:
    """Convert Telegram *bold* and _italic_ markdown to HTML, safely."""
    escaped = _esc(text)
    # *bold* -> <b>bold</b>
    escaped = re.sub(r'\*([^*\n]+)\*', r'<b>\1</b>', escaped)
    # _italic_ -> <i>italic</i>
    escaped = re.sub(r'_([^_\n]+)_', r'<i>\1</i>', escaped)
    return escaped.replace("\n", "<br>")

def _ig_format(text: str) -> str:
    """For Instagram: separate body text from hashtags, return (body_html, hashtags_html)."""
    words  = text.split()
    body   = [w for w in words if not w.startswith('#')]
    tags   = [w for w in words if w.startswith('#')]
    body_html = _esc(" ".join(body))
    tags_html = _esc(" ".join(tags))
    return body_html, tags_html

def render_platform_preview(platform: str, ad: dict):
    """Render a pixel-accurate, safely-escaped platform post preview."""
    content   = ad.get("content", "") or ""
    image_url = (ad.get("image_url") or "").strip()

    # Safe image tag — only emitted when URL is non-empty
    img_tag = (f'<img src="{image_url}" style="width:100%;display:block;'
               f'max-height:400px;object-fit:cover;" onerror="this.style.display=\'none\'">'
               if image_url else "")

    # ── INSTAGRAM ─────────────────────────────────────────────────────────────
    if platform == "Instagram":
        body_html, tags_html = _ig_format(content[:400])
        img_block = (img_tag if img_tag
                     else '<div class="ig-image-placeholder">📷</div>')
        st.markdown(f"""
        <div class="preview-instagram">
          <div class="ig-header">
            <div class="ig-avatar">A</div>
            <div>
              <div class="ig-username">adbot_official</div>
              <div class="ig-location">Sponsored</div>
            </div>
            <span style="margin-left:auto;font-size:20px;color:#262626;cursor:pointer">···</span>
          </div>
          {img_block}
          <div class="ig-actions">
            <svg class="ig-action-svg" viewBox="0 0 24 24" fill="none" stroke="#262626" stroke-width="2" style="width:24px;height:24px;cursor:pointer"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
            <svg class="ig-action-svg" viewBox="0 0 24 24" fill="none" stroke="#262626" stroke-width="2" style="width:24px;height:24px;cursor:pointer;margin-left:8px"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <svg class="ig-action-svg" viewBox="0 0 24 24" fill="none" stroke="#262626" stroke-width="2" style="width:24px;height:24px;cursor:pointer;margin-left:8px"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            <svg class="ig-action-svg" viewBox="0 0 24 24" fill="none" stroke="#262626" stroke-width="2" style="width:24px;height:24px;cursor:pointer;margin-left:auto"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
          </div>
          <div class="ig-likes">142 likes</div>
          <div class="ig-caption">
            <span class="ig-name">adbot_official</span>{body_html[:260]}
            {'<span class="ig-hashtags"><br>' + tags_html[:160] + '</span>' if tags_html else ''}
          </div>
          <div style="padding:2px 14px 4px;font-size:12px;color:#8e8e8e;cursor:pointer">
            View all 14 comments
          </div>
          <div class="ig-time">2 MINUTES AGO</div>
        </div>""", unsafe_allow_html=True)

    # ── FACEBOOK ──────────────────────────────────────────────────────────────
    elif platform == "Facebook":
        fb_text  = _nl2br(content[:500])
        img_block = (f'<img src="{image_url}" style="width:100%;display:block;'
                     f'max-height:350px;object-fit:cover;" />'
                     if image_url else "")
        st.markdown(f"""
        <div class="preview-facebook">
          <div class="fb-header">
            <div class="fb-avatar">A</div>
            <div style="flex:1">
              <div class="fb-name">AdBot Page</div>
              <div class="fb-meta">
                <span>2 min</span>
                <span>·</span>
                <span style="font-size:13px">🌍</span>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <div style="background:#1877f2;color:#fff;font-size:11px;font-weight:700;
                padding:3px 8px;border-radius:4px">Follow</div>
              <span style="color:#65676b;font-size:18px;cursor:pointer">···</span>
            </div>
          </div>
          <div class="fb-content">{fb_text}</div>
          {img_block}
          <div class="fb-reactions">
            <span>👍 ❤️ 😮 &nbsp; 47</span>
            <span>12 comments &nbsp;·&nbsp; 5 shares</span>
          </div>
          <div class="fb-actions">
            <div class="fb-action-btn">
              <svg viewBox="0 0 20 20" style="width:18px;height:18px;fill:#65676b;margin-right:5px"><path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z"/></svg>
              Like
            </div>
            <div class="fb-action-btn">
              <svg viewBox="0 0 20 20" style="width:18px;height:18px;fill:#65676b;margin-right:5px"><path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clip-rule="evenodd"/></svg>
              Comment
            </div>
            <div class="fb-action-btn">
              <svg viewBox="0 0 20 20" style="width:18px;height:18px;fill:#65676b;margin-right:5px"><path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z"/></svg>
              Share
            </div>
          </div>
        </div>""", unsafe_allow_html=True)

    # ── TELEGRAM ──────────────────────────────────────────────────────────────
    elif platform == "Telegram":
        tg_text   = _tg_format(content[:600])
        img_block = (f'<img src="{image_url}" style="width:100%;border-radius:8px;'
                     f'display:block;margin-bottom:10px;max-height:280px;object-fit:cover;" />'
                     if image_url else "")
        st.markdown(f"""
        <div class="preview-telegram">
          <div class="tg-header">
            <div class="tg-icon">✈</div>
            <div style="flex:1">
              <div class="tg-channel-name">AdBot Channel</div>
              <div class="tg-subscribers">1,247 subscribers</div>
            </div>
            <svg viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2"
              style="width:20px;height:20px;cursor:pointer">
              <circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>
            </svg>
          </div>
          <div style="padding:8px 12px 6px">
            <div class="tg-msg">
              {img_block}
              <div class="tg-msg-text">{tg_text}</div>
              <div class="tg-msg-meta">12:34 &nbsp;👁 342</div>
            </div>
            <div style="display:flex;gap:6px;margin-top:4px;padding-bottom:2px">
              <div style="background:#2b3d4f;border-radius:20px;padding:5px 14px;
                font-size:12px;color:#6ab3e4;cursor:pointer;flex:1;text-align:center">
                👍 &nbsp;128
              </div>
              <div style="background:#2b3d4f;border-radius:20px;padding:5px 14px;
                font-size:12px;color:#6ab3e4;cursor:pointer;flex:1;text-align:center">
                🔁 &nbsp;Share
              </div>
            </div>
          </div>
        </div>""", unsafe_allow_html=True)

    # ── DISCORD ───────────────────────────────────────────────────────────────
    elif platform == "Discord":
        dc_text   = _nl2br(content[:400])
        img_block = (f'<img src="{image_url}" style="width:100%;border-radius:4px;'
                     f'margin-top:8px;max-height:280px;object-fit:cover;display:block;" />'
                     if image_url else "")
        embed_block = (f'<div class="dc-embed" style="margin-top:10px">'
                       f'<div style="font-size:12px;font-weight:700;color:#fff;margin-bottom:4px">AdBot Ad</div>'
                       f'{img_block}</div>'
                       if image_url else "")
        st.markdown(f"""
        <div class="preview-discord">
          <div class="dc-header">
            <svg viewBox="0 0 24 24" style="width:16px;height:16px;fill:#80848e;margin-right:2px">
              <path d="M5.5 3A2.5 2.5 0 003 5.5v13A2.5 2.5 0 005.5 21H18.5A2.5 2.5 0 0021 18.5v-13A2.5 2.5 0 0018.5 3H5.5zM9 7a1 1 0 110 2 1 1 0 010-2zm6 0a1 1 0 110 2 1 1 0 010-2zM7.5 12h9l-1.5 6H9l-1.5-6z"/>
            </svg>
            <span class="dc-channel-name">announcements</span>
            <span style="color:#80848e;font-size:12px;margin-left:8px">|&nbsp; AdBot official channel</span>
          </div>
          <div class="dc-msg">
            <div class="dc-avatar">A</div>
            <div class="dc-msg-right">
              <div style="display:flex;align-items:baseline;gap:5px;margin-bottom:2px">
                <span class="dc-username">AdBot</span>
                <span class="dc-bot-badge">APP</span>
                <span class="dc-timestamp">Today at 12:34</span>
              </div>
              <div class="dc-text">{dc_text}</div>
              {embed_block}
              <div style="display:flex;gap:4px;margin-top:8px;flex-wrap:wrap">
                <div style="background:#2b2d31;border-radius:8px;padding:4px 10px;
                  font-size:12px;color:#b5bac1;cursor:pointer;border:1px solid #3f4147">
                  👍 &nbsp;12
                </div>
                <div style="background:#2b2d31;border-radius:8px;padding:4px 10px;
                  font-size:12px;color:#b5bac1;cursor:pointer;border:1px solid #3f4147">
                  🔁 &nbsp;5
                </div>
              </div>
            </div>
          </div>
        </div>""", unsafe_allow_html=True)

    # ── LINKEDIN ──────────────────────────────────────────────────────────────
    elif platform == "LinkedIn":
        li_text   = _nl2br(content[:600])
        img_block = (f'<img src="{image_url}" style="width:100%;display:block;'
                     f'max-height:320px;object-fit:cover;" />'
                     if image_url else "")
        st.markdown(f"""
        <div class="preview-linkedin">
          <div class="li-header">
            <div class="li-avatar">A</div>
            <div style="flex:1;min-width:0">
              <div class="li-name">AdBot Official</div>
              <div class="li-headline">AI-Powered Advertising Platform</div>
              <div class="li-degree">2nd &nbsp;·&nbsp; 2h &nbsp;·&nbsp; 🌍</div>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <div style="border:1px solid #0a66c2;color:#0a66c2;border-radius:20px;
                padding:4px 14px;font-size:13px;font-weight:600;cursor:pointer">+ Follow</div>
              <span style="color:#00000066;font-size:20px;cursor:pointer">···</span>
            </div>
          </div>
          <div class="li-content">{li_text}</div>
          {img_block}
          <div class="li-reactions" style="padding:10px 14px;border-top:1px solid rgba(0,0,0,.1);
            font-size:13px;color:#00000099;display:flex;justify-content:space-between">
            <span>
              <span style="background:#0a66c2;border-radius:50%;width:18px;height:18px;
                display:inline-flex;align-items:center;justify-content:center;
                font-size:10px;color:#fff;margin-right:3px">👍</span>
              <span style="background:#e44949;border-radius:50%;width:18px;height:18px;
                display:inline-flex;align-items:center;justify-content:center;
                font-size:10px;color:#fff;margin-right:5px">❤️</span>
              87
            </span>
            <span>24 comments &nbsp;·&nbsp; 11 reposts</span>
          </div>
          <div class="li-actions">
            <div class="li-action-btn">
              <svg viewBox="0 0 24 24" style="width:18px;height:18px;fill:none;stroke:#00000099;stroke-width:2">
                <path d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3H14z"/>
                <path d="M7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3"/>
              </svg>
              Like
            </div>
            <div class="li-action-btn">
              <svg viewBox="0 0 24 24" style="width:18px;height:18px;fill:none;stroke:#00000099;stroke-width:2">
                <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
              </svg>
              Comment
            </div>
            <div class="li-action-btn">
              <svg viewBox="0 0 24 24" style="width:18px;height:18px;fill:none;stroke:#00000099;stroke-width:2">
                <polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 014-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 01-4 4H3"/>
              </svg>
              Repost
            </div>
            <div class="li-action-btn">
              <svg viewBox="0 0 24 24" style="width:18px;height:18px;fill:none;stroke:#00000099;stroke-width:2">
                <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
              </svg>
              Send
            </div>
          </div>
        </div>""", unsafe_allow_html=True)

    # ── REDDIT ────────────────────────────────────────────────────────────────
    elif platform == "Reddit":
        all_lines = content.strip().split('\n')
        rd_title  = _esc(all_lines[0][:120]) if all_lines else "Ad Post"
        rd_body   = _nl2br('\n'.join(all_lines[1:])[:400]) if len(all_lines) > 1 else ""
        img_block = (f'<img src="{image_url}" style="width:100%;border-radius:4px;'
                     f'margin-top:10px;max-height:320px;object-fit:cover;display:block;" />'
                     if image_url else "")
        # Flair detection
        ad_type = ad.get("ad_type", "")
        flair_colors = {
            "Job / Hiring": ("#0dd3bb","#003c2e"),
            "Product Sale": ("#ff4500","#fff"),
            "Event":        ("#46d160","#fff"),
            "Announcement": ("#4f6ef7","#fff"),
        }
        fc, ft = flair_colors.get(ad_type, ("#c18d42","#fff"))
        flair_html = (f'<span style="background:{fc};color:{ft};font-size:10px;'
                      f'font-weight:700;padding:2px 8px;border-radius:12px;margin-left:6px">'
                      f'{ad_type}</span>' if ad_type else "")
        st.markdown(f"""
        <div class="preview-reddit">
          <div class="rd-header">
            <div class="rd-sub-icon">r/</div>
            <div style="flex:1">
              <div style="display:flex;align-items:center">
                <span class="rd-sub-name">r/technology</span>{flair_html}
              </div>
              <div class="rd-posted-by">Posted by u/adbot_official &nbsp;·&nbsp; Just now</div>
            </div>
            <div style="background:#ff4500;color:#fff;font-size:11px;font-weight:700;
              padding:4px 12px;border-radius:20px;cursor:pointer">Join</div>
          </div>
          <div class="rd-body">
            <div class="rd-title">{rd_title}</div>
            {'<div class="rd-text">' + rd_body + '</div>' if rd_body else ''}
            {img_block}
          </div>
          <div class="rd-actions">
            <div class="rd-vote">
              <svg viewBox="0 0 20 20" style="width:16px;height:16px;fill:#818384;cursor:pointer">
                <path d="M10 3L4 9h4v8h4V9h4z"/>
              </svg>
              <span class="rd-vote-count">1</span>
              <svg viewBox="0 0 20 20" style="width:16px;height:16px;fill:#818384;cursor:pointer">
                <path d="M10 17l6-6h-4V3H8v8H4z"/>
              </svg>
            </div>
            <div class="rd-action-btn">
              <svg viewBox="0 0 20 20" style="width:15px;height:15px;fill:#818384">
                <path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clip-rule="evenodd"/>
              </svg>
              &nbsp;Comment
            </div>
            <div class="rd-action-btn">
              <svg viewBox="0 0 20 20" style="width:15px;height:15px;fill:#818384">
                <path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z"/>
              </svg>
              &nbsp;Share
            </div>
            <div class="rd-action-btn">··· More</div>
          </div>
        </div>""", unsafe_allow_html=True)

# ── SIDEBAR ───────────────────────────────────────────────────────────────────
# Rendered unconditionally — always visible on every step rerun
with st.sidebar:

    # ── Sticky Logo + New Chat header ─────────────────────
    st.markdown("""
    <div style="
      position: sticky; top: 0; z-index: 50;
      background: #07090f;
      border-bottom: 1px solid #141824;
      padding: 16px 16px 12px;
      margin: 0 -12px 4px;
    ">
      <div class="sb-logo-wrap" style="padding: 0 0 12px">
        <div class="sb-logo-icon">⚡</div>
        <div>
          <div class="sb-logo-text">AdBot</div>
          <div class="sb-logo-sub">AI Ad Platform</div>
        </div>
      </div>
    </div>""", unsafe_allow_html=True)

    if st.button("＋  New Chat", type="primary", use_container_width=True, key="new_chat_btn"):
        _new_session()
        st.rerun()

    # ── Current step progress pill — visible on all steps ─
    _step_now   = st.session_state.get("step", "describe")
    _step_icons = {
        "describe":        ("✏️", "Describe",         "#7a86a8"),
        "platform_select": ("🎯", "Pick Platforms",   "#4f6ef7"),
        "generating":      ("⚙️", "Generating…",      "#ffb547"),
        "review":          ("👁️", "Review & Edit",    "#7b93ff"),
        "monitor":         ("📊", "Live Monitor",     "#1ee8a0"),
    }
    _si, _sl, _sc = _step_icons.get(_step_now, ("·", _step_now.title(), "#3d4866"))
    _campaign_desc = ""
    if st.session_state.get("campaign_data"):
        _campaign_desc = st.session_state.campaign_data.get("description","")[:38]
        if len(st.session_state.campaign_data.get("description","")) > 38:
            _campaign_desc += "…"

    st.markdown(f"""
    <div style="
      margin: 10px 0 4px;
      background: rgba(79,110,247,0.06);
      border: 1px solid rgba(79,110,247,0.15);
      border-radius: 10px; padding: 10px 13px;
    ">
      <div style="display:flex;align-items:center;gap:8px">
        <span style="font-size:15px">{_si}</span>
        <div style="flex:1;min-width:0">
          <div style="font-size:10px;font-weight:700;color:{_sc};
            font-family:'Space Mono',monospace;letter-spacing:1px;
            text-transform:uppercase">{_sl}</div>
          {f'<div style="font-size:11px;color:#3d4866;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{_campaign_desc}</div>' if _campaign_desc else ''}
        </div>
        <div style="display:flex;gap:3px">
          {"".join([f'<div style="width:6px;height:6px;border-radius:50%;background:{_sc if STEPS.index(_step_now)==i else ("#242d47" if STEPS.index(_step_now)<i else "rgba(79,110,247,0.4)")}"></div>' for i in range(len(STEPS))])}
        </div>
      </div>
    </div>""", unsafe_allow_html=True)

    # ── Constants for sidebar ─────────────────────────────
    AD_TYPE_ICONS = {
        "Job / Hiring": "💼", "Grocery / Food": "🛒", "Product Sale": "🛍️",
        "Event": "🎉",        "Service": "🔧",        "Real Estate": "🏠",
        "Announcement": "📢", "General": "📣",
    }
    STEP_LABELS = {
        "describe":        ("Drafting",          "#3d4866"),
        "platform_select": ("Choosing platforms", "#4f6ef7"),
        "generating":      ("Generating…",        "#ffb547"),
        "review":          ("In review",          "#7b93ff"),
        "monitor":         ("Live 🟢",            "#1ee8a0"),
    }

    def _rel_time(dt_str: str) -> str:
        try:
            ds  = re.sub(r'Z$', '+00:00', dt_str or "")
            dt  = datetime.fromisoformat(ds)
            now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
            d   = now - dt
            if d.days == 0:
                h = d.seconds // 3600
                m = (d.seconds % 3600) // 60
                if h:   return f"{h}h ago"
                if m:   return f"{m}m ago"
                return "Just now"
            if d.days == 1: return "Yesterday"
            if d.days < 7:  return f"{d.days}d ago"
            return dt.strftime("%b %d")
        except Exception:
            return ""

    # ── Build unified session list (DB + in-memory) ───────
    try:
        db_campaigns = api("get", "/campaigns") or []
    except Exception:
        db_campaigns = []

    mem_sessions = {s["id"]: s for s in st.session_state.get("sessions", [])}
    for c in db_campaigns:
        cid = c["id"]
        if cid not in mem_sessions:
            mem_sessions[cid] = {
                "id": cid, "campaign_id": cid,
                "title": c["description"][:60], "ad_type": c["ad_type"],
                "description": c["description"], "created_at": c["created_at"],
                "chat": [], "step": "platform_select", "campaign_data": c,
                "ads": [], "posts": [], "selected_platforms": [],
                "ad_version_num": 1, "low_eng_shown": False,
                "img_sources": {}, "img_enabled": {}, "img_feedback": {},
            }
        else:
            mem_sessions[cid].update({
                "title": c["description"][:60], "ad_type": c["ad_type"],
                "created_at": c["created_at"],  "campaign_data": c,
            })

    all_sessions = sorted(mem_sessions.values(), key=lambda s: s.get("created_at", ""), reverse=True)

    active_id = st.session_state.get("active_session_id") or st.session_state.get("campaign_id")

    # ══════════════════════════════════════════════════════
    # CURRENT CHAT LOG (always visible at top when active)
    # ══════════════════════════════════════════════════════
    active_chat = st.session_state.get("chat", [])
    if active_chat:
        st.markdown("""
        <div class="sb-divider">
          <div class="sb-divider-line"></div>
          <span class="sb-divider-label">Current session</span>
          <div class="sb-divider-line"></div>
        </div>""", unsafe_allow_html=True)

        # Show last 6 messages, newest at bottom
        for entry in active_chat[-6:]:
            is_bot    = entry["role"] == "agent"
            align     = "left" if is_bot else "right"
            cls       = "bot" if is_bot else "user"
            name_col  = "#4f6ef7" if is_bot else "#7a86a8"
            name_lbl  = "⚡ AdBot" if is_bot else "You"
            ts        = entry.get("ts", "")
            clean_msg = re.sub(r'<[^>]+>', '', entry["msg"])
            clean_msg = clean_msg[:90] + ("…" if len(clean_msg) > 90 else "")
            st.markdown(f"""
            <div class="sb-bubble-wrap" style="text-align:{align}">
              <div class="sb-bubble {cls}">
                <div class="sb-bubble-meta" style="color:{name_col}">{name_lbl} · {ts}</div>
                {clean_msg}
              </div>
            </div>""", unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════
    # SESSION HISTORY
    # ══════════════════════════════════════════════════════
    st.markdown("""
    <div class="sb-divider">
      <div class="sb-divider-line"></div>
      <span class="sb-divider-label">History</span>
      <div class="sb-divider-line"></div>
    </div>""", unsafe_allow_html=True)

    # Search
    search_q = st.text_input(
        "search_sessions", label_visibility="collapsed",
        placeholder="🔍  Search sessions…", key="sidebar_search_input",
    )
    q = search_q.lower().strip()

    filtered = [
        s for s in all_sessions
        if not q
        or q in s.get("title", "").lower()
        or q in s.get("ad_type", "").lower()
        or q in s.get("description", "").lower()
    ]

    if not filtered:
        st.markdown("""
        <div class="sb-empty">
          <div class="sb-empty-icon">🗂️</div>
          <div class="sb-empty-text">No sessions yet.<br/>Start a campaign above.</div>
        </div>""", unsafe_allow_html=True)
    else:
        # Group by date bucket
        buckets: dict[str, list] = {}
        for sess in filtered[:40]:
            ts_str = sess.get("created_at", "")
            try:
                ds  = re.sub(r'Z$', '+00:00', ts_str)
                dt  = datetime.fromisoformat(ds)
                now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
                d   = (now - dt).days
                if d == 0:   bucket = "Today"
                elif d == 1: bucket = "Yesterday"
                elif d < 7:  bucket = "This week"
                elif d < 30: bucket = "This month"
                else:        bucket = "Older"
            except Exception:
                bucket = "Older"
            buckets.setdefault(bucket, []).append(sess)

        BUCKET_ORDER = ["Today", "Yesterday", "This week", "This month", "Older"]
        for bucket_name in BUCKET_ORDER:
            if bucket_name not in buckets:
                continue

            # Bucket label
            st.markdown(f"""
            <div style="font-size:9px;color:#3d4866;font-family:'Space Mono',monospace;
              letter-spacing:1.5px;text-transform:uppercase;padding:8px 2px 5px">
              {bucket_name}
            </div>""", unsafe_allow_html=True)

            for sess in buckets[bucket_name]:
                sid       = sess["id"]
                is_active = sid == active_id
                icon      = AD_TYPE_ICONS.get(sess.get("ad_type", ""), "📣")
                step      = sess.get("step", "describe")
                step_lbl, step_col = STEP_LABELS.get(step, (step.title(), "#3d4866"))
                is_live   = step == "monitor"
                n_msgs    = len(sess.get("chat", []))
                n_ads     = len(sess.get("ads", []))
                rel_time  = _rel_time(sess.get("created_at", ""))
                platforms = sess.get("selected_platforms", [])
                title_display = sess["title"][:32] + ("…" if len(sess["title"]) > 32 else "")

                # Platform icons strip
                plat_icons = "".join([PLATFORMS.get(p, {}).get("icon", "") for p in platforms[:4]])

                # Active badge vs load/delete buttons
                if is_active:
                    action_html = '<div class="sb-active-badge">● ACTIVE SESSION</div>'
                    action_widget = None
                else:
                    action_html  = ""
                    action_widget = sid

                card_cls = "sb-sess-card active" if is_active else "sb-sess-card"

                st.markdown(f"""
                <div class="{card_cls}">
                  <div style="display:flex;align-items:flex-start;gap:9px">
                    <div class="sb-sess-icon">{icon}</div>
                    <div style="flex:1;min-width:0">
                      <div class="sb-sess-title">{title_display}</div>
                      <div class="sb-sess-meta">
                        <span class="sb-chip {'live' if is_live else ''}">{sess.get('ad_type','General')}</span>
                        {f'<span style="color:#3d4866;font-size:10px">{rel_time}</span>' if rel_time else ''}
                        {f'<span style="color:#3d4866;font-size:10px">💬 {n_msgs}</span>' if n_msgs else ''}
                        {f'<span style="color:#3d4866;font-size:10px">📝 {n_ads}</span>' if n_ads else ''}
                        {f'<span style="color:#3d4866;font-size:10px">{plat_icons}</span>' if plat_icons else ''}
                      </div>
                      <div style="display:flex;align-items:center;gap:5px">
                        <span class="sb-meta-dot" style="background:{step_col}"></span>
                        <span class="sb-step-text" style="color:{step_col}">{step_lbl}</span>
                      </div>
                    </div>
                  </div>
                  {action_html}
                </div>""", unsafe_allow_html=True)

                if action_widget:
                    col_open, col_del = st.columns([4, 1])
                    with col_open:
                        if st.button("Open →", key=f"load_sess_{sid}", use_container_width=True):
                            _snapshot_current_session()
                            _load_session(sess)
                            st.rerun()
                    with col_del:
                        if st.button("🗑", key=f"del_sess_{sid}", use_container_width=True, help="Delete"):
                            _delete_session(sid)
                            try: api("delete", f"/campaigns/{sid}")
                            except Exception: pass
                            if is_active: _new_session()
                            st.rerun()
                st.markdown("<div style='height:1px'></div>", unsafe_allow_html=True)


# ── HERO ──────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="ab-hero">
  <div class="ab-hero-glow"></div>
  <div class="ab-hero-glow2"></div>
  <div class="ab-hero-inner">
    <div class="ab-badge">AI-Powered · Multi-Platform · Real APIs</div>
    <h1>AdBot —<br/><em>ads that convert.</em></h1>
    <p>Describe your product once. Get platform-native copy, AI images, real-time previews, and live API posting — all in one flow.</p>
  </div>
</div>
""", unsafe_allow_html=True)

render_stepbar()

# ═════════════════════════════════════════════════════════════════════════════
# STEP 1 — DESCRIBE
# ═════════════════════════════════════════════════════════════════════════════
if st.session_state.step == "describe":

    st.markdown('<div class="ab-card">', unsafe_allow_html=True)
    st.markdown('<div class="ab-label">What are you advertising?</div>', unsafe_allow_html=True)
    desc = st.text_area(
        "desc", label_visibility="collapsed",
        placeholder=(
            "Examples:\n"
            "• Fresh organic vegetables, 20% off this weekend, home delivery in Mumbai\n"
            "• Hiring senior React developer, 3+ yrs exp, fintech startup, remote OK\n"
            "• Grand opening of new bakery — artisan breads, coffee. Saturday 10 AM\n"
            "• 2BHK apartment for rent, fully furnished, ₹25,000/mo"
        ),
        height=160
    )

    col1, col2 = st.columns(2)
    with col1:
        st.markdown('<div class="ab-label">Tone</div>', unsafe_allow_html=True)
        tone = st.selectbox(
            "tone", ["Auto-detect","Energetic","Professional","Friendly","Urgent","Luxurious","Minimalist"],
            label_visibility="collapsed"
        )
    with col2:
        st.markdown('<div class="ab-label">Language</div>', unsafe_allow_html=True)
        lang = st.selectbox(
            "lang", ["English","Hinglish","Hindi","Tamil","Telugu","Kannada"],
            label_visibility="collapsed"
        )
    st.markdown("</div>", unsafe_allow_html=True)
    st.markdown("")

    if st.button("Continue → Choose Platforms", type="primary", use_container_width=True):
        if not desc.strip():
            st.error("Please describe your product or service.")
        else:
            with st.spinner("Analyzing your campaign…"):
                try:
                    campaign = api("post", "/campaigns", json={"description": desc, "tone": tone, "language": lang})
                    st.session_state.campaign_id   = campaign["id"]
                    st.session_state.campaign_data = campaign
                    st.session_state.selected_platforms = PLATFORM_SMART.get(campaign["ad_type"], ["Instagram","Facebook"])
                    add_chat("agent", f"Detected as <b>{campaign['ad_type']}</b>. Pre-selected best platforms.")
                    st.session_state.step = "platform_select"
                    _snapshot_current_session()
                    st.rerun()
                except ValueError as e:
                    st.error(str(e))

# ═════════════════════════════════════════════════════════════════════════════
# STEP 2 — PLATFORM SELECT
# ═════════════════════════════════════════════════════════════════════════════
elif st.session_state.step == "platform_select":
    campaign  = st.session_state.campaign_data
    ad_type   = campaign["ad_type"] if campaign else "General"
    suggested = PLATFORM_SMART.get(ad_type, ["Instagram","Facebook"])

    st.markdown('<div class="ab-card">', unsafe_allow_html=True)
    st.markdown('<div class="ab-label">Select Platforms</div>', unsafe_allow_html=True)
    st.markdown(
        f'<div style="margin-bottom:16px;font-size:13px;color:var(--soft)">💡 Recommended for '
        f'<b style="color:var(--green)">{ad_type}</b>: '
        + "".join([f'<span class="ab-ptag green">{PLATFORMS[p]["icon"]} {p}</span>' for p in suggested if p in PLATFORMS])
        + "</div>", unsafe_allow_html=True
    )

    cols   = st.columns(3)
    chosen = []
    for i, (name, info) in enumerate(PLATFORMS.items()):
        with cols[i % 3]:
            checked = st.checkbox(
                f"{info['icon']} **{name}**\n_{info['style']}_",
                value=(name in suggested),
                key=f"plat_{name}"
            )
            if name == "Instagram" and checked:
                st.markdown('<div style="font-size:11px;color:var(--green);margin-top:-8px;margin-bottom:4px">✦ Auto-generates image</div>', unsafe_allow_html=True)
            if checked:
                chosen.append(name)

    st.markdown("</div>", unsafe_allow_html=True)

    if chosen:
        st.markdown(
            '<div style="margin:10px 0 6px;font-size:13px;color:var(--soft)">Generating for: '
            + "".join([f'<span class="ab-ptag">{PLATFORMS[p]["icon"]} {p}</span>' for p in chosen])
            + "</div>", unsafe_allow_html=True
        )

    c1, c2 = st.columns([1, 3])
    with c1:
        if st.button("← Back"):
            st.session_state.step = "describe"; st.rerun()
    with c2:
        lbl = (f"✦ Generate for {len(chosen)} Platform{'s' if len(chosen) != 1 else ''}"
               if chosen else "Select at least one platform")
        if st.button(lbl, type="primary", use_container_width=True, disabled=len(chosen) == 0):
            add_chat("human", f"Generate for: {', '.join(chosen)}")
            st.session_state.selected_platforms = chosen
            st.session_state.img_enabled = {p: (True if PLATFORMS[p]["needs_image"] else False) for p in chosen}
            st.session_state.img_sources = {p: "flux" for p in chosen}
            st.session_state.img_feedback = {p: "" for p in chosen}
            st.session_state.step = "generating"
            st.rerun()

# ═════════════════════════════════════════════════════════════════════════════
# STEP 3 — GENERATING
# ═════════════════════════════════════════════════════════════════════════════
elif st.session_state.step == "generating":
    platforms_to_generate = st.session_state.selected_platforms

    if not platforms_to_generate:
        st.error("No platforms selected.")
        if st.button("← Go Back"):
            st.session_state.step = "platform_select"; st.rerun()
    else:
        with st.spinner(f"🤖 Crafting ads for {', '.join(platforms_to_generate)}…"):
            try:
                result = api(
                    "post",
                    f"/campaigns/{st.session_state.campaign_id}/generate",
                    json={"platforms": platforms_to_generate, "feedback": ""}
                )
                all_ads      = result["ads"]
                filtered_ads = [ad for ad in all_ads if ad["platform"] in platforms_to_generate]
                st.session_state.ads            = filtered_ads
                st.session_state.ad_version_num = result["version"]
                _snapshot_current_session()

                # Auto-generate image for Instagram
                for ad in st.session_state.ads:
                    if ad["platform"] == "Instagram" and not ad.get("image_url"):
                        try:
                            src = st.session_state.img_sources.get("Instagram", "flux")
                            updated_ad = api("post", f"/ads/{ad['id']}/generate-image?source={src}")
                            st.session_state.ads = [
                                updated_ad if a["id"] == ad["id"] else a
                                for a in st.session_state.ads
                            ]
                            add_chat("agent", f"✅ Instagram image auto-generated.")
                        except Exception as e:
                            add_chat("agent", f"⚠️ Instagram image failed: {e}")

                st.session_state.step = "review"
                add_chat("agent", f"✅ <b>{len(filtered_ads)} ads</b> ready for {', '.join(platforms_to_generate)}.")
                st.rerun()
            except Exception as e:
                st.error(f"Generation failed: {e}")
                if st.button("← Go Back"):
                    st.session_state.step = "platform_select"; st.rerun()

# ═════════════════════════════════════════════════════════════════════════════
# STEP 4 — REVIEW (Preview + Edit + Post)
# ═════════════════════════════════════════════════════════════════════════════
elif st.session_state.step == "review":
    campaign = st.session_state.campaign_data
    ads_list = st.session_state.ads
    selected = st.session_state.selected_platforms
    ads_map  = {ad["platform"]: ad for ad in ads_list if ad["platform"] in selected}

    if not ads_map:
        st.warning("No ads found. Please regenerate.")
        if st.button("← Go Back"):
            st.session_state.step = "platform_select"; st.rerun()
        st.stop()

    first = ads_list[0]

    # Campaign header
    st.markdown(f"""
    <div class="ab-card" style="margin-bottom:24px;background:linear-gradient(135deg,var(--card),var(--card2));border-color:var(--border2)">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px">
        <div>
          <div class="ab-label">Campaign · v{st.session_state.ad_version_num} · #{campaign['id']}</div>
          <div style="font-family:'Syne',sans-serif;font-size:24px;font-weight:800;color:var(--bright);margin-bottom:6px">
            {first.get('title','Your Campaign')}
          </div>
          <div style="font-size:13px;color:var(--muted)">
            {campaign['ad_type']} &nbsp;·&nbsp; CTA: {first.get('cta','—')}
            &nbsp;·&nbsp; Platforms: {', '.join(ads_map.keys())}
          </div>
        </div>
        <div>{''.join([f'<span class="ab-ptag">{PLATFORMS[p]["icon"]} {p}</span>' for p in ads_map.keys()])}</div>
      </div>
    </div>""", unsafe_allow_html=True)

    # Global feedback
    st.markdown('<div class="ab-card" style="padding:18px 24px;margin-bottom:20px">', unsafe_allow_html=True)
    st.markdown('<div class="ab-label">Global Feedback — Regenerate All Texts</div>', unsafe_allow_html=True)
    gf_col, gb_col = st.columns([5, 1])
    with gf_col:
        global_fb = st.text_input(
            "global_feedback", label_visibility="collapsed",
            placeholder="Apply feedback to all platforms at once…",
            key=f"global_fb_{st.session_state.ad_version_num}"
        )
    with gb_col:
        if st.button("Apply →", use_container_width=True):
            if global_fb.strip():
                add_chat("human", f"Global: {global_fb}")
                with st.spinner("Regenerating all…"):
                    try:
                        result = api("post",
                            f"/campaigns/{st.session_state.campaign_id}/generate",
                            json={"platforms": selected, "feedback": global_fb}
                        )
                        st.session_state.ads = [ad for ad in result["ads"] if ad["platform"] in selected]
                        st.session_state.ad_version_num = result["version"]
                        add_chat("agent", f"✅ v{result['version']} ready!")
                        st.rerun()
                    except Exception as e:
                        st.error(str(e))
            else:
                st.warning("Type some feedback first.")
    st.markdown("</div>", unsafe_allow_html=True)

    # Per-platform tabs
    valid_platforms = [p for p in selected if p in ads_map]
    tabs = st.tabs([f"{PLATFORMS[p]['icon']} {p}" for p in valid_platforms])
    edited_ads = {}

    for tab, platform in zip(tabs, valid_platforms):
        ad    = ads_map[platform]
        limit = PLATFORMS[platform]["max_chars"]
        info  = PLATFORMS[platform]

        with tab:
            # ── Preview + Edit side by side ──────────────────────────────
            prev_col, edit_col = st.columns([1, 1], gap="large")

            # LEFT: Platform preview
            with prev_col:
                st.markdown('<div class="ab-label">Live Preview</div>', unsafe_allow_html=True)
                render_platform_preview(platform, ad)

            # RIGHT: Editor
            with edit_col:
                st.markdown('<div class="ab-label">Ad Copy Editor</div>', unsafe_allow_html=True)
                edited = st.text_area(
                    f"edit_{platform}",
                    value=ad["content"], height=220,
                    label_visibility="collapsed",
                    key=f"edit_{platform}_{st.session_state.ad_version_num}"
                )
                edited_ads[platform] = {"ad_id": ad["id"], "content": edited}
                chars = len(edited)
                color = "var(--green)" if chars <= limit else "var(--rose)"
                st.markdown(f'<div style="text-align:right;font-size:11px;color:{color};margin-top:3px;font-family:\'Space Mono\',monospace">{chars:,} / {limit:,}</div>', unsafe_allow_html=True)

                # Text regen
                st.markdown("")
                st.markdown('<div class="ab-label">Text Feedback</div>', unsafe_allow_html=True)
                fb_c, btn_c = st.columns([4, 1])
                with fb_c:
                    feedback = st.text_input(
                        f"fb_{platform}", label_visibility="collapsed",
                        placeholder="'more urgent' · 'add price' · 'funnier'…",
                        key=f"fb_{platform}_{st.session_state.ad_version_num}"
                    )
                with btn_c:
                    if st.button("↺", key=f"regen_text_{platform}", help="Regenerate text"):
                        fb_text = feedback.strip() or "Improve this ad copy"
                        add_chat("human", f"[{platform}] Regen: {fb_text}")
                        with st.spinner(f"Rewriting…"):
                            try:
                                result = api("post",
                                    f"/campaigns/{st.session_state.campaign_id}/generate",
                                    json={"platforms": [platform], "feedback": fb_text}
                                )
                                new_ads = [a for a in result["ads"] if a["platform"] == platform]
                                if new_ads:
                                    st.session_state.ads = [
                                        new_ads[0] if a["platform"] == platform else a
                                        for a in st.session_state.ads
                                    ]
                                    st.session_state.ad_version_num = result["version"]
                                    add_chat("agent", f"✅ [{platform}] text rewritten (v{result['version']})")
                                    st.rerun()
                            except Exception as e:
                                st.error(str(e))

                # Image section
                st.markdown("")
                st.markdown('<div class="ab-label">Image</div>', unsafe_allow_html=True)

                if platform == "Instagram":
                    st.markdown('<div style="font-size:11px;color:var(--green);margin-bottom:8px">✦ Image required &amp; auto-generated</div>', unsafe_allow_html=True)
                    img_on = True
                else:
                    img_on = st.checkbox(
                        "Generate image for this platform",
                        value=st.session_state.img_enabled.get(platform, False),
                        key=f"img_on_{platform}"
                    )
                    st.session_state.img_enabled[platform] = img_on

                if img_on:
                    src_keys    = list(IMAGE_SOURCES.keys())
                    src_labels  = list(IMAGE_SOURCES.values())
                    current_src = st.session_state.img_sources.get(platform, "flux")
                    src_idx     = src_keys.index(current_src) if current_src in src_keys else 0

                    st.markdown('<div class="ab-label" style="margin-top:10px">Image Source</div>', unsafe_allow_html=True)
                    chosen_src_label = st.selectbox(
                        f"src_{platform}", src_labels, index=src_idx,
                        label_visibility="collapsed",
                        key=f"src_{platform}_{st.session_state.ad_version_num}"
                    )
                    chosen_src = src_keys[src_labels.index(chosen_src_label)]
                    st.session_state.img_sources[platform] = chosen_src

                    current_img = ad.get("image_url", "")
                    if current_img:
                        st.image(current_img, use_container_width=True)
                        src_label_used = IMAGE_SOURCES.get(ad.get("image_source", ""), ad.get("image_source", ""))
                        st.markdown(f'<div style="font-size:10px;color:var(--muted);margin-top:4px">Source: {src_label_used}</div>', unsafe_allow_html=True)
                    else:
                        st.markdown("""
                        <div style="background:var(--surface);border:1px dashed var(--border2);
                          border-radius:10px;padding:28px;text-align:center;color:var(--muted);
                          font-size:13px">
                          🖼️<br/>No image yet — generate one below
                        </div>""", unsafe_allow_html=True)

                    # ── Image feedback input ──────────────────────────────────
                    st.markdown('<div class="ab-label" style="margin-top:12px">Image Style Instructions</div>', unsafe_allow_html=True)
                    st.markdown(
                        '<div style="font-size:11px;color:var(--muted);margin-bottom:6px">'
                        'Describe exactly what you want. This replaces the auto-detected style.'
                        '</div>', unsafe_allow_html=True
                    )

                    # Persist feedback in session state keyed by platform only (not version)
                    # so it survives reruns without resetting
                    fb_key = f"img_fb_input_{platform}"
                    if fb_key not in st.session_state:
                        st.session_state[fb_key] = st.session_state.img_feedback.get(platform, "")

                    img_fb = st.text_area(
                        f"img_fb_{platform}",
                        label_visibility="collapsed",
                        placeholder=(
                            "Examples:\n"
                            "• fresh vegetables on a wooden table, natural morning light\n"
                            "• outdoor café setting, warm golden hour, cozy atmosphere\n"
                            "• close-up of product on white background, studio lighting\n"
                            "• corporate office team meeting, diverse professionals"
                        ),
                        height=100,
                        key=fb_key,
                    )
                    # Sync back to persistent store
                    st.session_state.img_feedback[platform] = img_fb

                    # Show active feedback badge
                    if img_fb.strip():
                        st.markdown(
                            f'<div style="background:rgba(79,110,247,.08);border:1px solid rgba(79,110,247,.2);'
                            f'border-radius:8px;padding:8px 12px;font-size:11px;color:var(--accent2);'
                            f'margin-bottom:8px">✦ Feedback active — will be applied on next generate</div>',
                            unsafe_allow_html=True
                        )

                    # ── Buttons ───────────────────────────────────────────────
                    g1, g2 = st.columns(2)
                    with g1:
                        gen_label = "✦ Generate Image" if not current_img else "↺ Regen with Feedback"
                        if st.button(gen_label, key=f"gen_img_{platform}", use_container_width=True,
                                     type="primary" if img_fb.strip() else "secondary"):
                            with st.spinner(f"Generating{' with your feedback' if img_fb.strip() else ''}…"):
                                try:
                                    api("put", f"/ads/{ad['id']}", json={"content": edited_ads[platform]['content']})
                                    endpoint = "regenerate-image" if current_img else "generate-image"
                                    params   = {"source": chosen_src}
                                    if img_fb.strip():
                                        params["feedback"] = img_fb.strip()
                                    import urllib.parse as _urlparse
                                    query = "?" + _urlparse.urlencode(params)
                                    updated_ad = api("post", f"/ads/{ad['id']}/{endpoint}{query}")
                                    st.session_state.ads = [
                                        updated_ad if a["platform"] == platform else a
                                        for a in st.session_state.ads
                                    ]
                                    fb_note = f" (feedback: {img_fb[:40]}…)" if img_fb.strip() else ""
                                    add_chat("agent", f"✅ [{platform}] image generated via {chosen_src}{fb_note}")
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"Image generation failed: {e}")
                    with g2:
                        shuffle_label = "🔀 Shuffle"
                        if current_img and st.button(shuffle_label, key=f"shuf_img_{platform}", use_container_width=True,
                                                      help="New random seed, same feedback/style"):
                            with st.spinner("Shuffling…"):
                                try:
                                    # Shuffle always carries the current feedback too
                                    params = {"source": chosen_src}
                                    if img_fb.strip():
                                        params["feedback"] = img_fb.strip()
                                    import urllib.parse as _urlparse
                                    query = "?" + _urlparse.urlencode(params)
                                    updated_ad = api("post", f"/ads/{ad['id']}/regenerate-image{query}")
                                    st.session_state.ads = [
                                        updated_ad if a["platform"] == platform else a
                                        for a in st.session_state.ads
                                    ]
                                    add_chat("agent", f"✅ [{platform}] image shuffled")
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"Shuffle failed: {e}")

            st.markdown('<div style="height:16px"></div>', unsafe_allow_html=True)
            st.markdown('<hr style="margin:4px 0 16px"/>', unsafe_allow_html=True)

            # Per-platform post button
            pc1, pc2 = st.columns([2, 1])
            with pc2:
                if st.button(
                    f"🚀 Post to {platform} Only",
                    key=f"post_only_{platform}",
                    use_container_width=True,
                    type="primary"
                ):
                    add_chat("human", f"Post to {platform} only.")
                    with st.spinner(f"Posting to {platform}…"):
                        try:
                            api("put", f"/ads/{ad['id']}", json={"content": edited_ads[platform]['content']})
                            post = api("post", f"/ads/{ad['id']}/post")
                            # Merge into existing posts
                            existing = [p for p in st.session_state.posts if p.get("platform") != platform]
                            st.session_state.posts = existing + [post]
                            add_chat("agent", f"🚀 <b>{platform}</b> ad is live!")
                            st.success(f"✅ Posted to {platform}!")
                        except ValueError as e:
                            st.error(str(e))

    # ── Bottom action bar ─────────────────────────────────────────────────────
    st.markdown('<div class="section-divider"><span>Post Actions</span></div>', unsafe_allow_html=True)
    st.markdown('<div class="ab-card" style="padding:20px 24px">', unsafe_allow_html=True)

    ac1, ac2, ac3 = st.columns(3)
    with ac1:
        if st.button("✅ Post to All Platforms", type="primary", use_container_width=True):
            add_chat("human", "Post to all platforms.")
            errors, posted = [], []
            with st.spinner("Posting to all platforms…"):
                for platform, info in edited_ads.items():
                    try:
                        api("put", f"/ads/{info['ad_id']}", json={"content": info["content"]})
                        fresh_ads = api("get", f"/campaigns/{st.session_state.campaign_id}/ads")
                        fresh_ad  = next((a for a in fresh_ads if a["id"] == info["ad_id"]), None)
                        if fresh_ad:
                            st.session_state.ads = [
                                fresh_ad if a["id"] == info["ad_id"] else a
                                for a in st.session_state.ads
                            ]
                        post = api("post", f"/ads/{info['ad_id']}/post")
                        posted.append(post)
                    except ValueError as e:
                        errors.append(f"{platform}: {e}")
            if posted:
                st.session_state.posts = posted
                st.session_state.step = "monitor"
                add_chat("agent", f"🚀 <b>{len(posted)} ads live!</b> Metrics auto-refresh every 30 min.")
                _snapshot_current_session()
                st.rerun()
            for err in errors:
                st.error(err)

    with ac2:
        if st.button("🔄 Regenerate All", use_container_width=True):
            add_chat("human", "Regenerate all ads.")
            st.session_state.step = "generating"; st.rerun()

    with ac3:
        if st.button("← Change Platforms", use_container_width=True):
            st.session_state.step = "platform_select"; st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)

    # View posted if any
    if st.session_state.posts:
        if st.button("📊 View Posted Ads →", use_container_width=True):
            st.session_state.step = "monitor"; st.rerun()

# ═════════════════════════════════════════════════════════════════════════════
# STEP 5 — MONITOR
# ═════════════════════════════════════════════════════════════════════════════
elif st.session_state.step == "monitor":

    hdr1, hdr2, hdr3 = st.columns([4, 1, 1])
    with hdr1:
        st.markdown('<div style="font-family:\'Syne\',sans-serif;font-size:22px;font-weight:800;color:var(--bright);margin-bottom:4px">📊 Posted Ads & Metrics</div>', unsafe_allow_html=True)
    with hdr2:
        if st.button("🔄 Refresh", use_container_width=True):
            for post in st.session_state.posts:
                if post.get("status") == "live":
                    try: api("post", f"/posts/{post['id']}/metrics/refresh")
                    except: pass
            st.rerun()
    with hdr3:
        if st.button("← Review Ads", use_container_width=True):
            st.session_state.step = "review"; st.rerun()

    if st.button("＋ New Campaign", type="primary"):
        _new_session()
        st.rerun()

    try:
        all_posts = api("get", f"/campaigns/{st.session_state.campaign_id}/posts")
    except Exception:
        all_posts = st.session_state.posts

    active   = [p for p in all_posts if p.get("status") == "live"]
    inactive = [p for p in all_posts if p.get("status") == "archived"]

    if not active:
        st.info("No active posts yet. Go back to review and post your ads.")

    for post in active:
        m    = post.get("latest_metrics") or {}
        eng  = m.get("eng_rate", 0)
        label, css = eng_badge(eng)
        is_low = eng < 2.5
        icon = PLATFORMS.get(post["platform"], {}).get("icon", "📱")
        posted_dt = datetime.fromisoformat(post["posted_at"]).strftime("%b %d %H:%M")
        plat_color = PLATFORMS.get(post["platform"], {}).get("color", "#5b6ef5")

        card_cls = "posted-card low-eng" if is_low else "posted-card"
        st.markdown(f'<div class="{card_cls}">', unsafe_allow_html=True)

        # Low engagement banner
        if is_low:
            st.markdown(f"""
            <div class="low-eng-banner">
              📉 <b>Low engagement detected on {post['platform']}.</b>
              Consider regenerating this ad with a stronger hook.
            </div>""", unsafe_allow_html=True)

        # Header row
        row1, row2 = st.columns([3, 1])
        with row1:
            st.markdown(f"""
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
              <div style="font-size:28px">{icon}</div>
              <div>
                <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:var(--bright)">{post['platform']}</div>
                <div style="font-size:12px;color:var(--muted);font-family:'Space Mono',monospace">
                  {post.get('hours_live',0)}h live · {posted_dt} · ID: {post.get('platform_post_id','—')[:18]}
                </div>
              </div>
              <span class="eng-badge {css}" style="margin-left:12px">{label} — {eng}%</span>
            </div>""", unsafe_allow_html=True)

        # Metrics
        mc1, mc2, mc3, mc4, mc5 = st.columns(5)
        mc1.metric("👁️ Views",    f"{m.get('views', 0):,}")
        mc2.metric("❤️ Likes",    m.get("likes", 0))
        mc3.metric("🔁 Shares",   m.get("shares", 0))
        mc4.metric("💬 Comments", m.get("comments", 0))
        mc5.metric("🖱️ Clicks",   m.get("clicks", 0))

        # Ad content preview
        ad_content = next((a["content"] for a in st.session_state.ads if a.get("id") == post.get("ad_id")), "—")
        ad_img     = next((a.get("image_url","") for a in st.session_state.ads if a.get("id") == post.get("ad_id")), "")
        ad_obj     = next((a for a in st.session_state.ads if a.get("id") == post.get("ad_id")), {})

        with st.expander(f"📄 View Ad Content — {post['platform']}"):
            if ad_img:
                ic1, ic2 = st.columns([1, 2])
                with ic1: st.image(ad_img, use_container_width=True)
                with ic2:
                    st.markdown(f"""
                    <div style="background:var(--surface);border:1px solid var(--border2);
                      border-radius:12px;padding:16px 18px;font-size:14px;
                      line-height:1.75;color:var(--text);white-space:pre-wrap;word-break:break-word">
                      {ad_content}
                    </div>""", unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div style="background:var(--surface);border:1px solid var(--border2);
                  border-radius:12px;padding:16px 18px;font-size:14px;
                  line-height:1.75;color:var(--text);white-space:pre-wrap;word-break:break-word">
                  {ad_content}
                </div>""", unsafe_allow_html=True)

        # Action row
        act1, act2, act3, act4 = st.columns(4)
        with act1:
            if st.button("🗑️ Delete Post", key=f"del_{post['id']}", use_container_width=True):
                try: api("delete", f"/posts/{post['id']}"); st.rerun()
                except Exception as e: st.error(str(e))

        with act2:
            if st.button("✏️ Regenerate Ad", key=f"regen_{post['id']}", use_container_width=True,
                         type="primary" if is_low else "secondary"):
                add_chat("human", f"Regenerate {post['platform']} ad.")
                with st.spinner(f"Rewriting {post['platform']} ad…"):
                    try:
                        feedback_msg = (
                            "Previous had poor engagement. Add a stronger hook, more urgency."
                            if is_low else "Improve this ad copy."
                        )
                        result = api("post",
                            f"/campaigns/{st.session_state.campaign_id}/generate",
                            json={"platforms": [post["platform"]], "feedback": feedback_msg}
                        )
                        new_ads = [a for a in result["ads"] if a["platform"] == post["platform"]]
                        if new_ads:
                            st.session_state.ads = [
                                new_ads[0] if a["platform"] == post["platform"] else a
                                for a in st.session_state.ads
                            ]
                            st.session_state.selected_platforms = [post["platform"]]
                            st.session_state.ad_version_num = result["version"]
                            add_chat("agent", f"✅ [{post['platform']}] improved v{result['version']} ready.")
                            # Archive old post
                            try: api("delete", f"/posts/{post['id']}")
                            except: pass
                            st.session_state.step = "review"
                            st.rerun()
                    except Exception as e:
                        st.error(str(e))

        with act3:
            if st.button("🖼️ Regen Image", key=f"regen_img_{post['id']}", use_container_width=True):
                if ad_obj:
                    with st.spinner("Regenerating image…"):
                        try:
                            src = st.session_state.img_sources.get(post["platform"], "flux")
                            updated_ad = api("post", f"/ads/{ad_obj['id']}/regenerate-image?source={src}")
                            st.session_state.ads = [
                                updated_ad if a["id"] == ad_obj["id"] else a
                                for a in st.session_state.ads
                            ]
                            add_chat("agent", f"✅ [{post['platform']}] image refreshed")
                            st.rerun()
                        except Exception as e:
                            st.error(str(e))

        with act4:
            if st.button("📈 Refresh Metrics", key=f"refm_{post['id']}", use_container_width=True):
                try:
                    api("post", f"/posts/{post['id']}/metrics/refresh")
                    st.rerun()
                except Exception as e:
                    st.error(str(e))

        st.markdown('</div>', unsafe_allow_html=True)

    # Archived
    if inactive:
        with st.expander(f"🗃️ Archived Posts ({len(inactive)})"):
            for p in inactive:
                m = p.get("latest_metrics") or {}
                eng_val = m.get("eng_rate", 0)
                lbl, css = eng_badge(eng_val)
                st.markdown(
                    f'`{PLATFORMS.get(p["platform"],{}).get("icon","📱")} {p["platform"]}` — '
                    f'Final: **{eng_val}%** · {m.get("views",0):,} views '
                    f'<span class="eng-badge {css}" style="font-size:11px">{lbl}</span>',
                    unsafe_allow_html=True
                )

    # Low engagement handler
    low_posts = [p for p in active
                 if (p.get("latest_metrics") or {}).get("eng_rate", 99) < 2.5
                 and not st.session_state.low_eng_shown]
    if low_posts:
        names = ", ".join([f"<b>{p['platform']}</b>" for p in low_posts])
        add_chat("agent", f"📉 Low engagement on {names}. Click 'Regenerate Ad' on that platform.")
        st.session_state.low_eng_shown = True
        st.rerun()

# ── Footer ────────────────────────────────────────────────────────────────────
st.markdown('<p style="text-align:center;color:#1c2238;font-size:11px;margin-top:60px;padding-bottom:24px;font-family:\'Space Mono\',monospace">AdBot v3 · Gemini AI · FastAPI · SQLite · Real Platform APIs</p>', unsafe_allow_html=True)