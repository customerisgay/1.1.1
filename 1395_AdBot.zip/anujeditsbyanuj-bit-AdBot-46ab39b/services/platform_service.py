"""
services/platform_service.py
Real social media platform API integrations.
image_url is passed in from the Ad record (already stored in DB).
"""

import os, time, hashlib, base64, requests
from dotenv import load_dotenv
import praw

load_dotenv()


def _to_direct_image_url(url: str) -> str:
    """
    Instagram/Facebook need a direct image URL with no redirects and a proper
    Content-Type: image/... header.

    Strategy:
      1. If it's already an imgbb URL → use as-is (always direct)
      2. Otherwise → download the image bytes, upload to imgbb, return that URL
      3. If imgbb key missing → follow redirects and return final URL (best effort)
    """
    if not url:
        return url

    # imgbb URLs are always direct JPEG/PNG — no processing needed
    if "ibb.co" in url or "imgbb.com" in url:
        return url

    imgbb_key = os.getenv("IMGBB_API_KEY", "")

    if imgbb_key:
        try:
            # Download image bytes
            print(f"Downloading image for re-upload: {url}")
            resp = requests.get(url, timeout=30, allow_redirects=True)
            resp.raise_for_status()

            content_type = resp.headers.get("content-type", "")
            if "image" not in content_type:
                print(f"Warning: content-type is '{content_type}', proceeding anyway")

            img_b64 = base64.b64encode(resp.content).decode("utf-8")
            seed    = abs(hash(url)) % 99999

            # Upload to imgbb
            upload = requests.post(
                "https://api.imgbb.com/1/upload",
                data={"key": imgbb_key, "image": img_b64, "name": f"adbot_ig_{seed}"},
                timeout=30,
            )
            data = upload.json()
            if data.get("success"):
                direct = data["data"]["url"]
                print(f"Re-uploaded to imgbb: {direct}")
                return direct
            else:
                print(f"imgbb re-upload failed: {data}")
        except Exception as e:
            print(f"imgbb re-upload error: {e}")

    # Fallback: just follow redirects
    try:
        r = requests.head(url, allow_redirects=True, timeout=15)
        return r.url
    except Exception:
        return url



def _sanitize_telegram_markdown(text: str) -> str:
    """
    Telegram's legacy Markdown parser requires every *, _, and ` to be paired
    on the same line. AI-generated copy often has unmatched markers (e.g. a
    bullet line starting with * that is never closed, or stray underscores in
    URLs/prices). This function ensures every such character is properly paired
    or escaped, preventing the 'Can't find end of entity' Bad Request error.

    Approach: for each line, count occurrences of each special char. If the
    count is odd, escape the last lone occurrence with a backslash so Telegram
    treats it as a literal character instead of a formatting marker.
    """
    def fix_pairs(t: str, char: str) -> str:
        lines = t.split('\n')
        fixed = []
        for line in lines:
            count = line.count(char)
            if count % 2 != 0:
                idx = line.rfind(char)
                line = line[:idx] + '\\' + line[idx:]
            fixed.append(line)
        return '\n'.join(fixed)

    text = fix_pairs(text, '*')
    text = fix_pairs(text, '_')
    text = fix_pairs(text, '`')
    return text

class PlatformService:

    def post(self, platform: str, content: str, image_url: str = None) -> dict:
        handlers = {
            "Telegram":    self._post_telegram,
            "Facebook":    self._post_facebook,
            "Discord":     self._post_discord,
            "Instagram":   self._post_instagram,
            "LinkedIn":    self._post_linkedin,
            
            "WhatsApp":    self._post_whatsapp,
            "Reddit":      self._post_reddit,
            "X (Twitter)": self._post_twitter,
        }
        handler = handlers.get(platform)
        if not handler:
            raise ValueError(f"Unknown platform: {platform}")
        return handler(content, image_url=image_url)

    # ── TELEGRAM ──────────────────────────────────────────────────────────────
    def _post_telegram(self, content: str, image_url: str = None) -> dict:
        token   = os.getenv("TELEGRAM_BOT_TOKEN", "")
        chat_id = os.getenv("TELEGRAM_CHAT_ID", "")

        # Sanitize markdown — unpaired *, _, ` cause a Telegram Bad Request error
        safe_content = _sanitize_telegram_markdown(content)
        caption      = _sanitize_telegram_markdown(content[:1024])

        if image_url:
            api_url = f"https://api.telegram.org/bot{token}/sendPhoto"
            resp    = requests.post(api_url, json={
                "chat_id":    chat_id,
                "photo":      image_url,
                "caption":    caption,
                "parse_mode": "Markdown",
            }, timeout=30)
            data = resp.json()
            if not data.get("ok"):
                # Image failed — fall back to text-only
                print(f"Telegram photo failed: {data.get('description')} — sending text only")
                api_url = f"https://api.telegram.org/bot{token}/sendMessage"
                resp    = requests.post(api_url, json={
                    "chat_id":    chat_id,
                    "text":       safe_content,
                    "parse_mode": "Markdown",
                }, timeout=10)
                data = resp.json()
        else:
            api_url = f"https://api.telegram.org/bot{token}/sendMessage"
            resp    = requests.post(api_url, json={
                "chat_id":    chat_id,
                "text":       safe_content,
                "parse_mode": "Markdown",
            }, timeout=10)
            data = resp.json()

        if not data.get("ok"):
            # Last resort: retry without parse_mode (plain text — always works)
            print(f"Telegram Markdown failed: {data.get('description')} — retrying as plain text")
            api_url = f"https://api.telegram.org/bot{token}/sendMessage"
            resp    = requests.post(api_url, json={
                "chat_id": chat_id,
                "text":    content,
            }, timeout=10)
            data = resp.json()
            if not data.get("ok"):
                raise ValueError(f"Telegram error: {data.get('description', 'Unknown')}")

        return {"post_id": str(data["result"]["message_id"])}

    # ── DISCORD ───────────────────────────────────────────────────────────────
    def _post_discord(self, content: str, image_url: str = None) -> dict:
        channel_id = os.getenv("DISCORD_CHANNEL_ID", "")
        bot_token  = os.getenv("DISCORD_BOT_TOKEN", "")
        url        = f"https://discord.com/api/v10/channels/{channel_id}/messages"
        resp       = requests.post(url, json={"content": content},
                                   headers={"Authorization": f"Bot {bot_token}"}, timeout=10)
        data = resp.json()
        if resp.status_code != 200:
            raise ValueError(f"Discord error: {data.get('message', 'Unknown')}")
        return {"post_id": str(data["id"])}

    # ── FACEBOOK ──────────────────────────────────────────────────────────────
    def _post_facebook(self, content: str, image_url: str = None) -> dict:
        access_token = os.getenv("FACEBOOK_PAGE_ACCESS_TOKEN", "")
        page_id      = os.getenv("FACEBOOK_PAGE_ID", "")

        if image_url:
            direct = _to_direct_image_url(image_url)
            url    = f"https://graph.facebook.com/v18.0/{page_id}/photos"
            resp   = requests.post(url, data={"caption": content, "url": direct,
                                              "access_token": access_token}, timeout=30)
        else:
            url  = f"https://graph.facebook.com/v18.0/{page_id}/feed"
            resp = requests.post(url, data={"message": content,
                                            "access_token": access_token}, timeout=10)

        data = resp.json()
        if "error" in data:
            raise ValueError(f"Facebook error: {data['error']['message']}")
        return {"post_id": data.get("id", data.get("post_id", ""))}

    # ── INSTAGRAM ─────────────────────────────────────────────────────────────
    def _post_instagram(self, content: str, image_url: str = None) -> dict:
        access_token = os.getenv("INSTAGRAM_ACCESS_TOKEN", "")
        account_id   = os.getenv("INSTAGRAM_ACCOUNT_ID", "")

        if not access_token or not account_id:
            return self._stub("Instagram", content)

        if not image_url:
            raise ValueError(
                "Instagram requires an image. Please click 'Generate Image' "
                "in the Review step before posting to Instagram."
            )

        # image_url should already be an imgbb URL (set by image_selector.py)
        direct_url = image_url
        print(f"Instagram posting with image URL: {direct_url}")

        # Step 1: Create media container
        container_resp = requests.post(
            f"https://graph.instagram.com/v18.0/{account_id}/media",
            params={"caption": content, "image_url": direct_url,
                    "access_token": access_token},
            timeout=60,
        )
        container_data = container_resp.json()
        if "error" in container_data:
            raise ValueError(f"Instagram container error: {container_data['error']['message']}")
        container_id = container_data.get("id")
        if not container_id:
            raise ValueError("Instagram: failed to get container ID")

        # Step 2: Wait for media ready
        for attempt in range(10):
            status_resp = requests.get(
                f"https://graph.instagram.com/v18.0/{container_id}",
                params={"fields": "status_code", "access_token": access_token},
                timeout=10,
            )
            status = status_resp.json().get("status_code", "")
            print(f"Instagram container attempt {attempt + 1}: {status}")
            if status == "FINISHED": break
            elif status == "ERROR":  raise ValueError("Instagram: media container failed")
            time.sleep(3)
        else:
            raise ValueError("Instagram: media container timed out")

        # Step 3: Publish
        pub_resp = requests.post(
            f"https://graph.instagram.com/v18.0/{account_id}/media_publish",
            params={"creation_id": container_id, "access_token": access_token},
            timeout=10,
        )
        pub_data = pub_resp.json()
        if "error" in pub_data:
            raise ValueError(f"Instagram publish error: {pub_data['error']['message']}")
        return {"post_id": str(pub_data.get("id", ""))}

    # ── LINKEDIN ──────────────────────────────────────────────────────────────
    def _post_linkedin(self, content: str, image_url: str = None) -> dict:
        access_token = os.getenv("LINKEDIN_ACCESS_TOKEN", "")
        author_urn   = os.getenv("LINKEDIN_AUTHOR_URN", "")
        if not access_token or not author_urn:
            return self._stub("LinkedIn", content)
        body = {
            "author": author_urn, "lifecycleState": "PUBLISHED",
            "specificContent": {"com.linkedin.ugc.ShareContent": {
                "shareCommentary": {"text": content}, "shareMediaCategory": "NONE",
            }},
            "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"},
        }
        resp = requests.post("https://api.linkedin.com/v2/ugcPosts", json=body, headers={
            "Authorization": f"Bearer {access_token}", "Content-Type": "application/json",
        }, timeout=10)
        if resp.status_code not in (200, 201):
            raise ValueError(f"LinkedIn error: {resp.text}")
        return {"post_id": resp.headers.get("x-restli-id", "")}

    # ── WHATSAPP ──────────────────────────────────────────────────────────────
    def _post_whatsapp(self, content: str, image_url: str = None) -> dict:
        token     = os.getenv("WHATSAPP_TOKEN", "")
        phone_id  = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
        to_number = os.getenv("WHATSAPP_TO_NUMBER", "")
        if not all([token, phone_id, to_number]):
            return self._stub("WhatsApp", content)
        url  = f"https://graph.facebook.com/v18.0/{phone_id}/messages"
        body = {"messaging_product": "whatsapp", "to": to_number,
                "type": "text", "text": {"body": content}}
        resp = requests.post(url, json=body, headers={
            "Authorization": f"Bearer {token}", "Content-Type": "application/json"
        }, timeout=10)
        data = resp.json()
        if "error" in data:
            raise ValueError(f"WhatsApp error: {data['error']['message']}")
        return {"post_id": data.get("messages", [{}])[0].get("id", "")}

    # ── REDDIT ────────────────────────────────────────────────────────────────
    def _post_reddit(self, content: str, image_url: str = None) -> dict:
        client_id     = os.getenv("REDDIT_CLIENT_ID", "")
        client_secret = os.getenv("REDDIT_CLIENT_SECRET", "")
        username      = os.getenv("REDDIT_USERNAME", "")
        password      = os.getenv("REDDIT_PASSWORD", "")
        subreddit     = os.getenv("REDDIT_SUBREDDIT", "test")
        if not all([client_id, client_secret, username, password]):
            return self._stub("Reddit", content)
        reddit = praw.Reddit(client_id=client_id, client_secret=client_secret,
                             username=username, password=password,
                             user_agent=f"AdBot:v1.0 (by u/{username})")
        lines = content.strip().split("\n")
        title = lines[0][:300]
        body  = "\n".join(lines[1:]) if len(lines) > 1 else content
        post  = reddit.subreddit(subreddit).submit(title=title, selftext=body)
        return {"post_id": str(post.id)}

    # ── TWITTER / X ───────────────────────────────────────────────────────────
    def _post_twitter(self, content: str, image_url: str = None) -> dict:
        api_key             = os.getenv("TWITTER_API_KEY", "")
        api_secret          = os.getenv("TWITTER_API_SECRET", "")
        access_token        = os.getenv("TWITTER_ACCESS_TOKEN", "")
        access_token_secret = os.getenv("TWITTER_ACCESS_TOKEN_SECRET", "")
        if not all([api_key, api_secret, access_token, access_token_secret]):
            return self._stub("X (Twitter)", content)
        return self._stub("X (Twitter)", content)

    # ── STUB ──────────────────────────────────────────────────────────────────
    def _stub(self, platform: str, content: str) -> dict:
        fake_id = hashlib.md5(f"{platform}{content}{time.time()}".encode()).hexdigest()[:12]
        print(f"[STUB] {platform}: '{content[:60]}' → fake_id={fake_id}")
        return {"post_id": f"stub_{fake_id}"}