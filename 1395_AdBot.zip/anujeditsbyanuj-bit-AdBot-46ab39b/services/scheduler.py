"""
services/scheduler.py
Background scheduler — polls metrics for all live posts every 30 minutes.
Uses APScheduler (pip install apscheduler).
"""

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from database import SessionLocal
from services.metrics_service import MetricsService
import logging

logger    = _scheduler = None
metrics_svc = MetricsService()


def _poll_all_metrics():
    """Called every 30 minutes. Fetches metrics for every live post."""
    from models import Post
    db = SessionLocal()
    try:
        live_posts = db.query(Post).filter(Post.status == "live").all()
        logger.info(f"[Scheduler] Polling metrics for {len(live_posts)} live posts...")
        for post in live_posts:
            try:
                metrics_svc.fetch_and_save(post.id, db)
            except Exception as e:
                logger.warning(f"[Scheduler] Failed metrics for post {post.id}: {e}")
    finally:
        db.close()


def start_scheduler():
    global _scheduler, logger
    logger = logging.getLogger("adbot.scheduler")
    _scheduler = BackgroundScheduler()
    _scheduler.add_job(
        _poll_all_metrics,
        trigger=IntervalTrigger(minutes=30),
        id="metrics_poll",
        name="Poll platform metrics",
        replace_existing=True,
    )
    _scheduler.start()
    logger.info("[Scheduler] Started — metrics polling every 30 minutes.")


def stop_scheduler():
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
