"""
services/metrics_service.py
Fetches real engagement metrics from each platform API.
Falls back to simulation when API keys are not configured.
"""

import os, random
import requests
from datetime import datetime, timezone
from dotenv import load_dotenv

load_dotenv()


class MetricsService:

    def fetch_and_save(self, post_id: int, db) -> object:
        """Fetch latest metrics for a post and save a new snapshot to DB."""
        from models import Post, Metrics

        post = db.query(Post).filter(Post.id == post_id).first()

        if not post:
            raise ValueError(f"Post {post_id} not found")

        # Fetch from the right platform
        raw = self._fetch(post.platform, post.platform_post_id) # bring the post_id and platform_post_id from the db

        # Save snapshot
        snapshot = Metrics(
            post_id     = post_id,
            views       = raw["views"],
            likes       = raw["likes"],
            shares      = raw["shares"],
            comments    = raw["comments"],
            clicks      = raw["clicks"],
            eng_rate    = raw["eng_rate"],
            recorded_at = datetime.now(timezone.utc),
        )
        # Increment hours_live
        post.hours_live += 1

        db.add(snapshot)
        db.commit()
        db.refresh(snapshot)
        return snapshot

    # Router
    def _fetch(self, platform: str, platform_post_id: str) -> dict:
        fetchers = {
            "Telegram":    self._fetch_telegram,
            "Discord":     self._fetch_discord,
            "Instagram":   self._fetch_instagram,
            "Facebook":    self._fetch_facebook,
            "LinkedIn":    self._fetch_linkedin,

            "X (Twitter)": self._fetch_twitter,
            "WhatsApp":    self._fetch_whatsapp,

        }

        fetcher = fetchers.get(platform)

        if not fetcher:
            return self._simulate(platform)
        
        return fetcher(platform_post_id)

    # FACEBOOK 
    # Facebook returns real insights via Graph API
    def _fetch_facebook(self, post_id: str) -> dict:
        token = os.getenv("FACEBOOK_PAGE_ACCESS_TOKEN", "")

        # if not token or post_id.startswith("stub_"):
        #     return self._simulate("Facebook")

        url = f"https://graph.facebook.com/v18.0/{post_id}/insights"
        resp = requests.get(url, params={
            "metric":       "post_impressions,post_engagements,post_clicks",
            "access_token": token,
        }, timeout=10)

        data = resp.json().get("data", [])
        metrics = {item["name"]: item["values"][0]["value"] for item in data}

    #   Facebook's response structure:
    #   "data": [{
    #     "name": "post_impressions",
    #     "values": [{"value": 1200}]
    #   }

        views    = metrics.get("post_impressions", 0)
        engaged  = metrics.get("post_engagements", 0)
        clicks   = metrics.get("post_clicks", 0)
        eng_rate = round((engaged / views * 100), 2) if views > 0 else 0

        return {"views": views, "likes": engaged // 2, "shares": engaged // 6,
                "comments": engaged // 8, "clicks": clicks, "eng_rate": eng_rate}


    # INSTAGRAM
    def _fetch_instagram(self, post_id: str) -> dict:
        token = os.getenv("INSTAGRAM_ACCESS_TOKEN", "")

        url  = f"https://graph.facebook.com/v18.0/{post_id}/insights"
        resp = requests.get(url, params={
            "metric":       "impressions,reach,likes,comments,shares,saved",
            "access_token": token,
        }, timeout=10)

        data = {item["name"]: item["values"][0]["value"] for item in resp.json().get("data", [])}

        views    = data.get("impressions", 0)
        likes    = data.get("likes", 0)
        comments = data.get("comments", 0)
        shares   = data.get("shares", 0)
        eng_rate = round(((likes + comments + shares) / max(views, 1)) * 100, 2)
        return {"views": views, "likes": likes, "shares": shares,
                "comments": comments, "clicks": data.get("saved", 0), "eng_rate": eng_rate}

    # LINKEDIN 
    def _fetch_linkedin(self, post_id: str) -> dict:
        token = os.getenv("LINKEDIN_ACCESS_TOKEN", "")
        
        url  = f"https://api.linkedin.com/v2/socialActions/{post_id}"
        resp = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=10)
        data = resp.json()

        likes    = data.get("likesSummary",   {}).get("totalLikes", 0)
        comments = data.get("commentsSummary",{}).get("totalFirstLevelComments", 0)
        shares   = data.get("shareStatistics",{}).get("totalShareStatistics",{}).get("shareCount", 0)
        views    = data.get("shareStatistics",{}).get("totalShareStatistics",{}).get("impressionCount", 0)
        eng_rate = round(((likes + comments + shares) / max(views, 1)) * 100, 2)
        return {"views": views, "likes": likes, "shares": shares,
                "comments": comments, "clicks": 0, "eng_rate": eng_rate}

    # Telegram (no public metrics API)
    def _fetch_telegram(self, post_id: str) -> dict:
        # Telegram doesn't expose engagement metrics via Bot API.
        # Channel view counts require a user-account session (Telethon).
        # We simulate for now.
        return self._simulate("Telegram")
    

    def _fetch_discord(self, post_id: str) -> dict:
        # Discord doesn't expose engagement metrics via Bot API.
        # We simulate for now.
        return self._simulate("Discord")

    # ─ WhatsApp (no metrics API)
    def _fetch_whatsapp(self, post_id: str) -> dict:
        # WhatsApp Business API exposes delivery/read receipts, not engagement metrics.
        return self._simulate("WhatsApp")
    
    #  TWITTER / X
    # Docs: https://developer.twitter.com/en/docs/twitter-api/tweets/timelines/api-reference
    def _fetch_twitter(self, post_id: str) -> dict:
        bearer = os.getenv("TWITTER_BEARER_TOKEN", "")
        if not bearer or post_id.startswith("stub_"):
            return self._simulate("X (Twitter)")

        url  = f"https://api.twitter.com/2/tweets/{post_id}"
        resp = requests.get(url,
            params={"tweet.fields": "public_metrics"},
            headers={"Authorization": f"Bearer {bearer}"},
            timeout=10
        )
        m = resp.json().get("data", {}).get("public_metrics", {})
        views    = m.get("impression_count", 0)
        likes    = m.get("like_count", 0)
        shares   = m.get("retweet_count", 0)
        comments = m.get("reply_count", 0)
        clicks   = m.get("url_link_clicks", 0)
        eng_rate = round(((likes + shares + comments) / max(views, 1)) * 100, 2)
        return {"views": views, "likes": likes, "shares": shares,
                "comments": comments, "clicks": clicks, "eng_rate": eng_rate}

    # Simulation fallback 
    def _simulate(self, platform: str, hours: int = 1) -> dict:
        """Realistic simulation used when real API keys are absent."""

        base = {"X (Twitter)": 1.2, "Instagram": 1.9, "Facebook": 1.5,
                "LinkedIn": 1.0, "WhatsApp": 0.6, "Telegram": 0.8}.get(platform, 1.0)
        decay    = max(0.15, 1 - hours / 48)
        views    = int(random.randint(40, 600) * base * decay)
        eng_rate = round(random.uniform(0.5, 7.0), 2)
        likes    = int(views * eng_rate / 100 * random.uniform(0.4, 0.7))
        shares   = int(likes * random.uniform(0.05, 0.25))
        comments = int(likes * random.uniform(0.03, 0.15))
        clicks   = int(views * random.uniform(0.01, 0.06))
        return {"views": views, "likes": likes, "shares": shares,
                "comments": comments, "clicks": clicks, "eng_rate": eng_rate}
