# services/image_selector.py
import re
import io
import os
import base64
import random
import requests
import urllib.parse
from pathlib import Path

try:
    import replicate
except ImportError:
    replicate = None


def _get_keywords(content: str) -> tuple[list[str], list[str]]:
    """Extract content keywords and detect category keywords from ad content."""
    clean = re.sub(r'[^\w\s]', ' ', content)
    clean = re.sub(r'#\w+', '', clean)
    clean = re.sub(r'\*\*.*?\*\*', '', clean)

    stop_words = {
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
        'could', 'should', 'may', 'might', 'shall', 'can', 'need',
        'for', 'to', 'of', 'in', 'on', 'at', 'by', 'with', 'from',
        'this', 'that', 'these', 'those', 'it', 'its', 'you', 'your',
        'our', 'we', 'us', 'and', 'or', 'but', 'so', 'just', 'not',
        'now', 'here', 'there', 'today', 'best', 'get', 'let', 'dont',
        'order', 'yours', 'via', 'link', 'bio', 'right', 'every',
        'more', 'all', 'any', 'each', 'such', 'even', 'also', 'only'
    }

    words = clean.lower().split()
    content_keywords = [w for w in words if w not in stop_words and len(w) > 3]
    content_lower = content.lower()

    if any(w in content_lower for w in ['job', 'hiring', 'vacancy', 'career', 'apply', 'position', 'salary', 'resume', 'recruit']):
        category_keywords = ['office', 'professional', 'career', 'workplace', 'business']
    elif any(w in content_lower for w in ['food', 'biryani', 'pizza', 'burger', 'restaurant', 'eat', 'meal', 'dish', 'taste', 'chef', 'delicious', 'craving']):
        category_keywords = ['food', 'restaurant', 'delicious', 'meal', 'cuisine']
    elif any(w in content_lower for w in ['sale', 'discount', 'offer', 'deal', 'price', 'buy', 'shop', 'store', 'product']):
        category_keywords = ['shopping', 'retail', 'sale', 'store', 'product']
    elif any(w in content_lower for w in ['fitness', 'gym', 'workout', 'health', 'yoga', 'exercise', 'training']):
        category_keywords = ['fitness', 'gym', 'workout', 'health', 'exercise']
    elif any(w in content_lower for w in ['tech', 'software', 'app', 'digital', 'startup', 'code', 'developer']):
        category_keywords = ['technology', 'computer', 'digital', 'software', 'startup']
    elif any(w in content_lower for w in ['travel', 'trip', 'tour', 'hotel', 'flight', 'destination', 'vacation']):
        category_keywords = ['travel', 'destination', 'tourism', 'vacation', 'adventure']
    elif any(w in content_lower for w in ['fashion', 'clothing', 'wear', 'dress', 'style', 'outfit', 'brand']):
        category_keywords = ['fashion', 'clothing', 'style', 'outfit', 'model']
    elif any(w in content_lower for w in ['education', 'course', 'learn', 'study', 'training', 'class', 'school']):
        category_keywords = ['education', 'learning', 'students', 'classroom', 'study']
    elif any(w in content_lower for w in ['real estate', 'property', 'house', 'apartment', 'rent', 'flat', 'home']):
        category_keywords = ['real', 'estate', 'house', 'property', 'interior']
    elif any(w in content_lower for w in ['meme', 'funny', 'comedy', 'laugh', 'joke', 'humor', 'lol', 'hilarious', 'fun']):
        category_keywords = ['funny', 'comedy', 'humor', 'laughing', 'fun']
    elif any(w in content_lower for w in ['music', 'song', 'concert', 'album', 'artist', 'band', 'festival', 'beat']):
        category_keywords = ['music', 'concert', 'artist', 'performance', 'stage']
    elif any(w in content_lower for w in ['beauty', 'skincare', 'makeup', 'cosmetic', 'salon', 'hair', 'glow', 'skin']):
        category_keywords = ['beauty', 'skincare', 'makeup', 'cosmetics', 'salon']
    elif any(w in content_lower for w in ['sports', 'cricket', 'football', 'game', 'match', 'team', 'player', 'tournament']):
        category_keywords = ['sports', 'athlete', 'stadium', 'competition', 'team']
    elif any(w in content_lower for w in ['pet', 'dog', 'cat', 'animal', 'puppy', 'kitten', 'veterinary']):
        category_keywords = ['pets', 'dog', 'cat', 'animal', 'cute']
    elif any(w in content_lower for w in ['wedding', 'event', 'party', 'celebrate', 'anniversary', 'birthday']):
        category_keywords = ['wedding', 'celebration', 'event', 'party', 'festive']
    elif any(w in content_lower for w in ['finance', 'investment', 'money', 'loan', 'insurance', 'bank', 'crypto']):
        category_keywords = ['finance', 'investment', 'money', 'banking', 'business']
    else:
        category_keywords = ['professional', 'business', 'modern', 'clean']

    return content_keywords, category_keywords


# ── PROMPT BUILDER ───────────────────────────────────────────────────────────
def _build_prompt(content: str, feedback: str = "") -> str:
    """
    Build a rich image generation prompt from ad content + optional user feedback.

    feedback overrides the auto-derived style when provided, letting users say
    things like 'warmer lighting', 'outdoor setting', 'show the product clearly'.
    """
    content_keywords, category_keywords = _get_keywords(content)
    category    = category_keywords[0] if category_keywords else "professional"
    top_words   = " ".join(content_keywords[:6])

    # Clean ad text: strip URLs, hashtags, non-ASCII
    clean = re.sub(r'http\S+', '', content)
    clean = re.sub(r'#\w+', '', clean)
    clean = re.sub(r'[^\x00-\x7F]+', '', clean)
    clean = re.sub(r'\*+', '', clean)        # strip markdown bold/italic markers
    clean = re.sub(r'\s+', ' ', clean).strip()
    clean = clean[:200]

    # Base style depends on category
    is_food = ("food" in category or
               any(w in content.lower() for w in
                   ["biryani","pizza","burger","food","restaurant",
                    "eat","meal","dish","vegetable","grocery","cafe"]))

    if is_food:
        base_style = ("food photography, vibrant colors, appetizing, "
                      "close-up shot, natural ingredients visible, "
                      "studio lighting, shallow depth of field")
    elif "job" in category or "career" in category or "office" in category:
        base_style = ("professional office environment, business photography, "
                      "diverse team, modern workspace, natural light")
    elif "real" in category or "estate" in category or "house" in category:
        base_style = ("real estate photography, bright interior, "
                      "wide angle, warm lighting, clean modern space")
    elif "fashion" in category or "clothing" in category:
        base_style = ("fashion photography, editorial style, "
                      "model wearing outfit, clean background, professional lighting")
    elif "tech" in category or "software" in category or "digital" in category:
        base_style = ("technology product photo, sleek, modern, "
                      "dark background, blue accent lighting, futuristic")
    elif "fitness" in category or "gym" in category or "workout" in category:
        base_style = ("fitness photography, action shot, energy, "
                      "gym environment, dynamic lighting, motivated person")
    else:
        base_style = ("professional advertisement photo, commercial photography, "
                      "clean background, studio lighting, sharp focus")

    # If user gave feedback, it REPLACES the style entirely — this is the key fix
    if feedback and feedback.strip():
        style_part = feedback.strip()
        print(f"[image_selector] Using user feedback as style: '{style_part}'")
    else:
        style_part = base_style

    prompt = (
        f"{top_words}, {clean}, "
        f"{style_part}, "
        f"high quality, photorealistic, 4k, no text, no watermark"
    )
    print(f"[image_selector] Prompt: {prompt[:200]}...")
    return prompt


# ── SOURCE 1: Picsum (free stock photos, always works, no key needed) ─────────
# NOTE: Picsum is keyword-blind — feedback has no effect here
def get_unsplash_image(content: str, seed: int = None, feedback: str = "") -> str:
    """Free stock photo via Picsum. Always works, no API key."""
    seed      = seed or random.randint(1, 9999)
    image_id  = seed % 1000
    image_url = f"https://picsum.photos/seed/{image_id}/1080/1080"
    print(f"Fetching Picsum image (seed={seed}, id={image_id})...")
    img_resp = requests.get(image_url, timeout=30, allow_redirects=True)
    print(f"Picsum image URL: {img_resp.url}")
    return img_resp.url


# ── SOURCE 2: Pollinations (free AI images, no key needed) ───────────────────
def get_pollinations_image(content: str, seed: int = None, feedback: str = "") -> str:
    """Free AI-generated image via Pollinations. Falls back to Picsum if fails."""
    seed   = seed or random.randint(1, 9999)
    prompt = _build_prompt(content, feedback)

    encoded_prompt = urllib.parse.quote(prompt)
    image_url = (
        f"https://image.pollinations.ai/prompt/{encoded_prompt}"
        f"?width=1080&height=1080&nologo=true&seed={seed}&model=flux"
    )

    print(f"Generating Pollinations image (seed={seed})...")
    img_resp = requests.get(image_url, timeout=60, allow_redirects=True)

    if img_resp.status_code != 200 or "image" not in img_resp.headers.get("content-type", ""):
        print(f"Pollinations failed ({img_resp.status_code}), falling back to Picsum")
        return get_unsplash_image(content, seed)

    print(f"Pollinations image URL: {img_resp.url}")
    return img_resp.url


# ── SOURCE 3: HuggingFace Space (FLUX.1-schnell, free, best quality) ─────────
def get_flux_image(content: str, seed: int = None, feedback: str = "") -> str:
    """
    AI image via HuggingFace Space running FLUX.1-schnell.
    Fast (~5-10s), free, always running, best quality.
    Falls back to Pollinations if Space is not responding.
    """
    server_url = os.getenv("FLUX_API_URL", "").rstrip("/")
    api_key    = os.getenv("FLUX_API_KEY", "adbot-flux-secret-2024")
    seed       = seed or random.randint(1, 99999)

    if not server_url:
        print("FLUX_API_URL not set — falling back to Pollinations")
        return get_pollinations_image(content, seed, feedback)

    prompt = _build_prompt(content, feedback)

    print(f"Calling HF Space FLUX.1 (seed={seed})...")
    try:
        health = requests.get(f"{server_url}/health", timeout=10)
        if health.status_code != 200:
            raise ConnectionError("HF Space not responding")

        resp = requests.post(
            f"{server_url}/generate",
            json={"prompt": prompt, "steps": 4, "seed": seed},
            headers={"x-api-key": api_key},
            timeout=60,
        )

        if resp.status_code == 401:
            raise ValueError("Wrong FLUX_API_KEY — check .env")

        resp.raise_for_status()
        data    = resp.json()
        img_b64 = data.get("image_b64", "")
        elapsed = data.get("elapsed_sec", "?")

        if not img_b64:
            raise ValueError("Space returned empty image")

        print(f"✅ FLUX image generated in {elapsed}s — uploading to imgbb...")
        img_bytes = base64.b64decode(img_b64)
        return _upload_to_imgbb(img_bytes, seed)

    except (ConnectionError, requests.exceptions.ConnectionError):
        print("⚠️  HF Space not responding — falling back to Pollinations")
        return get_pollinations_image(content, seed, feedback)
    except Exception as e:
        print(f"HF Space failed: {e} — falling back to Pollinations")
        return get_pollinations_image(content, seed, feedback)


# ── SOURCE 4: Replicate API (paid, best quality, FLUX.1 on A100) ─────────────
def get_replicate_image(content: str, seed: int = None, feedback: str = "") -> str:
    """
    FLUX.1 via Replicate API. $5 free credits on signup (~1600 images).
    Falls back to Pollinations if token not set.
    """
    api_token = os.getenv("REPLICATE_API_TOKEN", "")

    if not api_token:
        print("REPLICATE_API_TOKEN not set — falling back to Pollinations")
        return get_pollinations_image(content, seed, feedback)

    if replicate is None:
        print("replicate not installed — run: pip install replicate")
        return get_pollinations_image(content, seed, feedback)

    seed   = seed or random.randint(1, 99999)
    prompt = _build_prompt(content, feedback)

    print(f"Calling Replicate FLUX.1 (seed={seed})...")
    try:
        output = replicate.run(
            "black-forest-labs/flux-schnell",
            input={
                "prompt":              prompt,
                "width":               1080,
                "height":              1080,
                "num_outputs":         1,
                "num_inference_steps": 4,
                "seed":                seed,
            }
        )
        image_url = str(output[0])
        print(f"✅ Replicate image URL: {image_url}")
        return image_url

    except Exception as e:
        print(f"Replicate failed: {e} — falling back to Pollinations")
        return get_pollinations_image(content, seed, feedback)


# ── imgbb: converts base64 bytes to a public HTTPS URL ───────────────────────
def _upload_to_imgbb(img_bytes: bytes, seed: int) -> str:
    """Upload image to imgbb → returns permanent public HTTPS URL."""
    api_key = os.getenv("IMGBB_API_KEY", "")

    if not api_key:
        print("⚠️  IMGBB_API_KEY not set — falling back to Picsum")
        return get_unsplash_image("", seed)

    img_b64 = base64.b64encode(img_bytes).decode("utf-8")
    resp = requests.post(
        "https://api.imgbb.com/1/upload",
        data={"key": api_key, "image": img_b64, "name": f"adbot_{seed}"},
        timeout=30,
    )
    data = resp.json()
    if data.get("success"):
        url = data["data"]["url"]
        print(f"✅ Uploaded to imgbb: {url}")
        return url
    else:
        print(f"imgbb upload failed: {data} — falling back to Picsum")
        return get_unsplash_image("", seed)


# ── MAIN ENTRY POINT ──────────────────────────────────────────────────────────
def get_ad_image_url(content: str, source: str = "flux",
                     seed: int = None, feedback: str = "") -> str:
    """
    Get an image for an ad.

    source:   "flux"         → HF Space FLUX.1-schnell (default, free, best quality)
              "replicate"    → Replicate FLUX.1 ($5 free then paid)
              "pollinations" → free AI, no setup needed
              "unsplash"     → free stock photo (feedback ignored)

    feedback: natural-language style instructions, e.g.:
              "warmer colors", "outdoor setting", "show the product clearly"
              When provided this REPLACES the auto-derived style in the prompt.

    Fallback chain:  flux → pollinations → picsum
    """
    if source == "flux":
        return get_flux_image(content, seed, feedback)
    elif source == "replicate":
        return get_replicate_image(content, seed, feedback)
    elif source == "pollinations":
        return get_pollinations_image(content, seed, feedback)
    else:
        return get_unsplash_image(content, seed, feedback)