"""
services/ai_service.py
Handles all Gemini AI calls: ad type detection, platform suggestions, ad generation.
"""

import os, json
from google import genai
from dotenv import load_dotenv

load_dotenv()

PLATFORM_INFO = {
    "Telegram":  {"style": "informative, use *bold* for key points",           "max": 4096},
    "Discord":   {"style": "casual, fun, community-focused, use @mentions",    "max": 2000},
    "Facebook":  {"style": "conversational, community-focused, detailed",      "max": 63206},
    "Instagram": {"style": "visual storytelling, emojis, hashtags, CTA",      "max": 2200},
    "LinkedIn":   {"style": "professional, value-driven, no fluff",            "max": 3000},
    # Hidden for now - can be enabled in UI and added to ad generation rules later:
    "Reddit":    {"style": "authentic, no-salesy tone, add value to community","max": 40000},
    "WhatsApp":   {"style": "personal, direct, concise, no hashtags",          "max": 1000},
    "X (Twitter)":{"style": "short, punchy, with hashtags",                    "max": 280},
}

# for suggestion ad platforms based on detected ad type - can be expanded with more types/platforms
PLATFORM_SMART = {
    "Job / Hiring":   ["LinkedIn", "Discord", ],
    "Grocery / Food": ["Instagram", "Facebook", "Telegram"],
    "Product Sale":   ["Instagram", "Facebook"],
    "Event":          ["Instagram", "Facebook", "Discord"],
    "Service":        ["Facebook", "Telegram"],
    "Real Estate":    ["Facebook", "Instagram", "Telegram"],
    "Announcement":   ["Telegram", "Discord"],
    "General":        ["Instagram", "Facebook"],
}


class AIService:
    # Initialize Gemini client with API key from environment variable
    def __init__(self):
        api_key = os.getenv("GOOGLE_API_KEY", "")
        if api_key:
            # to establish connection and catch any auth issues early using self.client so we can reuse it for all calls
            self.client = genai.Client(api_key=api_key)

    # Ad Type Detection
    def detect_ad_type(self, description: str) -> str:
        """Keyword-based detection (fast, no API call needed)."""
        d = description.lower()
        if any(w in d for w in ["hiring","job","vacancy","role","position","developer","engineer","designer","manager","intern","recruit","doctor"]):
            return "Job / Hiring"
        if any(w in d for w in ["grocery","vegetable","fruit","fresh","organic","farm","milk","bread","food","restaurant","cafe"]):
            return "Grocery / Food"
        if any(w in d for w in ["sale","discount","offer","product","buy","shop","price","deal","launch"]):
            return "Product Sale"
        if any(w in d for w in ["event","concert","webinar","conference","meetup","workshop","party","festival","opening"]):
            return "Event"
        if any(w in d for w in ["service","repair","cleaning","plumber","electrician","salon","delivery","consulting"]):
            return "Service"
        if any(w in d for w in ["flat","apartment","house","rent","property","bedroom","bhk","sqft","villa"]):
            return "Real Estate"
        return "General"

    def suggest_platforms(self, ad_type: str) -> list[str]:
        return PLATFORM_SMART.get(ad_type, ["Instagram", "Facebook"])

    # Ad Generation 
    def generate_ads(
        self,
        description: str,
        ad_type:     str,
        tone:        str,
        language:    str,
        platforms:   list[str],
        extra:       str = "",
    ) -> dict:
        specs = "\n".join([
            f"- {p}: {PLATFORM_INFO[p]['style']} (max {PLATFORM_INFO[p]['max']} chars)"
            for p in platforms if p in PLATFORM_INFO
        ])
        ex_ads = ",\n    ".join([f'"{p}": "write engaging ad"' for p in platforms])

        prompt = (
            "You are a senior marketing copywriter and growth marketer.\n"
            "Your task is to generate high-performing, platform-native advertisement copy.\n\n"

            "CAMPAIGN INFORMATION:\n"
            f"Product / Service: {description}\n"
            f"Category: {ad_type}\n"
            f"Tone: {tone}\n"
            f"Language: {language}\n"
            + (f"Additional Instructions: {extra}\n" if extra else "") +

            "\nTARGET PLATFORMS AND STYLE:\n"
            f"{specs}\n\n"

            "WRITING GUIDELINES:\n"
            "- Start with a strong hook.\n"
            "- Highlight the main benefit of the product or service.\n"
            "- Keep the message clear and engaging.\n"
            "- Include a strong call-to-action when appropriate.\n"
            "- Adapt writing style to the platform audience.\n\n"

            "PLATFORM RULES:\n"
            "- X/Twitter: under 280 characters, punchy hook, 2–3 hashtags.\n"
            "- Threads: conversational, relatable tone, short paragraphs, 2–4 hashtags max.\n"
            "- Instagram: visual storytelling, emojis allowed, end with 5–8 hashtags.\n"
            "- Facebook: friendly tone, 1–2 short paragraphs, minimal hashtags.\n"
            "- LinkedIn: professional, value-focused, minimal emojis.\n"
            "- WhatsApp: short, personal message, NO hashtags.\n"
            "- Telegram: clean layout, short sections, use *bold* for key phrases.\n"
            "- Discord: casual community tone, short messages, can include emojis, avoid heavy marketing language.\n"
            "- Reddit: authentic, informative, non-salesy tone, focus on value.\n\n"

            "IMPORTANT OUTPUT RULES:\n"
            "- Generate ads ONLY for the platforms listed.\n"
            "- Return ONLY valid JSON.\n"
            "- Do NOT include explanations, markdown, or code fences.\n"
            "- Ensure the JSON is syntactically correct.\n\n"

            "EXPECTED JSON FORMAT:\n"
            "{\n"
            '  "title": "Short campaign title",\n'
            '  "ads": {\n'
            f"    {ex_ads}\n"
            "  },\n"
            '  "suggested_cta": "Primary call to action"\n'
            "}"
        )
        # NEW — replaces the old self.model.generate_content block
        response = self.client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
        )

        raw = response.text.strip()
        if not raw:
            raise ValueError("Gemini returned an empty response.")

        return self._parse_json(raw)    # JSON Parsing
    
    # private helper to extract JSON from Gemini's response
    def _parse_json(self, raw: str) -> dict:
        # Strip markdown fences if present
        if "```" in raw:
            for part in raw.split("```"):
                part = part.strip()
                if part.lower().startswith("json"):
                    part = part[4:].strip()
                if part.startswith("{"):
                    raw = part
                    break

        s = raw.find("{")
        e = raw.rfind("}") + 1
        if s == -1 or e == 0:
            raise ValueError(f"No JSON found in response: {raw[:300]}")

        try:
            return json.loads(raw[s:e])
        except json.JSONDecodeError as err:
            # Try to auto-close truncated JSON
            fixed = raw[s:].rstrip() + '"}}}'
            try:
                # might be a limit hit of API key, so we try to salvage what we can
                return json.loads(fixed[fixed.find("{"):fixed.rfind("}")+1])
            except Exception:
                raise ValueError(f"JSON parse failed: {err}\nRaw: {raw[:500]}")