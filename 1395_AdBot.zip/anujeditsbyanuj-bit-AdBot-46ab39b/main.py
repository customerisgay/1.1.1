"""AdBot Backend — FastAPI"""
# Depends -> used for dependency injection (
from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, Query
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import random
import uvicorn

# file imports
from database import engine, Base, get_db
from sqlalchemy.orm import Session
import models
import schemas
from services.ai_service import AIService
from services.platform_service import PlatformService
from services.metrics_service import MetricsService
from services.scheduler import start_scheduler, stop_scheduler
from services.image_selector import get_ad_image_url


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Creates all database tables if they do not exist.
    Base.metadata.create_all(bind=engine)
    start_scheduler()
    yield
    stop_scheduler()

app = FastAPI(title="AdBot API", version="1.0.0", lifespan=lifespan)

app.add_middleware(CORSMiddleware,
                   # This allows any frontend to call the API.
                   allow_origins=["*"],
                   allow_methods=["*"],
                   allow_headers=["*"]
                   )


ai_svc = AIService()
platform_svc = PlatformService()
metrics_svc = MetricsService()


# CAMPAIGNS
# response_model parameter tells the framework what structure the API should return to the client
@app.post("/campaigns", response_model=schemas.CampaignOut)
# payload -> campaign data from request
# db -> database session
def create_campaign(payload: schemas.CampaignCreate, db: Session = Depends(get_db)):

    ad_type = ai_svc.detect_ad_type(payload.description)

    campaign = models.Campaign(
        description=payload.description,
        tone=payload.tone,
        language=payload.language,
        ad_type=ad_type,
        suggested_platforms=",".join(ai_svc.suggest_platforms(ad_type)),
    )

    db.add(campaign)
    db.commit()
    db.refresh(campaign)

    return campaign


# returns all the campaigns in the database, ordered by creation date (newest first)
@app.get("/campaigns", response_model=list[schemas.CampaignOut])
def list_campaigns(db: Session = Depends(get_db)):
    # SELECT * FROM campaigns ORDER BY created_at DESC
    return db.query(models.Campaign).order_by(models.Campaign.created_at.desc()).all()

# returns a specific campaign by ID, or 404 if not found


@app.get("/campaigns/{campaign_id}", response_model=schemas.CampaignOut)
def get_campaign(campaign_id: int, db: Session = Depends(get_db)):
    c = db.query(models.Campaign).filter(
        models.Campaign.id == campaign_id).first()
    if not c:
        raise HTTPException(404, "Campaign not found")
    return c


# deletes a campaign and all its associated ads/posts (cascade delete)
@app.delete("/campaigns/{campaign_id}")
def delete_campaign(campaign_id: int, db: Session = Depends(get_db)):
    c = db.query(models.Campaign).filter(
        models.Campaign.id == campaign_id).first()

    if not c:
        raise HTTPException(404, "Campaign not found")

    db.delete(c)
    db.commit()
    return {"message": "Deleted"}


#  AD GENERATION for selected platforms
@app.post("/campaigns/{campaign_id}/generate", response_model=schemas.GenerateOut)
def generate_ads(campaign_id: int, payload: schemas.GenerateRequest, db: Session = Depends(get_db)):

    campaign = db.query(models.Campaign).filter(
        models.Campaign.id == campaign_id).first()

    if not campaign:
        raise HTTPException(404, "Campaign not found")

    # AI generates ONLY for platforms in payload.platforms
    result = ai_svc.generate_ads(
        description=campaign.description,
        ad_type=campaign.ad_type,
        tone=campaign.tone,
        language=campaign.language,
        platforms=payload.platforms,
        extra=payload.feedback or "",
    )
    # models.Ad -> the Ads table
    # Only select ads that belong to this campaign.
    version = (db.query(models.Ad).filter(models.Ad.campaign_id == campaign_id)
               .count() // max(len(payload.platforms), 1)) + 1

    saved_ads = []
    # payload.platforms contains the platforms selected by the user when requesting ad generation.

    """
    result = {
        "title": "Boost Your Productivity",
        "suggested_cta": "Try it Today",
        "ads": {
            "reddit": "Discover the AI tool everyone is talking about...",
            "twitter": "Supercharge your workflow with AI 🚀",
            "linkedin": "Improve team productivity using AI-driven automation."
        }
    }
    """
    for platform in payload.platforms:
        content = result["ads"].get(platform)
        if not content:
            continue

        ad = models.Ad(
            campaign_id=campaign_id,
            platform=platform,
            content=content,
            version=version,
            title=result.get("title", ""),
            cta=result.get("suggested_cta", ""),
            image_url="", 
            image_source="",
        )

        db.add(ad)
        db.flush() # sends the insert to the database without committing the transaction.
        saved_ads.append(ad)

    db.commit()

    for ad in saved_ads:
        db.refresh(ad) # to get the latest database state.

    return schemas.GenerateOut(
        title=result.get("title", ""), 
        suggested_cta=result.get("suggested_cta", ""),
        ads=[schemas.AdOut.model_validate(ad) for ad in saved_ads],
        # model_validate -> used to convert and validate external data into a Pydantic model
        version=version
    )


# ADS
@app.get("/campaigns/{campaign_id}/ads", response_model=list[schemas.AdOut])
def list_ads(campaign_id: int, db: Session = Depends(get_db)):
    return db.query(models.Ad).filter(models.Ad.campaign_id == campaign_id).all()


@app.put("/ads/{ad_id}", response_model=schemas.AdOut)
def update_ad(ad_id: int, payload: schemas.AdUpdate, db: Session = Depends(get_db)):
    ad = db.query(models.Ad).filter(models.Ad.id == ad_id).first()
    if not ad:
        raise HTTPException(404, "Ad not found")
    ad.content = payload.content
    db.commit()
    db.refresh(ad)
    return ad


# IMAGE: generate & save to DB
@app.post("/ads/{ad_id}/generate-image", response_model=schemas.AdOut)
def generate_image(
    ad_id:    int,
    source:   str = Query(default="flux"),
    feedback: str = Query(default=""),
    db:       Session = Depends(get_db),
):
    """Generate an image for a specific ad and persist it in the DB.

    Pass ?feedback=warmer+colors to steer the image generation prompt.
    """
    ad = db.query(models.Ad).filter(models.Ad.id == ad_id).first()
    if not ad:
        raise HTTPException(404, "Ad not found")
    ad.image_url = get_ad_image_url(ad.content, source=source,
                                    feedback=feedback.strip())
    ad.image_source = source
    db.commit()
    db.refresh(ad)
    return ad


@app.post("/ads/{ad_id}/regenerate-image", response_model=schemas.AdOut)
def regenerate_image(
    ad_id:    int,
    source:   str = Query(default="flux"),
    feedback: str = Query(default=""),
    db:       Session = Depends(get_db),
):
    """Regenerate a different image (new random seed) and persist it.

    Pass ?feedback=outdoor+setting to steer the image generation prompt.
    """
    ad = db.query(models.Ad).filter(models.Ad.id == ad_id).first()
    if not ad:
        raise HTTPException(404, "Ad not found")
    ad.image_url = get_ad_image_url(ad.content, source=source,
                                    seed=random.randint(1, 99999),
                                    feedback=feedback.strip())
    ad.image_source = source
    db.commit()
    db.refresh(ad)
    return ad

# POSTING


@app.post("/ads/{ad_id}/post", response_model=schemas.PostOut)
def post_ad(ad_id: int, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    ad = db.query(models.Ad).filter(models.Ad.id == ad_id).first()
    if not ad:
        raise HTTPException(404, "Ad not found")
    if ad.posted:
        raise HTTPException(400, "Ad already posted")

    # pass image_url to platform poster (used by Instagram/Facebook)
    result = platform_svc.post(
        ad.platform, ad.content, image_url=ad.image_url or None)

    post = models.Post(
        ad_id=ad.id, campaign_id=ad.campaign_id, platform=ad.platform,
        platform_post_id=result.get("post_id", ""), status="live",
    )
    ad.posted = True
    db.add(post)
    db.commit()
    db.refresh(post)
    background_tasks.add_task(metrics_svc.fetch_and_save, post.id, db)
    return post


@app.delete("/posts/{post_id}")
def delete_post(post_id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "Post not found")
    post.status = "archived"
    db.commit()
    return {"message": "Archived"}

# METRICS


@app.get("/posts/{post_id}/metrics", response_model=list[schemas.MetricsOut])
def get_metrics(post_id: int, db: Session = Depends(get_db)):
    return db.query(models.Metrics).filter(models.Metrics.post_id == post_id).order_by(models.Metrics.recorded_at.desc()).all()


@app.post("/posts/{post_id}/metrics/refresh", response_model=schemas.MetricsOut)
def refresh_metrics(post_id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "Post not found")
    return metrics_svc.fetch_and_save(post_id, db)


@app.get("/campaigns/{campaign_id}/posts", response_model=list[schemas.PostWithMetrics])
def get_campaign_posts(campaign_id: int, db: Session = Depends(get_db)):
    posts = db.query(models.Post).filter(
        models.Post.campaign_id == campaign_id).all()
    result = []
    for post in posts:
        latest = db.query(models.Metrics).filter(models.Metrics.post_id == post.id).order_by(
            models.Metrics.recorded_at.desc()).first()
        result.append(schemas.PostWithMetrics(
            **post.__dict__, latest_metrics=schemas.MetricsOut.model_validate(latest) if latest else None))
    return result


@app.get("/health")
def health():
    return {"status": "ok"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
