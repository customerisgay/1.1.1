"""models.py — SQLAlchemy database models"""

from sqlalchemy import Column, Integer, String, Text, Boolean, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
from database import Base


class Campaign(Base):
    __tablename__ = "campaigns"
    id                  = Column(Integer, primary_key=True, index=True)
    description         = Column(Text,    nullable=False)
    tone                = Column(String(50),  default="Auto-detect")
    language            = Column(String(50),  default="English")
    ad_type             = Column(String(100), default="General")
    suggested_platforms = Column(Text, default="")
    
    created_at          = Column(DateTime, default=datetime.now(timezone.utc))
    ads                 = relationship("Ad",   back_populates="campaign", cascade="all, delete")
    posts               = relationship("Post", back_populates="campaign", cascade="all, delete")


class Ad(Base):
    __tablename__ = "ads"
    id           = Column(Integer, primary_key=True, index=True)
    campaign_id  = Column(Integer, ForeignKey("campaigns.id"), nullable=False)
    platform     = Column(String(50),  nullable=False)
    content      = Column(Text,        nullable=False)
    version      = Column(Integer,     default=1)
    title        = Column(String(200), default="")
    cta          = Column(String(200), default="")
    posted       = Column(Boolean,     default=False)
    image_url    = Column(Text,        default="")    # saved image URL
    image_source = Column(String(50),  default="")    # which source generated it
    created_at   = Column(DateTime,    default=datetime.now(timezone.utc))
    campaign     = relationship("Campaign", back_populates="ads")
    post         = relationship("Post", back_populates="ad", uselist=False)


class Post(Base):
    __tablename__ = "posts"
    id               = Column(Integer, primary_key=True, index=True)
    ad_id            = Column(Integer, ForeignKey("ads.id"),       nullable=False)
    campaign_id      = Column(Integer, ForeignKey("campaigns.id"), nullable=False)
    platform         = Column(String(50), nullable=False)
    platform_post_id = Column(String(200), default="")
    status           = Column(String(20), default="live")
    posted_at        = Column(DateTime, default=datetime.now(timezone.utc))
    hours_live       = Column(Integer, default=0)
    ad               = relationship("Ad",       back_populates="post")
    campaign         = relationship("Campaign", back_populates="posts")
    metrics          = relationship("Metrics",  back_populates="post", cascade="all, delete")


class Metrics(Base):
    __tablename__ = "metrics"
    id          = Column(Integer, primary_key=True, index=True)
    post_id     = Column(Integer, ForeignKey("posts.id"), nullable=False)
    views       = Column(Integer, default=0)
    likes       = Column(Integer, default=0)
    shares      = Column(Integer, default=0)
    comments    = Column(Integer, default=0)
    clicks      = Column(Integer, default=0)
    eng_rate    = Column(Float,   default=0.0)
    recorded_at = Column(DateTime, default=datetime.now(timezone.utc))
    post        = relationship("Post", back_populates="metrics")
