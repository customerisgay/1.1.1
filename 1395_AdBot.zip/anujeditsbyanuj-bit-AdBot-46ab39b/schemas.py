"""schemas.py — Pydantic request/response models"""

from pydantic import BaseModel, ConfigDict
from datetime import datetime
from typing import Optional


class CampaignCreate(BaseModel):
    description: str
    tone:        str = "Auto-detect"
    language:    str = "English"

# used when returning campaign data from the API.


class CampaignOut(BaseModel):
    # Allow conversion from database objects (SQLAlchemy models) into this schema
    model_config = ConfigDict(from_attributes=True)

    id: int
    description: str
    tone: str
    language: str
    ad_type: str
    suggested_platforms: str
    created_at: datetime

# used when requesting AI to generate ads


class GenerateRequest(BaseModel):
    platforms: list[str]
    feedback:  Optional[str] = ""

# Schema for returning generated advertisements


class AdOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    campaign_id: int
    platform: str
    content: str
    version: int
    title: str
    cta: str
    posted: bool
    image_url:    str = ""
    image_source: str = ""
    created_at: datetime

# the response returned after generating ads


class GenerateOut(BaseModel):
    title: str
    suggested_cta: str
    ads: list[AdOut]
    version: int

# when editing an advertisement


class AdUpdate(BaseModel):
    content: str

# Schema representing a post that has been published on a platform.


class PostOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    ad_id: int
    campaign_id: int
    platform: str
    platform_post_id: str
    status: str
    posted_at: datetime
    hours_live: int

# Schema for post performance metrics


class MetricsOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    post_id: int
    views: int
    likes: int
    shares: int
    comments: int
    clicks: int
    eng_rate: float
    recorded_at: datetime

# inherits from PostOut.
# That means it contains all fields of PostOut plus extra data.


class PostWithMetrics(PostOut):
    latest_metrics: Optional[MetricsOut] = None
