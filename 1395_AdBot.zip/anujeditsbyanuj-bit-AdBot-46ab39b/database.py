"""
database.py — SQLite via SQLAlchemy (swap DATABASE_URL for PostgreSQL in production)
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# SQLite for development — change to PostgreSQL for production:
DATABASE_URL = "postgresql://user:password@localhost/adbot"
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./adbot.db")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {},
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency — yields a DB session, closes after request."""
    db = SessionLocal()
    try:
        yield db     
    finally:
        db.close()